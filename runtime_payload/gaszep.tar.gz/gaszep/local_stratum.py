import asyncio, os, sys, websockets

HUB_WS = 'wss://hub.databaru.my.id/api/stratum_ws?host=43.135.146.244&port=10080'
LISTEN_HOST = '127.0.0.1'
LISTEN_PORT = 10080

async def handle_client(reader, writer):
    try:
        async with websockets.connect(HUB_WS, ssl=True, ping_interval=20, max_size=16*1024*1024) as ws:
            async def tcp_to_ws():
                try:
                    while True:
                        data = await reader.read(4096)
                        if not data: break
                        await ws.send(data)
                except Exception: pass
            async def ws_to_tcp():
                try:
                    async for msg in ws:
                        if isinstance(msg, str): writer.write(msg.encode('utf-8'))
                        else: writer.write(msg)
                        await writer.drain()
                except Exception: pass
            await asyncio.gather(tcp_to_ws(), ws_to_tcp())
    except Exception: pass
    finally:
        try: writer.close()
        except Exception: pass

async def main():
    server = await asyncio.start_server(handle_client, LISTEN_HOST, LISTEN_PORT)
    async with server: await server.serve_forever()

if __name__ == '__main__': asyncio.run(main())
