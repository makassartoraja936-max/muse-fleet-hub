let hasClickedOpenProject = false; // Status apakah tombol "Open Project" sudah diklik
let isProcessing = false; // Status apakah proses sedang berjalan

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Periksa apakah halaman yang dimuat adalah halaman dengan URL /users/
    if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("https://studiolab.sagemaker.aws/users/")) {
        // Periksa apakah tab aktif di jendela saat ini
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            if (activeTab.id === tabId) {
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    func: startAutomation
                });
            }
        });
    }
});

// Listener saat ekstensi diinstal
chrome.runtime.onInstalled.addListener(() => {
    // Membuat alarm yang berjalan setiap 4 menit
    chrome.alarms.create('keepAlive', { periodInMinutes: 4 });
});

// Listener saat Chrome dibuka kembali
chrome.runtime.onStartup.addListener(() => {
    chrome.alarms.create('keepAlive', { periodInMinutes: 4 });
});

// Listener untuk alarm
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'keepAlive') {
        // Keep service worker alive
    }
});

// Fungsi utama untuk otomatisasi
function startAutomation() {
    if (window.isProcessing) {
        return;
    }

    window.isProcessing = true; // Tandai bahwa proses sedang berjalan

    function waitForXPath(xpath, callback, timeout = 10000) {
        let retries = 0;
        const interval = 1000; // Interval untuk mencoba menemukan elemen
        const maxRetries = Math.ceil(timeout / interval);

        const intervalId = setInterval(() => {
            retries++;
            const element = document.evaluate(
                xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;

            if (element) {
                clearInterval(intervalId);
                callback(element);
            } else if (retries >= maxRetries) {
                clearInterval(intervalId);
                callback(null); // Jika tidak ditemukan, panggil callback dengan null
            }
        }, interval);
    }

    // Fungsi untuk deteksi CAPTCHA yang lebih komprehensif
    function detectCaptcha() {
        // Berbagai selector untuk mendeteksi CAPTCHA
        const captchaSelectors = [
            // AWS WAF CAPTCHA selectors - yang paling umum di AWS
            'awswaf-captcha',
            '[data-awswaf-captcha]',
            '.awswaf-captcha',
            '#awswaf-captcha',
            'div[class*="awswaf"]',
            'div[id*="awswaf"]',
            
            // Generic CAPTCHA selectors (EXCLUDE our own notification)
            '.captcha-modal',
            '.captcha-container',
            '.captcha-wrapper',
            '.captcha-box',
            '[id*="captcha"]:not(#captcha-notification)',
            '[class*="captcha"]:not(.captcha-notification)',
            '[data-captcha]',
            
            // reCAPTCHA selectors
            '.g-recaptcha',
            '#recaptcha',
            'iframe[src*="recaptcha"]',
            '.recaptcha-container',
            
            // hCaptcha selectors
            '.h-captcha',
            'iframe[src*="hcaptcha"]',
            
            // Cloudflare selectors
            '.cf-challenge',
            '.challenge-form',
            '.cf-captcha',
            
            // AWS specific selectors
            '.aws-captcha',
            '[class*="aws-captcha"]',
            '[id*="aws-captcha"]',
            
            // Modal/dialog selectors that might contain CAPTCHA
            '[role="dialog"]',
            '.modal',
            '.MuiDialog-root',
            '.popup',
            '.overlay',
            
            // Challenge-related selectors
            '.challenge',
            '.verification',
            '.security-check',
            '[class*="challenge"]',
            '[class*="verification"]'
        ];

        let captchaFound = false;
        let foundElement = null;
        let foundSelector = '';

        // Check each selector
        for (const selector of captchaSelectors) {
            try {
                const elements = document.querySelectorAll(selector);

                if (elements.length > 0) {
                    for (const element of elements) {
                        // SKIP our own notification elements
                        if (element.id === 'captcha-notification' || 
                            element.classList.contains('captcha-notification')) {
                            continue;
                        }
                        
                        // Check if element is visible and not hidden
                        const style = window.getComputedStyle(element);
                        const rect = element.getBoundingClientRect();
                        
                        if (style.display !== 'none' && 
                            style.visibility !== 'hidden' && 
                            style.opacity !== '0' &&
                            rect.width > 0 && 
                            rect.height > 0) {
                            
                            captchaFound = true;
                            foundElement = element;
                            foundSelector = selector;
                            break;
                        }
                    }
                    if (captchaFound) break;
                }
            } catch (error) {
                // Error checking selector
            }
        }

        // Additional checks for iframe-based CAPTCHAs
        if (!captchaFound) {
            const iframes = document.querySelectorAll('iframe');
            for (const iframe of iframes) {
                try {
                    const src = iframe.src ? iframe.src.toLowerCase() : '';
                    const title = iframe.title ? iframe.title.toLowerCase() : '';
                    const className = iframe.className ? iframe.className.toLowerCase() : '';
                    
                    if (src.includes('captcha') || src.includes('recaptcha') || src.includes('hcaptcha') ||
                        title.includes('captcha') || className.includes('captcha') ||
                        src.includes('challenge') || title.includes('challenge')) {
                        
                        // Check if iframe is visible
                        const rect = iframe.getBoundingClientRect();
                        const style = window.getComputedStyle(iframe);
                        
                        if (style.display !== 'none' && 
                            style.visibility !== 'hidden' && 
                            rect.width > 0 && rect.height > 0) {
                            
                            captchaFound = true;
                            foundElement = iframe;
                            foundSelector = 'iframe';
                            break;
                        }
                    }
                } catch (error) {
                    // Error checking iframe
                }
            }
        }

        // Check for text content that might indicate CAPTCHA (EXCLUDE our notification)
        if (!captchaFound) {
            const bodyTextElement = document.body.cloneNode(true);
            // Remove our notification from the clone
            const notificationInClone = bodyTextElement.querySelector('#captcha-notification');
            if (notificationInClone) {
                notificationInClone.remove();
            }
            
            const bodyText = bodyTextElement.textContent.toLowerCase();
            const captchaKeywords = [
                'complete the captcha',
                'solve the captcha',
                'verify you are human',
                'prove you are human',
                'security check',
                'prove you are not a robot',
                'human verification',
                'challenge verification',
                'verify your identity',
                'security challenge',
                'complete verification',
                'anti-robot verification'
            ];

            for (const keyword of captchaKeywords) {
                if (bodyText.includes(keyword)) {
                    captchaFound = true;
                    foundSelector = 'text-detection';
                    
                    // Try to find the element containing this text (but not our notification)
                    const textNodes = document.evaluate(
                        `//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '${keyword}') and not(@id='captcha-notification')]`,
                        document,
                        null,
                        XPathResult.FIRST_ORDERED_NODE_TYPE,
                        null
                    );
                    
                    if (textNodes.singleNodeValue) {
                        foundElement = textNodes.singleNodeValue;
                    }
                    break;
                }
            }
        }

        return { found: captchaFound, element: foundElement, selector: foundSelector };
    }

    function checkOpenProject() {
        const openProjectXPath = '/html/body/div[2]/div/div/div[1]/div/div/div/button/span[1]';
        waitForXPath(openProjectXPath, (openProjectButton) => {
            if (openProjectButton) {
                const isDisabled = openProjectButton.parentElement.disabled;
                const isActive = !isDisabled && !openProjectButton.parentElement.classList.contains("Mui-disabled");

                if (isActive) {
                    if (!window.hasClickedOpenProject) {
                        openProjectButton.parentElement.click(); // Klik tombol
                        window.hasClickedOpenProject = true;
                        window.isProcessing = false; // Proses selesai
                    }
                } else {
                    startRuntime();
                }
            } else {
                startRuntime();
            }
        });
    }

    function startRuntime() {
        // Cek CAPTCHA terlebih dahulu
        const captchaResult = detectCaptcha();
        
        if (captchaResult.found) {
            showCaptchaNotification(captchaResult.element);
            waitForCaptchaCompletion(() => {
                cleanupCaptchaUI();
                proceedWithStartRuntime();
            });
        } else {
            proceedWithStartRuntime();
        }
    }

    function proceedWithStartRuntime() {
        let retryCount = 0;
        const maxRetries = 50;
        const retryDelay = 2000; // 2 detik delay - diperpanjang untuk stabilitas
        
        function attemptStartRuntime() {
            // PERBAIKAN: Cek CAPTCHA SEBELUM mencoba klik Start Runtime
            const captchaResult = detectCaptcha();
            if (captchaResult.found) {
                showCaptchaNotification(captchaResult.element);
                waitForCaptchaCompletion(() => {
                    cleanupCaptchaUI();
                    // Delay sebentar setelah CAPTCHA selesai sebelum coba start runtime
                    setTimeout(() => {
                        attemptStartRuntime(); // Recursive call setelah CAPTCHA selesai
                    }, 2000);
                });
                return; // PENTING: Keluar dari fungsi, jangan lanjut ke klik button
            }
            
            waitForXPath('//*[@id="root"]/div/div/div/div/div/div[2]/div/div[4]/div/span/button/span', (startRuntimeButton) => {
                if (startRuntimeButton) {
                    // PERBAIKAN: Double check CAPTCHA sesaat sebelum klik
                    const lastMinuteCaptchaCheck = detectCaptcha();
                    if (lastMinuteCaptchaCheck.found) {
                        showCaptchaNotification(lastMinuteCaptchaCheck.element);
                        waitForCaptchaCompletion(() => {
                            cleanupCaptchaUI();
                            setTimeout(() => {
                                attemptStartRuntime();
                            }, 2000);
                        });
                        return;
                    }
                    
                    startRuntimeButton.click();
                    
                    // Tunggu lebih lama untuk memastikan proses klik selesai
                    setTimeout(() => {
                        checkRuntimeResult();
                    }, 4000); // Diperpanjang dari 3 detik ke 4 detik
                } else {
                    checkOpenProject();
                }
            });
        }
        
        function checkRuntimeResult() {
            // PERBAIKAN: Cek CAPTCHA dengan lebih teliti
            const captchaResult = detectCaptcha();
            
            if (captchaResult.found) {
                showCaptchaNotification(captchaResult.element);
                // PERBAIKAN: Tunggu dengan timeout yang lebih panjang dan callback yang lebih robust
                waitForCaptchaCompletion(() => {
                    cleanupCaptchaUI();
                    // PERBAIKAN: Tambah delay setelah CAPTCHA selesai sebelum cek error
                    setTimeout(() => {
                        checkForRuntimeError();
                    }, 3000); // Delay 3 detik setelah CAPTCHA selesai
                });
                return;
            }
            
            // Jika tidak ada CAPTCHA, langsung cek error
            checkForRuntimeError();
        }
        
        function checkForRuntimeError() {
            const errorXPath = '/html/body/div[2]/div/div/div[1]/div/div/div[1]';
            const errorElement = document.evaluate(
                errorXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;
            
            if (errorElement && errorElement.textContent) {
                const errorText = errorElement.textContent.trim();
                
                // Cek apakah masih loading/preparing
                if (errorText.includes("Preparing project runtime") || 
                    errorText.includes("Starting runtime") ||
                    errorText.includes("Loading")) {
                    
                    setTimeout(() => {
                        // Cek dulu apakah Open Project sudah muncul
                        const openProjectXPath = '/html/body/div[2]/div/div/div[1]/div/div/div/button/span[1]';
                        const openProjectButton = document.evaluate(
                            openProjectXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
                        ).singleNodeValue;

                        if (openProjectButton && 
                            !openProjectButton.parentElement.disabled && 
                            !openProjectButton.parentElement.classList.contains("Mui-disabled")) {
                            checkOpenProject();
                        } else {
                            checkForRuntimeError(); // Cek lagi status error
                        }
                    }, 5000);
                    return;
                }
                
                // Cek error yang memerlukan retry
                if (errorText.includes("There is no runtime available right now") || 
                    errorText.includes("The server currently has too many requests") ||
                    errorText.includes("Please try again later") ||
                    errorText.includes("Runtime failed to start") ||
                    errorText.includes("Unable to start runtime")) {
                    
                    retryCount++;
                    
                    if (retryCount < maxRetries) {
                        setTimeout(() => {
                            attemptStartRuntime();
                        }, retryDelay);
                    } else {
                        window.isProcessing = false;
                    }
                } else {
                    // Tidak ada error yang dikenal, cek Open Project
                    setTimeout(() => {
                        // Cek dulu apakah Open Project sudah muncul
                        const openProjectXPath = '/html/body/div[2]/div/div/div[1]/div/div/div/button/span[1]';
                        const openProjectButton = document.evaluate(
                            openProjectXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
                        ).singleNodeValue;

                        if (openProjectButton && 
                            !openProjectButton.parentElement.disabled && 
                            !openProjectButton.parentElement.classList.contains("Mui-disabled")) {
                            checkOpenProject();
                        } else {
                            attemptStartRuntime();
                        }
                    }, 3000);
                }
            } else {
                // Tidak ada error, cek Open Project
                setTimeout(() => {
                    // Cek dulu apakah Open Project sudah muncul
                    const openProjectXPath = '/html/body/div[2]/div/div/div[1]/div/div/div/button/span[1]';
                    const openProjectButton = document.evaluate(
                        openProjectXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
                    ).singleNodeValue;

                    if (openProjectButton && 
                        !openProjectButton.parentElement.disabled && 
                        !openProjectButton.parentElement.classList.contains("Mui-disabled")) {
                        checkOpenProject();
                    } else {
                        attemptStartRuntime();
                    }
                }, 3000);
            }
        }
        
        // Mulai attempt pertama
        attemptStartRuntime();
    }

    function showCaptchaNotification(captchaElement) {
        // Highlight the captcha element if found
        if (captchaElement) {
            captchaElement.style.border = "3px solid red";
            captchaElement.style.boxShadow = "0 0 10px red";
        }
        
        // Remove existing notification first
        const existingNotification = document.getElementById('captcha-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Create notification
        const notification = document.createElement('div');
        notification.id = 'captcha-notification';
        notification.className = 'captcha-notification'; // Add class for easier identification
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff4444;
            color: white;
            padding: 15px;
            border-radius: 5px;
            z-index: 10000;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            animation: pulse 1s infinite;
            max-width: 300px;
        `;
        
        // Add CSS animation if not exists
        if (!document.getElementById('captcha-animation-style')) {
            const style = document.createElement('style');
            style.id = 'captcha-animation-style';
            style.textContent = `
                @keyframes pulse {
                    0% { opacity: 1; }
                    50% { opacity: 0.7; }
                    100% { opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
        
        notification.innerHTML = '🤖 CAPTCHA detected!<br>Please complete it to continue.<br><small>Automation will resume automatically.</small>';
        document.body.appendChild(notification);
    }
    
    function waitForCaptchaCompletion(callback) {
        const captchaCheckInterval = 1500; // Cek setiap 1.5 detik - lebih sering
        const maxCaptchaWaitTime = 600000; // Maksimal 10 menit untuk captcha - diperpanjang
        let captchaWaitTime = 0;
        let consecutiveNoCaptcha = 0; // Counter untuk memastikan CAPTCHA benar-benar hilang
        const requiredConsecutive = 3; // Perlu 3 kali berturut-turut tidak ada CAPTCHA
        
        const captchaChecker = setInterval(() => {
            captchaWaitTime += captchaCheckInterval;
            
            // Cek apakah captcha masih ada
            const captchaResult = detectCaptcha();
            
            if (!captchaResult.found) {
                consecutiveNoCaptcha++;
                
                // PERBAIKAN: Pastikan CAPTCHA benar-benar hilang dengan mengecek beberapa kali
                if (consecutiveNoCaptcha >= requiredConsecutive) {
                    clearInterval(captchaChecker);
                    callback();
                }
            } else {
                consecutiveNoCaptcha = 0; // Reset counter jika masih ada CAPTCHA
            }
            
            if (captchaWaitTime >= maxCaptchaWaitTime) {
                // Timeout menunggu captcha
                clearInterval(captchaChecker);
                callback();
            }
        }, captchaCheckInterval);
    }
    
    function cleanupCaptchaUI() {
        // Remove any highlighting
        const highlightedElements = document.querySelectorAll('[style*="border: 3px solid red"]');
        highlightedElements.forEach(el => {
            el.style.border = '';
            el.style.boxShadow = '';
        });
        
        // Remove notification
        const notification = document.getElementById('captcha-notification');
        if (notification && notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
        
        // Remove animation style
        const animationStyle = document.getElementById('captcha-animation-style');
        if (animationStyle && animationStyle.parentNode) {
            animationStyle.parentNode.removeChild(animationStyle);
        }
    }

    // Reset flags untuk sesi baru
    window.hasClickedOpenProject = false;
    
    // Langsung mulai dengan Start Runtime
    startRuntime();
}