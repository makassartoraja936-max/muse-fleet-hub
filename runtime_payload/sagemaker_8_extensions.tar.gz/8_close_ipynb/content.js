// URL target
const TARGET_URL_PATTERN = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/;

if (TARGET_URL_PATTERN.test(window.location.href)) {
    console.log("[INFO] Memulai otomatisasi...");

    function closeGettingStartedTab() {
        const gettingStartedText = "Your SageMaker Studio Lab project is a notebook development environment with 15 GB of persistent storage";
        if (!document.body.innerText.includes(gettingStartedText)) {
            return false;
        }

        console.log("[INFO] Terdeteksi Getting Started.ipynb...");

        // Cari tab Getting Started
        let targetTab = null;
        const tabs = document.querySelectorAll('.lm-TabBar-tab, li[id^="tab-key-"]');
        for (let tab of tabs) {
            if (tab.textContent.includes('Getting Started')) {
                targetTab = tab;
                break;
            }
        }

        if (!targetTab) {
            console.log("[WARNING] Tab tidak ditemukan");
            return false;
        }

        console.log("[INFO] Tab ditemukan, mencoba close...");

        // METHOD 1: Middle-click pada tab (universal close tab gesture)
        console.log("[INFO] Method 1: Middle-click...");
        const rect = targetTab.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        targetTab.dispatchEvent(new MouseEvent('auxclick', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: x,
            clientY: y,
            button: 1  // middle button
        }));

        // METHOD 2: Trigger lm-close-request event (Lumino framework)
        setTimeout(() => {
            console.log("[INFO] Method 2: Lumino close-request...");
            targetTab.dispatchEvent(new CustomEvent('lm-close-request', { bubbles: true }));
            
            // Coba juga pada title element
            const title = targetTab.querySelector('.lm-TabBar-tabLabel');
            if (title) {
                title.dispatchEvent(new CustomEvent('lm-close-request', { bubbles: true }));
            }
        }, 200);

        // METHOD 3: Klik close icon dengan pointer events
        setTimeout(() => {
            console.log("[INFO] Method 3: Click close icon...");
            
            // Cari close icon
            const closeIcon = targetTab.querySelector('.lm-TabBar-tabCloseIcon') || 
                              targetTab.querySelector('[data-icon="ui-components:close"]') ||
                              targetTab.querySelector('svg');
            
            if (closeIcon) {
                // Pastikan element bisa diklik
                const origPointerEvents = closeIcon.style.pointerEvents;
                closeIcon.style.pointerEvents = 'auto';
                
                const iconRect = closeIcon.getBoundingClientRect();
                const iconX = iconRect.left + iconRect.width / 2;
                const iconY = iconRect.top + iconRect.height / 2;
                
                // Sequence lengkap: pointerdown -> mousedown -> mouseup -> pointerup -> click
                ['pointerdown', 'mousedown'].forEach(type => {
                    closeIcon.dispatchEvent(new PointerEvent(type, {
                        bubbles: true, cancelable: true, view: window,
                        clientX: iconX, clientY: iconY, button: 0, isPrimary: true
                    }));
                });
                
                ['mouseup', 'pointerup', 'click'].forEach(type => {
                    closeIcon.dispatchEvent(new PointerEvent(type, {
                        bubbles: true, cancelable: true, view: window,
                        clientX: iconX, clientY: iconY, button: 0, isPrimary: true
                    }));
                });
                
                closeIcon.style.pointerEvents = origPointerEvents;
            }
        }, 400);

        // METHOD 4: Inject script untuk akses JupyterLab internal
        setTimeout(() => {
            console.log("[INFO] Method 4: JupyterLab commands...");
            
            const script = document.createElement('script');
            script.textContent = `
                (function() {
                    try {
                        // Coba akses JupyterLab app
                        if (window.jupyterapp && window.jupyterapp.commands) {
                            window.jupyterapp.commands.execute('application:close');
                            console.log('[EXT] JupyterLab command executed');
                        }
                        
                        // Alternatif: cari via require
                        if (typeof require !== 'undefined') {
                            const app = require('@jupyterlab/application').JupyterFrontEnd;
                            if (app && app.commands) {
                                app.commands.execute('application:close');
                            }
                        }
                    } catch(e) {
                        console.log('[EXT] JupyterLab command failed:', e);
                    }
                })();
            `;
            document.head.appendChild(script);
            script.remove();
        }, 600);

        // METHOD 5: Double-click pada close area (some UIs respond to this)
        setTimeout(() => {
            console.log("[INFO] Method 5: Double-click close area...");
            
            const closeIcon = targetTab.querySelector('.lm-TabBar-tabCloseIcon');
            if (closeIcon) {
                closeIcon.dispatchEvent(new MouseEvent('dblclick', {
                    bubbles: true, cancelable: true, view: window, detail: 2
                }));
            }
        }, 800);

        return true;
    }

    function startAutomation(attempt = 1, maxAttempts = 20) {
        console.log(`[INFO] Percobaan ${attempt}/${maxAttempts}...`);

        const gettingStartedText = "Your SageMaker Studio Lab project is a notebook development environment with 15 GB of persistent storage";

        if (document.body.innerText.includes(gettingStartedText)) {
            console.log("[SUCCESS] Getting Started terdeteksi!");
            closeGettingStartedTab();
        } else if (attempt < maxAttempts) {
            setTimeout(() => startAutomation(attempt + 1, maxAttempts), 2000);
        } else {
            console.log("[INFO] Getting Started tidak ditemukan.");
        }
    }

    setTimeout(() => startAutomation(), 3000);

} else {
    console.log("[INFO] Ekstensi tidak aktif di halaman ini.");
}
