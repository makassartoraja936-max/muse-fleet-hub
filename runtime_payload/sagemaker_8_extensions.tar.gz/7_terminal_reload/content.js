const MAX_RETRIES = 50;
const RETRY_INTERVAL = 2000;
let retries = 0;

const TARGET_URL_PATTERN = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/;

if (TARGET_URL_PATTERN.test(window.location.href)) {
    console.log("[INFO] Memulai otomatisasi klik terminal...");

    function clickTerminalButton(attempt = 1, maxAttempts = 10) {
        const waitTime = 5000;
        console.log(`[INFO] Percobaan ${attempt}/${maxAttempts}: Menunggu ${waitTime/1000} detik sebelum mencari tombol...`);
        
        setTimeout(() => {
            let button = null;
            
            // Method 1: XPath asli
            const buttonXPath = '/html/body/div[1]/div[3]/div[2]/div[1]/div[3]/div[3]/div[3]/div/div/div[4]/div[2]/div[1]/div[1]';
            button = document.evaluate(buttonXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            
            if (button) {
                console.log("[INFO] Tombol ditemukan dengan XPath asli.");
            } else {
                console.log("[INFO] XPath asli gagal, mencoba method alternatif...");
                
                // Method 2: Cari berdasarkan teks "Terminal"
                const allElements = document.querySelectorAll('*');
                for (let element of allElements) {
                    if (element.textContent && element.textContent.trim() === 'Terminal' && element.tagName === 'DIV') {
                        button = element;
                        console.log("[INFO] Tombol ditemukan berdasarkan teks 'Terminal'.");
                        break;
                    }
                }
            }
            
            if (!button) {
                // Method 3: XPath fleksibel
                const flexibleXPaths = [
                    "//div[contains(@class, 'jp-LauncherCard') and .//div[text()='Terminal']]",
                    "//div[contains(@class, 'jp-LauncherCard') and .//span[text()='Terminal']]",
                    "//div[contains(@class, 'jp-LauncherCard') and contains(., 'Terminal')]",
                    "//div[text()='Terminal']",
                    "//div[contains(text(), 'Terminal')]"
                ];
                
                for (let xpath of flexibleXPaths) {
                    button = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    if (button) {
                        console.log(`[INFO] Tombol ditemukan dengan XPath: ${xpath}`);
                        break;
                    }
                }
            }
            
            if (!button) {
                // Method 4: CSS selectors
                const possibleSelectors = [
                    '.jp-LauncherCard[title*="Terminal"]',
                    '.jp-LauncherCard[data-category*="Terminal"]',
                    'div[data-command*="terminal"]',
                    'div[data-command="terminal:create-new"]'
                ];
                
                for (let selector of possibleSelectors) {
                    try {
                        button = document.querySelector(selector);
                        if (button) {
                            console.log(`[INFO] Tombol ditemukan dengan selector: ${selector}`);
                            break;
                        }
                    } catch (e) {}
                }
            }
            
            if (!button) {
                // Method 5: Launcher cards
                const launcherCards = document.querySelectorAll('.jp-LauncherCard, div[class*="launcher"], div[class*="card"]');
                for (let element of launcherCards) {
                    const text = element.textContent || element.innerText || '';
                    const title = element.title || '';
                    const ariaLabel = element.getAttribute('aria-label') || '';
                    const dataCommand = element.getAttribute('data-command') || '';
                    
                    if ((text.includes('Terminal') || title.includes('Terminal') || ariaLabel.includes('Terminal') || dataCommand.includes('terminal')) &&
                        (element.classList.contains('jp-LauncherCard') || element.onclick || element.style.cursor === 'pointer')) {
                        button = element;
                        console.log("[INFO] Tombol launcher Terminal ditemukan.");
                        break;
                    }
                }
            }

            if (button && validateTerminalButton(button)) {
                console.log("[SUCCESS] Tombol Terminal valid ditemukan! Mengklik...");
                button.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                setTimeout(() => {
                    try {
                        button.click();
                        console.log("[INFO] Klik berhasil.");
                    } catch (e) {
                        const clickEvent = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                        button.dispatchEvent(clickEvent);
                    }
                    
                    setTimeout(() => reloadPage(), 2000);
                }, 500);
            } else {
                if (attempt < maxAttempts) {
                    console.warn(`[WARNING] Percobaan ${attempt}/${maxAttempts} gagal. Mencoba lagi...`);
                    setTimeout(() => clickTerminalButton(attempt + 1, maxAttempts), 2000);
                } else {
                    console.error("[ERROR] Tombol Terminal tidak ditemukan setelah 10 percobaan!");
                    setTimeout(() => reloadPage(), 1000);
                }
            }
        }, waitTime);
    }

    function validateTerminalButton(element) {
        if (!element) return false;
        
        const blacklistedClasses = ['lm-TabBar-tabLabel', 'jp-TabBar-tabLabel', 'jp-MenuBar-label', 'jp-Toolbar-label'];
        if (blacklistedClasses.some(cls => element.classList.contains(cls))) return false;
        
        const hasLauncherClass = element.classList.contains('jp-LauncherCard') ||
                                 element.classList.contains('jp-LauncherCard-body') ||
                                 element.closest('.jp-LauncherCard') !== null;
        
        const dataCommand = element.getAttribute('data-command') || '';
        const hasTerminalCommand = dataCommand.includes('terminal');
        
        const title = element.title || '';
        const ariaLabel = element.getAttribute('aria-label') || '';
        const hasValidTitle = title.toLowerCase().includes('terminal') || ariaLabel.toLowerCase().includes('terminal');
        
        const text = element.textContent || element.innerText || '';
        const isJustText = text.trim() === 'Terminal' && !hasLauncherClass && !hasTerminalCommand && !hasValidTitle;
        
        return (hasLauncherClass || hasTerminalCommand || hasValidTitle) && !isJustText;
    }

    function checkTerminalInBody() {
        const bodyElement = document.querySelector("body");
        if (!bodyElement) return false;
        const bodyText = bodyElement.innerText || "";
        return ['Terminal', 'terminal', 'TERMINAL', 'Console', 'console'].some(keyword => bodyText.includes(keyword));
    }

    function reloadPage() {
        console.log("[INFO] Akan reload halaman dalam 25 detik...");
        setTimeout(() => {
            console.log("[INFO] Melakukan reload halaman...");
            window.location.reload();
        }, 25000);
    }

    function waitForTerminalAndClick() {
        console.log(`[INFO] Percobaan ke-${retries + 1} untuk mendeteksi teks "Terminal"...`);
        retries++;

        if (checkTerminalInBody()) {
            console.log("[SUCCESS] Teks 'Terminal' terdeteksi.");
            clickTerminalButton();
        } else {
            if (retries < MAX_RETRIES) {
                setTimeout(waitForTerminalAndClick, RETRY_INTERVAL);
            } else {
                console.error("[ERROR] Teks 'Terminal' tidak ditemukan setelah beberapa percobaan.");
            }
        }
    }

    waitForTerminalAndClick();
} else {
    console.log("[INFO] Ekstensi tidak aktif di halaman ini.");
}
