chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.url && tab.url.includes("studiolab.sagemaker.aws/studiolab/") && changeInfo.status === "complete") {
        console.log("[INFO] Halaman SageMaker termuat. Menjalankan script...");
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ["content.js"]
        });
    }
});
