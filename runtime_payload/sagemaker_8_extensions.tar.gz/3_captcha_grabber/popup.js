document.addEventListener('DOMContentLoaded', function() {
  const refreshBtn = document.getElementById('refresh-btn');
  const clearBtn = document.getElementById('clear-btn');
  const clickBtn = document.getElementById('click-btn');
  const viewDataBtn = document.getElementById('view-data-btn');
  const analyticsBtn = document.getElementById('analytics-btn');
  const clearDbBtn = document.getElementById('clear-db-btn');
  const rebuildAnalyticsBtn = document.getElementById('rebuild-analytics-btn');
  const debugBtn = document.getElementById('debug-btn');
  
  // Helper function to show loading state on buttons
  function setButtonLoading(button, loading = true) {
    if (!button) return;
    
    if (loading) {
      button.classList.add('btn-loading');
      button.disabled = true;
    } else {
      button.classList.remove('btn-loading');
      button.disabled = false;
    }
  }

  function isChromeExtensionContext() {
    return typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  }

  if (!isChromeExtensionContext()) {
    document.body.innerHTML = '<div style="padding: 20px; color: red;">Error: Not in Chrome Extension context.</div>';
    return;
  }

  // Inisialisasi
  loadCompactStats();
  loadTiles();

  function loadCompactStats() {
    if (!chrome || !chrome.storage) return;

    Promise.all([
      // ✅ FIXED: Load database size from database.json file instead of storage
      fetch(chrome.runtime.getURL('database.json'))
        .then(response => response.json())
        .then(data => ({ hashDatabase: data }))
        .catch(() => ({ hashDatabase: {} })),
      new Promise(resolve => {
        chrome.storage.local.get(['learnedDatabase', 'hashSettings'], (result) => {
          if (chrome.runtime.lastError) resolve({});
          else resolve(result);
        });
      }),
      new Promise(resolve => {
        chrome.runtime.sendMessage({ action: 'getLearningAnalytics' }, (response) => {
          if (chrome.runtime.lastError) resolve({ success: false });
          else resolve(response || { success: false });
        });
      })
    ]).then(([dbResult, storageResult, analyticsResult]) => {
      // Database stats (Column 1)
      const dbSize = dbResult.hashDatabase ? Object.keys(dbResult.hashDatabase).length : 0;
      const learnedDbSize = storageResult.learnedDatabase ? Object.keys(storageResult.learnedDatabase).length : 0;
      const settings = storageResult.hashSettings || { width: 9, height: 8, threshold: 10 };
      const uniqueLabels = new Set(Object.values(dbResult.hashDatabase || {}));
      if (storageResult.learnedDatabase) {
        Object.values(storageResult.learnedDatabase).forEach(label => uniqueLabels.add(label));
      }
      
      const dbStatsElement = document.getElementById('db-main-stats');
      if (dbStatsElement) {
        dbStatsElement.innerHTML = `
          <div class="stats-value">Base: ${dbSize.toLocaleString()}</div>
          <div class="stats-value">Learned: ${learnedDbSize}</div>
          <div style="font-size: 9px; margin-top: 2px;">
            Labels: ${uniqueLabels.size} | ${settings.width}x${settings.height}
          </div>`;
      }

      // Analytics stats (Column 2)
      const analyticsElement = document.getElementById('analytics-stats');
      if (analyticsElement) {
        if (analyticsResult && analyticsResult.success && analyticsResult.analytics) {
          const analytics = analyticsResult.analytics;
          analyticsElement.innerHTML = `
            <div class="stats-value">Success: ${analytics.successUnknown || 0} | <span style="color: #FF9800;">${analytics.successWrongCategory || 0}</span></div>
            <div class="stats-value">Learned: ${analytics.totalLearned || 0} | <span style="color: #FF9800;">${analytics.totalCorrected || 0}</span></div>
            <div style="font-size: 9px; margin-top: 2px;">
              Categories: ${analytics.uniqueLabels || 0}
            </div>`;
          
          // Recent learning (Column 3)
          const recentElement = document.getElementById('recent-stats');
          if (recentElement) {
            // Combine learning and correction history, sort by timestamp
            const allHistory = [
              ...(analytics.learningHistory || []).map(e => ({ ...e, type: 'learn' })),
              ...(analytics.correctionHistory || []).map(e => ({ ...e, type: 'correct' }))
            ].sort((a, b) => b.timestamp - a.timestamp).slice(0, 2);
            
            if (allHistory.length > 0) {
              let recentHtml = '';
              allHistory.forEach(entry => {
                const time = new Date(entry.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                const label = entry.label.replace('the ', '');
                if (entry.type === 'correct') {
                  recentHtml += `<div class="recent-item" style="color: #FF9800;">- ${time}: ✓${entry.correctedCount} ${label}</div>`;
                } else {
                  recentHtml += `<div class="recent-item">- ${time}: +${entry.hashesLearned} ${label}</div>`;
                }
              });
              recentElement.innerHTML = recentHtml;
            } else {
              recentElement.innerHTML = '<div class="stats-value">No data</div>';
            }
          }
        } else {
          analyticsElement.innerHTML = '<div class="stats-value">No data</div>';
          const recentElement = document.getElementById('recent-stats');
          if (recentElement) {
            recentElement.innerHTML = '<div class="stats-value">No data</div>';
          }
        }
      }
      
    }).catch(error => {
      console.error('❌ Error in loadCompactStats:', error);
      
      // Show error state in UI
      ['db-main-stats', 'analytics-stats', 'recent-stats'].forEach(id => {
        const element = document.getElementById(id);
        if (element) {
          element.innerHTML = '<div class="stats-value" style="color: #f44336;">Error</div>';
        }
      });
    });
  }

  function loadTiles() {
    if (!chrome || !chrome.storage) return;

    chrome.storage.local.get(['captchaTiles', 'lastCaptured', 'captchaInstruction', 'captchaClickedPositions', 'tilesForLearning'], function(result) {
      if (chrome.runtime.lastError) return;

      const tilesContainer = document.getElementById('tiles-container');
      const summaryDiv = document.getElementById('captcha-summary');
      tilesContainer.innerHTML = '';
      summaryDiv.innerHTML = '';
      
      // ✅ NEW: Reset summary styling
      summaryDiv.className = 'captcha-summary';

      if (!result.captchaTiles || result.captchaTiles.length === 0) {
        summaryDiv.innerHTML = '<div class="captcha-title">No CAPTCHA tiles analyzed</div>';
        return;
      }

      const labelCount = {};
      const clickedPositions = result.captchaClickedPositions || [];
      const learningTiles = result.tilesForLearning || [];
      result.captchaTiles.forEach(tile => {
        let label = 'unknown';
        if (tile.matchResult && tile.matchResult.found) {
          label = tile.matchResult.match.folder;
        }
        labelCount[label] = (labelCount[label] || 0) + 1;
      });

      let summaryHtml = '';
      if (result.captchaInstruction) {
        summaryHtml += `<div class="captcha-title">${result.captchaInstruction}</div>`;
      }
      const analysisItems = Object.entries(labelCount).map(([label, count]) => {
        const shortLabel = label.replace('the ', '');
        return `<span class="analysis-item">${count} ${shortLabel}</span>`;
      }).join('');
      let strategyText = `${clickedPositions.length} clicks`;
      if (learningTiles.length > 0) {
        strategyText += ` | ${learningTiles.length} learn`;
      }
      summaryHtml += `<div class="analysis-items">${analysisItems}</div><div class="strategy-info">${strategyText}</div>`;
      summaryDiv.innerHTML = summaryHtml;

      result.captchaTiles.forEach((tile, index) => {
        const tileDiv = document.createElement('div');
        tileDiv.className = 'tile';
        const img = document.createElement('img');
        img.src = tile.dataURL;
        tileDiv.appendChild(img);

        const [row, col] = tile.position.split('_').map(Number);
        const isClicked = clickedPositions.some(pos => pos.row === row && pos.col === col);
        const isForLearning = learningTiles.some(item => item.tile && item.tile.position === tile.position);

        if (tile.matchResult && tile.matchResult.found) {
          const matchInfo = document.createElement('div');
          matchInfo.className = 'match-info';
          const shortLabel = tile.matchResult.match.folder.replace('the ', '');
          matchInfo.innerHTML = `<div class="match-folder">${shortLabel}</div><div>${tile.matchResult.match.confidence}%</div>`;
          tileDiv.appendChild(matchInfo);
        } else if (isForLearning) {
          const info = document.createElement('div');
          info.className = 'match-info';
          info.style.background = 'rgba(255, 152, 0, 0.9)';
          info.innerHTML = `<div class="match-folder">Learning</div>`;
          tileDiv.appendChild(info);
        } else {
          const info = document.createElement('div');
          info.className = 'match-info';
          info.style.background = 'rgba(158, 158, 158, 0.9)';
          info.innerHTML = `<div class="match-folder">Unknown</div>`;
          tileDiv.appendChild(info);
        }

        if (isClicked) {
          tileDiv.style.border = isForLearning ? '2px solid #FF9800' : '2px solid #4CAF50';
          tileDiv.style.boxShadow = isForLearning ? '0 0 8px rgba(255, 152, 0, 0.5)' : '0 0 8px rgba(76, 175, 80, 0.5)';
        }
        tilesContainer.appendChild(tileDiv);
      });

      if (result.lastCaptured) {
        const lastUpdated = document.getElementById('last-updated');
        if (lastUpdated) {
          lastUpdated.textContent = `Last: ${new Date(result.lastCaptured).toLocaleTimeString()}`;
        }
      }
    });
    
    // ✅ NEW: Check for cooldown status from content script
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getCooldownStatus' }, (response) => {
          if (chrome.runtime.lastError) return;
          
          const summaryDiv = document.getElementById('captcha-summary');
          if (!summaryDiv) return;
          
          if (response && response.isInCooldown) {
            summaryDiv.className = 'captcha-summary cooldown';
            const cooldownMsg = `<div class="captcha-title">⏸️ Cooldown Mode</div><div style="font-size: 11px;">Too many failures (${response.consecutiveFailures}). Paused for ${Math.ceil(response.remainingTime/1000)}s</div>`;
            if (summaryDiv.innerHTML === '<div class="captcha-title">No CAPTCHA tiles analyzed</div>') {
              summaryDiv.innerHTML = cooldownMsg;
            }
          } else if (response && response.consecutiveFailures > 0) {
            summaryDiv.className = 'captcha-summary error';
          }
        });
      }
    });
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'refresh-captcha' }, (response) => {
            loadTiles();
            loadCompactStats();
          });
        } else {
          loadTiles();
          loadCompactStats();
        }
      });
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', function() {
      if (confirm('Hapus semua tile yang tertangkap?')) {
        chrome.storage.local.remove(['captchaTiles', 'lastCaptured', 'captchaInstruction', 'captchaClickedPositions', 'tilesForLearning'], () => {
          if (!chrome.runtime.lastError) {
            loadTiles();
            loadCompactStats();
          }
        });
      }
    });
  }
  
  if (clickBtn) {
    clickBtn.addEventListener('click', function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'click-captcha' });
        }
      });
    });
  }

  if (viewDataBtn) {
    viewDataBtn.addEventListener('click', () => chrome.tabs.create({ url: 'viewer.html' }));
  }

  if (analyticsBtn) {
    analyticsBtn.addEventListener('click', () => chrome.tabs.create({ url: 'analytics.html' }));
  }

  if (clearDbBtn) {
    clearDbBtn.addEventListener('click', function() {
      if (confirm('Hapus semua data yang telah dipelajari? Aksi ini tidak bisa dibatalkan.')) {
        setButtonLoading(clearDbBtn, true);
        
        chrome.runtime.sendMessage({ action: 'clearLearnedDatabase' }, function(response) {
          setButtonLoading(clearDbBtn, false);
          
          if (response && response.success) {
            setTimeout(() => {
              loadCompactStats();
              loadTiles();
            }, 100);
            alert('Database pembelajaran lokal telah dihapus!');
          } else {
            alert('Gagal menghapus database: ' + (response?.error || 'Unknown error'));
          }
        });
      }
    });
  }

  if (rebuildAnalyticsBtn) {
    rebuildAnalyticsBtn.addEventListener('click', function() {
      setButtonLoading(rebuildAnalyticsBtn, true);
      
      chrome.runtime.sendMessage({ action: 'rebuildAnalytics' }, function(response) {
        setButtonLoading(rebuildAnalyticsBtn, false);
        
        if (response && response.success) {
          setTimeout(() => {
            loadCompactStats();
            loadTiles();
          }, 100);
          alert(response.message || 'Analitik berhasil dibangun ulang!');
        } else {
          alert('Gagal membangun ulang analitik: ' + (response?.error || 'Unknown error'));
        }
      });
    });
  }
  
  if (debugBtn) {
    debugBtn.addEventListener('click', () => chrome.tabs.create({ url: 'debug.html' }));
  }
  
  // Listen for storage changes
  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'local') {
      loadTiles();
      loadCompactStats();
    }
  });
});