// background.js - Versi Offline Penuh dengan Improved Initialization

// Global state untuk memastikan inisialisasi hanya terjadi sekali
let isInitializing = false;
let initializationPromise = null;

// Fungsi inisialisasi yang aman dari race condition
async function ensureInitialization() {
  // Jika sudah ada proses inisialisasi berjalan, tunggu selesai
  if (initializationPromise) {
    return initializationPromise;
  }

  const result = await chrome.storage.local.get(['isInitialized', 'databaseMode', 'lastInitialized']);
  if (result.isInitialized && result.databaseMode === 'file' && result.lastInitialized) {
    return true;
  }

  // Mulai proses inisialisasi
  if (isInitializing) {
    return false;
  }

  isInitializing = true;

  initializationPromise = (async () => {
    try {
      await chrome.storage.local.set({ isInitialized: false });
      
      const response = await fetch(chrome.runtime.getURL('database.json'), { method: 'HEAD' });
      if (!response.ok) {
        throw new Error(`Failed to verify database.json: ${response.status}`);
      }

      // Preserve existing learned data if any
      const existingData = await chrome.storage.local.get(['learnedDatabase', 'learningAnalytics']);
      
      await chrome.storage.local.set({
        // ✅ REMOVED: hashDatabase - will be loaded on-demand from file
        learnedDatabase: existingData.learnedDatabase || {},
        hashSettings: {
          width: 9,
          height: 8,
          algorithm: 'dhash',
          threshold: 10
        },
        learningAnalytics: existingData.learningAnalytics || {
          totalLearned: 0,
          totalCorrected: 0,
          successUnknown: 0, // ✅ NEW: CAPTCHA sukses dengan unknown tiles
          successWrongCategory: 0, // ✅ NEW: CAPTCHA sukses dengan wrongCategory tiles
          successfulCaptchas: 0, // Total (untuk backward compatibility)
          learningHistory: [],
          correctionHistory: [],
          captchaHistory: [], // ✅ NEW: Complete CAPTCHA history with tiles distribution
          labelStats: {}
        },
        isInitialized: true,
        lastInitialized: Date.now(),
        databaseMode: 'file' // ✅ Flag to indicate we're using file-based loading
      });

      return true;

    } catch (error) {
      console.error('❌ Error during extension initialization:', error);
      await chrome.storage.local.set({
        // ✅ REMOVED: hashDatabase
        learnedDatabase: {},
        hashSettings: {
          width: 9,
          height: 8,
          algorithm: 'dhash',
          threshold: 10
        },
        learningAnalytics: {
          totalLearned: 0,
          totalCorrected: 0,
          successUnknown: 0,
          successWrongCategory: 0,
          successfulCaptchas: 0,
          learningHistory: [],
          correctionHistory: [],
          captchaHistory: [], // ✅ NEW: Complete CAPTCHA history with tiles distribution
          labelStats: {}
        },
        isInitialized: true,
        initializationError: true,
        lastInitialized: Date.now(),
        databaseMode: 'file'
      });
      return false;
    } finally {
      isInitializing = false;
    }
  })();

  return initializationPromise;
}

chrome.runtime.onInstalled.addListener(async (details) => {
  await ensureInitialization();
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureInitialization();
});

(async () => {
  await ensureInitialization();
})();

// >>> IMPROVED KEEP-ALIVE SYSTEM <<<
const KEEP_ALIVE_ALARM_NAME = 'keepAliveAlarm';

function setupAlarms() {
  chrome.alarms.get(KEEP_ALIVE_ALARM_NAME, (alarm) => {
    if (!alarm) {
      chrome.alarms.create(KEEP_ALIVE_ALARM_NAME, { 
        delayInMinutes: 0.5,
        periodInMinutes: 0.5
      });
    }
  });
}

// Setup alarms on various events
chrome.runtime.onInstalled.addListener(setupAlarms);
chrome.runtime.onStartup.addListener(setupAlarms);

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === KEEP_ALIVE_ALARM_NAME) {
    try {
      const result = await chrome.storage.local.get(['isInitialized', 'lastInitialized']);
      if (!result.isInitialized || !result.lastInitialized) {
        await ensureInitialization();
      }
    } catch (error) {
      console.error('❌ Keep-alive error:', error);
    }
  }
});
// >>> END KEEP-ALIVE SYSTEM <<<

// Fungsi bantuan untuk akses storage yang aman
function safeStorageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result);
      }
    });
  });
}

function safeStorageSet(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const handleWithInitialization = async (handler) => {
    try {
      await ensureInitialization();
      return await handler();
    } catch (error) {
      console.error('❌ Error in message handler:', error);
      return { success: false, error: error.message };
    }
  };

  if (request.action === 'ensureInitialization') {
    ensureInitialization().then((success) => {
      sendResponse({ success, initialized: true });
    }).catch((error) => {
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }

  if (request.action === 'learnMultipleHashes') {
    handleWithInitialization(async () => {
      const { hashes, label, confidence, corrections, tilesDistribution, totalClicked } = request;

      // ✅ FIX: Allow request even if no hashes/corrections (for captchaHistory tracking)
      const hasHashes = hashes && hashes.length > 0;
      const hasCorrections = corrections && corrections.length > 0;
      
      if (!label) {
        return { success: false, error: 'Parameter tidak valid' };
      }

      const result = await safeStorageGet(['learnedDatabase', 'learningAnalytics']);
      const database = result.learnedDatabase || {};
      const analytics = result.learningAnalytics || {
        totalLearned: 0,
        totalCorrected: 0,
        successUnknown: 0,
        successWrongCategory: 0,
        successfulCaptchas: 0,
        learningHistory: [],
        correctionHistory: [],
        captchaHistory: [],
        labelStats: {}
      };

      // Ensure new fields exist for older analytics
      if (typeof analytics.totalCorrected === 'undefined') analytics.totalCorrected = 0;
      if (typeof analytics.successUnknown === 'undefined') analytics.successUnknown = 0;
      if (typeof analytics.successWrongCategory === 'undefined') analytics.successWrongCategory = 0;
      if (!analytics.correctionHistory) analytics.correctionHistory = [];
      if (!analytics.captchaHistory) analytics.captchaHistory = [];

      let newHashesAdded = 0;
      let correctedCount = 0;
      const duplicateHashes = [];
      const correctionDetails = [];

      // ✅ FIX: Only process if hashes array exists
      if (hashes && hashes.length > 0) {
        for (const dhash of hashes) {
          if (dhash && typeof dhash === 'string' && dhash.length > 0) {
            if (!database[dhash]) {
              database[dhash] = label;
              newHashesAdded++;
            } else {
              duplicateHashes.push(dhash);
            }
          }
        }
      }

      // ✅ NEW: Process corrections (wrong category tiles that were corrected)
      if (corrections && corrections.length > 0) {
        for (const correction of corrections) {
          if (correction.hash && correction.newLabel && correction.oldLabel) {
            // Update database with correct label
            database[correction.hash] = correction.newLabel;
            correctedCount++;
            correctionDetails.push({
              hash: correction.hash.substring(0, 16) + '...', // Truncate for storage
              from: correction.oldLabel,
              to: correction.newLabel
            });
          }
        }
      }

      if (newHashesAdded > 0 || correctedCount > 0) {
        analytics.successfulCaptchas += 1;

        if (!analytics.labelStats[label]) {
          analytics.labelStats[label] = { count: 0, corrected: 0, lastUpdated: Date.now() };
        }
        
        // Update learned stats (unknown tiles)
        if (newHashesAdded > 0) {
          analytics.totalLearned += newHashesAdded;
          analytics.successUnknown += 1; // ✅ NEW: Count success with unknown tiles
          analytics.labelStats[label].count += newHashesAdded;
          analytics.labelStats[label].lastUpdated = Date.now();

          analytics.learningHistory.unshift({
            timestamp: Date.now(),
            label: label,
            hashesLearned: newHashesAdded,
            confidence: confidence || null,
            duplicates: duplicateHashes.length
          });

          if (analytics.learningHistory.length > 50) {
            analytics.learningHistory = analytics.learningHistory.slice(0, 50);
          }
        }

        // Update correction stats (wrongCategory tiles)
        if (correctedCount > 0) {
          analytics.totalCorrected += correctedCount;
          analytics.successWrongCategory += 1; // ✅ NEW: Count success with wrongCategory tiles
          analytics.labelStats[label].corrected = (analytics.labelStats[label].corrected || 0) + correctedCount;

          analytics.correctionHistory.unshift({
            timestamp: Date.now(),
            label: label,
            correctedCount: correctedCount,
            details: correctionDetails
          });

          if (analytics.correctionHistory.length > 50) {
            analytics.correctionHistory = analytics.correctionHistory.slice(0, 50);
          }
        }
      }

      // ✅ NEW: Only save to captchaHistory if there's learning or correction
      if (tilesDistribution && Object.keys(tilesDistribution).length > 0 && (newHashesAdded > 0 || correctedCount > 0)) {
        analytics.captchaHistory.unshift({
          timestamp: Date.now(),
          label: label,
          tilesDistribution: tilesDistribution,
          totalClicked: totalClicked || 0,
          learned: newHashesAdded,
          corrected: correctedCount,
          corrections: correctionDetails.length > 0 ? correctionDetails : null
        });

        if (analytics.captchaHistory.length > 50) {
          analytics.captchaHistory = analytics.captchaHistory.slice(0, 50);
        }
      }

      await safeStorageSet({ learnedDatabase: database, learningAnalytics: analytics });
      
      return {
        success: true,
        count: newHashesAdded,
        corrected: correctedCount,
        duplicates: duplicateHashes.length,
        totalInDatabase: Object.keys(database).length
      };
    }).then(response => sendResponse(response));
    return true;
  }

  if (request.action === 'getLearningAnalytics') {
    safeStorageGet(['learningAnalytics', 'learnedDatabase'])
      .then(result => {
        let analytics = result.learningAnalytics || {
          totalLearned: 0,
          totalCorrected: 0,
          successUnknown: 0,
          successWrongCategory: 0,
          successfulCaptchas: 0,
          learningHistory: [],
          correctionHistory: [],
          captchaHistory: [],
          labelStats: {}
        };
        
        // Ensure new fields exist for older analytics
        if (typeof analytics.totalCorrected === 'undefined') analytics.totalCorrected = 0;
        if (typeof analytics.successUnknown === 'undefined') analytics.successUnknown = 0;
        if (typeof analytics.successWrongCategory === 'undefined') analytics.successWrongCategory = 0;
        if (!analytics.correctionHistory) analytics.correctionHistory = [];
        if (!analytics.captchaHistory) analytics.captchaHistory = [];
        
        const learnedDb = result.learnedDatabase || {};
        const learnedCount = Object.keys(learnedDb).length;

        // Hitung ulang jika analytics kosong tapi DB sudah ada isinya
        if (learnedCount > 0 && analytics.totalLearned === 0) {
          console.log('Menghitung ulang analitik dari database yang ada...');
          const labelStats = {};
          Object.values(learnedDb).forEach(label => {
            labelStats[label] = {
              count: (labelStats[label]?.count || 0) + 1,
              corrected: 0,
              lastUpdated: Date.now()
            };
          });
          analytics.totalLearned = learnedCount;
          analytics.successfulCaptchas = Math.ceil(learnedCount / 5);
          analytics.successUnknown = Math.ceil(learnedCount / 5); // ✅ FIX: Estimate from learned count
          analytics.labelStats = labelStats;
        }
        
        // ✅ FIX: Jika successUnknown masih 0 tapi totalLearned > 0, estimasi dari data yang ada
        if (analytics.successUnknown === 0 && analytics.totalLearned > 0) {
          analytics.successUnknown = analytics.learningHistory ? analytics.learningHistory.length : Math.ceil(analytics.totalLearned / 5);
        }
        
        // ✅ FIX: Jika successWrongCategory masih 0 tapi totalCorrected > 0, estimasi dari data yang ada
        if (analytics.successWrongCategory === 0 && analytics.totalCorrected > 0) {
          analytics.successWrongCategory = analytics.correctionHistory ? analytics.correctionHistory.length : Math.ceil(analytics.totalCorrected / 3);
        }
        
        const dbSize = result.learnedDatabase ? Object.keys(result.learnedDatabase).length : 0;

        sendResponse({
          success: true,
          analytics: {
            ...analytics,
            currentDatabaseSize: dbSize,
            uniqueLabels: Object.keys(analytics.labelStats || {}).length,
          }
        });
      })
      .catch(error => {
        console.error('Error saat mengambil analitik:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  if (request.action === 'clearLearnedDatabase') {
    safeStorageSet({
      learnedDatabase: {},
      learningAnalytics: {
        totalLearned: 0,
        totalCorrected: 0,
        successUnknown: 0,
        successWrongCategory: 0,
        successfulCaptchas: 0,
        learningHistory: [],
        correctionHistory: [],
        captchaHistory: [],
        labelStats: {}
      }
    })
    .then(() => {
      console.log('Database pembelajaran lokal telah dihapus.');
      sendResponse({ success: true, message: 'Database lokal berhasil dihapus' });
    })
    .catch(error => {
      console.error('Gagal menghapus database:', error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }

  if (request.action === 'rebuildAnalytics') {
    console.log('Membangun ulang analitik dari database pembelajaran...');
    safeStorageGet(['learnedDatabase'])
      .then(async (result) => {
        const learnedDb = result.learnedDatabase || {};
        const learnedCount = Object.keys(learnedDb).length;
        const labelStats = {};
        Object.values(learnedDb).forEach(label => {
          labelStats[label] = {
            count: (labelStats[label]?.count || 0) + 1,
            lastUpdated: Date.now()
          };
        });

        const rebuiltAnalytics = {
          totalLearned: learnedCount,
          totalCorrected: 0, // Cannot recover correction count from rebuild
          successUnknown: 0, // Cannot recover from rebuild
          successWrongCategory: 0, // Cannot recover from rebuild
          successfulCaptchas: Math.ceil(learnedCount / 5),
          learningHistory: [{
            timestamp: Date.now(),
            label: 'ANALYTICS_REBUILT',
            hashesLearned: learnedCount,
            confidence: null
          }],
          correctionHistory: [],
          captchaHistory: [], // Cannot recover from rebuild
          labelStats: labelStats,
          lastUpdate: Date.now()
        };

        await safeStorageSet({ learningAnalytics: rebuiltAnalytics });
        sendResponse({
          success: true,
          analytics: rebuiltAnalytics,
          message: `Analitik berhasil dibangun ulang: ${learnedCount} pola, ${Object.keys(labelStats).length} kategori`
        });
      })
      .catch(error => {
        console.error('Gagal membangun ulang analitik:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  return false;
});