// Debug Console JavaScript
document.addEventListener('DOMContentLoaded', function() {
  const logContainer = document.getElementById('log-container');
  
  function addLog(message, type = 'info') {
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry ${type}`;
    logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    logContainer.appendChild(logEntry);
    logContainer.scrollTop = logContainer.scrollHeight;
    
    // Keep only last 100 logs
    if (logContainer.children.length > 100) {
      logContainer.removeChild(logContainer.firstChild);
    }
  }

  function updateStatus(elementId, text, status = 'info') {
    const element = document.getElementById(elementId);
    const textElement = element.querySelector('div');
    textElement.textContent = text;
    
    element.className = `status-card ${status}`;
  }

  async function checkChromeAPIs() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.runtime) {
        updateStatus('chrome-apis-status', '✅ Available', 'success');
        addLog('Chrome APIs are available', 'success');
        return true;
      } else {
        updateStatus('chrome-apis-status', '❌ Not Available', 'error');
        addLog('Chrome APIs are not available', 'error');
        return false;
      }
    } catch (error) {
      updateStatus('chrome-apis-status', '❌ Error: ' + error.message, 'error');
      addLog('Error checking Chrome APIs: ' + error.message, 'error');
      return false;
    }
  }

  async function checkBackgroundScript() {
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { action: 'ensureInitialization' },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({ success: false, error: chrome.runtime.lastError.message });
            } else {
              resolve(response || { success: false, error: 'No response' });
            }
          }
        );
      });

      if (response.success) {
        updateStatus('background-status', '✅ Initialized', 'success');
        addLog('Background script is initialized', 'success');
        return true;
      } else {
        updateStatus('background-status', '❌ Error: ' + (response.error || 'Unknown'), 'error');
        addLog('Background script error: ' + (response.error || 'Unknown'), 'error');
        return false;
      }
    } catch (error) {
      updateStatus('background-status', '❌ Error: ' + error.message, 'error');
      addLog('Error checking background script: ' + error.message, 'error');
      return false;
    }
  }

  async function checkDatabase() {
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['hashDatabase', 'learnedDatabase', 'isInitialized'], resolve);
      });

      const mainDbSize = result.hashDatabase ? Object.keys(result.hashDatabase).length : 0;
      const learnedDbSize = result.learnedDatabase ? Object.keys(result.learnedDatabase).length : 0;
      
      if (result.isInitialized && mainDbSize > 0) {
        updateStatus('database-status', `✅ Main: ${mainDbSize}, Learned: ${learnedDbSize}`, 'success');
        addLog(`Database loaded - Main: ${mainDbSize}, Learned: ${learnedDbSize}`, 'success');
        return true;
      } else {
        updateStatus('database-status', '❌ Not loaded or empty', 'error');
        addLog('Database not loaded or empty', 'error');
        return false;
      }
    } catch (error) {
      updateStatus('database-status', '❌ Error: ' + error.message, 'error');
      addLog('Error checking database: ' + error.message, 'error');
      return false;
    }
  }

  async function checkContentScript() {
    try {
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      if (tabs.length === 0) {
        updateStatus('content-status', '❌ No active tab', 'warning');
        addLog('No active tab found', 'warning');
        return false;
      }

      const tab = tabs[0];
      if (!tab.url.includes('studiolab.sagemaker.aws')) {
        updateStatus('content-status', '⚠️ Wrong domain', 'warning');
        addLog('Active tab is not on target domain', 'warning');
        return false;
      }

      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, { action: 'ping' }, (response) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
          } else {
            resolve(response || { success: true });
          }
        });
      });

      if (response.success !== false) {
        updateStatus('content-status', '✅ Active on target domain', 'success');
        addLog('Content script is active on target domain', 'success');
        
        // ✅ NEW: Check cooldown status
        await checkCooldownStatus(tab.id);
        
        return true;
      } else {
        updateStatus('content-status', '❌ Not responding', 'error');
        addLog('Content script not responding: ' + (response.error || 'Unknown'), 'error');
        return false;
      }
    } catch (error) {
      updateStatus('content-status', '❌ Error: ' + error.message, 'error');
      addLog('Error checking content script: ' + error.message, 'error');
      return false;
    }
  }
  
  // ✅ NEW: Check cooldown status
  async function checkCooldownStatus(tabId) {
    try {
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tabId, { action: 'getCooldownStatus' }, (response) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false });
          } else {
            resolve(response || { success: false });
          }
        });
      });

      if (response.success) {
        if (response.isInCooldown) {
          const remainingSecs = Math.ceil(response.remainingTime / 1000);
          updateStatus('cooldown-status', `⏸️ Active (${response.consecutiveFailures} failures, ${remainingSecs}s remaining)`, 'warning');
          addLog(`Cooldown active: ${response.consecutiveFailures} failures, ${remainingSecs}s remaining`, 'warning');
        } else if (response.consecutiveFailures > 0) {
          updateStatus('cooldown-status', `⚠️ ${response.consecutiveFailures} recent failures`, 'warning');
          addLog(`Recent failures: ${response.consecutiveFailures}`, 'warning');
        } else {
          updateStatus('cooldown-status', '✅ No cooldown', 'success');
          addLog('No cooldown active', 'success');
        }
      } else {
        updateStatus('cooldown-status', '⚠️ Unable to check', 'warning');
      }
    } catch (error) {
      updateStatus('cooldown-status', '❌ Error checking', 'error');
      addLog('Error checking cooldown: ' + error.message, 'error');
    }
  }

  async function refreshStatus() {
    addLog('Refreshing all status checks...', 'info');
    
    const chromeOk = await checkChromeAPIs();
    if (!chromeOk) return;
    
    await checkBackgroundScript();
    await checkDatabase();
    await checkContentScript();
    
    addLog('Status refresh completed', 'info');
  }

  async function forceInitialize() {
    addLog('Forcing extension initialization...', 'info');
    
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { action: 'ensureInitialization' },
          resolve
        );
      });

      if (response && response.success) {
        addLog('Force initialization successful', 'success');
      } else {
        addLog('Force initialization failed: ' + (response?.error || 'Unknown error'), 'error');
      }
    } catch (error) {
      addLog('Force initialization error: ' + error.message, 'error');
    }
    
    // Refresh status after force init
    setTimeout(refreshStatus, 2000);
  }

  async function testCaptchaDetection() {
    addLog('Testing CAPTCHA detection...', 'info');
    
    try {
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      if (tabs.length === 0) {
        addLog('No active tab for testing', 'error');
        return;
      }

      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'test-detection' }, resolve);
      });

      if (response && response.success) {
        addLog('CAPTCHA detection test successful', 'success');
      } else {
        addLog('CAPTCHA detection test failed: ' + (response?.error || 'Unknown'), 'error');
      }
    } catch (error) {
      addLog('CAPTCHA detection test error: ' + error.message, 'error');
    }
  }

  function clearLogs() {
    logContainer.innerHTML = '<div class="log-entry info">Debug console cleared...</div>';
  }

  // Event listeners
  document.getElementById('refresh-status').addEventListener('click', refreshStatus);
  document.getElementById('force-init').addEventListener('click', forceInitialize);
  document.getElementById('test-captcha').addEventListener('click', testCaptchaDetection);
  document.getElementById('clear-logs').addEventListener('click', clearLogs);

  // Initial status check
  setTimeout(refreshStatus, 1000);
  
  // Periodic status refresh
  setInterval(refreshStatus, 30000); // Every 30 seconds
});