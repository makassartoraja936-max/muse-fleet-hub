// util: deep selector yang menembus shadowRoot
function deepQuerySelector(selector) {
  function dfs(root) {
    const el = root.querySelector(selector);
    if (el) return el;
    for (const node of root.querySelectorAll('*')) {
      if (node.shadowRoot) {
        const found = dfs(node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  return dfs(document);
}

// Helper to search for a canvas within nested shadowRoots
function findCanvasInShadow(root) {
  if (!root) return null;
  const direct = root.querySelector('canvas');
  if (direct) return direct;
  for (const node of root.querySelectorAll('*')) {
    if (node.shadowRoot) {
      const found = findCanvasInShadow(node.shadowRoot);
      if (found) return found;
    }
  }
  return null;
}

function isElementVisible(el) {
  try {
    if (!el) return false;
    const rects = el.getClientRects();
    return rects && rects.length > 0 && el.offsetParent !== null;
  } catch (_) {
    return false;
  }
}

// Function to check if Chrome APIs are available
function isChromeExtensionContext() {
  return typeof chrome !== 'undefined' && 
         chrome.storage && 
         chrome.storage.local && 
         chrome.runtime;
}

// Enhanced function to wait for Chrome APIs to be available
function waitForChromeAPIs(maxWait = 10000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    
    function checkAPIs() {
      if (isChromeExtensionContext()) {
        // console.log('✅ Chrome APIs are available');
        resolve(true);
      } else if (Date.now() - startTime > maxWait) {
        console.error('❌ Chrome APIs not available after timeout');
        reject(new Error('Chrome APIs not available after timeout'));
      } else {
        // console.log('⏳ Waiting for Chrome APIs...');
        setTimeout(checkAPIs, 200); // Check more frequently
      }
    }
    
    checkAPIs();
  });
}

// Enhanced function to wait for background script initialization
async function waitForInitialization(maxWait = 15000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    let attempts = 0;
    
    const checkInitialization = async () => {
      attempts++;
      
      try {
        const response = await new Promise((resolveMsg) => {
          chrome.runtime.sendMessage(
            { action: 'ensureInitialization' }, 
            (response) => {
              if (chrome.runtime.lastError) {
                resolveMsg({ success: false });
              } else {
                resolveMsg(response || { success: false });
              }
            }
          );
        });
        
        if (response.success) {
          const result = await new Promise((resolveStorage) => {
            chrome.storage.local.get(['isInitialized', 'databaseMode'], (result) => {
              if (chrome.runtime.lastError) {
                resolveStorage({ isInitialized: false });
              } else {
                resolveStorage(result);
              }
            });
          });
          
          if (result.isInitialized && result.databaseMode === 'file') {
            resolve(true);
            return;
          }
        }
        
        if (Date.now() - startTime > maxWait) {
          reject(new Error('Background script initialization timeout'));
          return;
        }
        
        setTimeout(checkInitialization, 1000);
        
      } catch (error) {
        if (Date.now() - startTime > maxWait) {
          reject(error);
        } else {
          setTimeout(checkInitialization, 1000);
        }
      }
    };
    
    checkInitialization();
  });
}

// Compute dHash for an image
function computeDHash(imgElement, width = 9, height = 8) {
  return new Promise((resolve, reject) => {
    try {
      if (!imgElement || !(imgElement instanceof HTMLImageElement)) {
        throw new Error('Invalid image element');
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Failed to get canvas context');
      }
      ctx.drawImage(imgElement, 0, 0, width, height);
      const imageData = ctx.getImageData(0, 0, width, height);
      const pixels = imageData.data;
      const grayscale = [];
      for (let i = 0; i < pixels.length; i += 4) {
        const gray = 0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2];
        grayscale.push(gray);
      }
      let hash = '';
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width - 1; x++) {
          const idx = y * width + x;
          hash += grayscale[idx] < grayscale[idx + 1] ? '1' : '0';
        }
      }
      resolve(hash);
    } catch (error) {
      reject(error);
    }
  });
}

// Load and initialize database from JSON file
let hashDatabase = {};
let isDatabaseLoaded = false;
let databaseLoadPromise = null;

// ✅ FIXED: Load database on-demand from file, not from chrome.storage
function loadDatabase() {
  if (databaseLoadPromise) {
    return databaseLoadPromise;
  }

  if (isDatabaseLoaded && Object.keys(hashDatabase).length > 0) {
    return Promise.resolve();
  }
  
  databaseLoadPromise = fetch(chrome.runtime.getURL('database.json'))
    .then(response => {
      if (!response.ok) {
        throw new Error(`Failed to load database.json: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      hashDatabase = data;
      isDatabaseLoaded = true;
      dbCache.signature = null;
      dbCache.entries = null;
      databaseLoadPromise = null;
    })
    .catch(error => {
      console.error('❌ Failed to load database.json:', error);
      hashDatabase = {};
      isDatabaseLoaded = false;
      databaseLoadPromise = null;
      throw error;
    });

  return databaseLoadPromise;
}

// Safe storage access function
function safeStorageGet(keys) {
  return new Promise((resolve, reject) => {
    if (!isChromeExtensionContext()) {
      reject(new Error('Chrome APIs not available'));
      return;
    }

    chrome.storage.local.get(keys, (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result);
      }
    });
  });
}

function safeStorageSet(data) {
  return new Promise((resolve, reject) => {
    if (!isChromeExtensionContext()) {
      reject(new Error('Chrome APIs not available'));
      return;
    }

    chrome.storage.local.set(data, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

// === Optimized Hamming helpers and DB cache ===
// Convert binary-string (e.g., 64 bits) to BigInt
function binaryStringToBigInt(bin) {
  try {
    return BigInt('0b' + bin);
  } catch (e) {
    return null;
  }
}

// Popcount via Brian Kernighan's algorithm with early-exit
function hammingDistanceBigInt(aBits, bBits, maxDistance) {
  let x = aBits ^ bBits;
  let count = 0;
  while (x !== 0n) {
    x &= (x - 1n);
    count++;
    if (maxDistance != null && count > maxDistance) {
      return count;
    }
  }
  return count;
}

// Cache for combined DB entries (pre-parsed to BigInt)
let dbCache = {
  signature: null,
  entries: null
};

// Estimasi jarak minimal sebuah tile (hash) ke label target menggunakan entri DB ter-cache
function estimateDistanceToLabel(hashStr, keyword, maxDistance = 64) {
  try {
    if (!hashStr || !keyword || !dbCache.entries) return null;
    const hBits = binaryStringToBigInt(hashStr);
    if (hBits === null) return null;
    let best = maxDistance;
    const key = keyword.toLowerCase();
    for (const entry of dbCache.entries) {
      if (!entry.bits) continue;
      if (!entry.folder || !entry.folder.toLowerCase().includes(key)) continue;
      const d = hammingDistanceBigInt(hBits, entry.bits, best);
      if (d < best) best = d;
      if (best === 0) break;
    }
    return best;
  } catch (_) {
    return null;
  }
}

// Fungsi untuk memeriksa database (dioptimalkan untuk menerima 2 database)
async function checkDatabase(dataURL, learnedDb, mainDb, settings) {
  try {
    const img = new Image();
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = dataURL;
    });

    const dhash = await computeDHash(img, settings.width, settings.height);
    const dhashBits = binaryStringToBigInt(dhash);
    // Build cached combined entries (once per DB size change)
    const signature = `${Object.keys(mainDb || {}).length}:${Object.keys(learnedDb || {}).length}`;
    if (!dbCache.entries || dbCache.signature !== signature) {
      const combinedDb = { ...(mainDb || {}), ...(learnedDb || {}) };
      dbCache.entries = Object.entries(combinedDb).map(([hashStr, folder]) => ({
        bits: binaryStringToBigInt(hashStr),
        folder,
        hash: hashStr
      }));
      dbCache.signature = signature;
    }

    const threshold = settings.threshold || 10;
    const matches = [];

    for (const entry of dbCache.entries) {
      if (entry.bits === null) continue;
      const distance = hammingDistanceBigInt(dhashBits, entry.bits, threshold);
      if (distance <= threshold) {
        matches.push({
          folder: entry.folder,
          hash: entry.hash,
          distance: distance,
          confidence: Math.round(100 * (1 - distance / 64))
        });
      }
    }

    matches.sort((a, b) => a.distance - b.distance);
    const folderMatches = {};
    matches.forEach(match => {
      if (!folderMatches[match.folder]) {
        folderMatches[match.folder] = {
          count: 0,
          matches: []
        };
      }
      folderMatches[match.folder].count++;
      folderMatches[match.folder].matches.push(match);
    });

    let bestFolder = null;
    let maxCount = 0;
    Object.entries(folderMatches).forEach(([folder, info]) => {
      if (info.count > maxCount) {
        maxCount = info.count;
        bestFolder = folder;
      }
    });

    if (bestFolder && maxCount >= 3) {
      const bestMatch = folderMatches[bestFolder].matches[0];
      return {
        found: true,
        match: {
          folder: bestFolder,
          distance: bestMatch.distance,
          hash: bestMatch.hash,
          confidence: bestMatch.confidence,
          duplicateCount: maxCount
        },
        hash: dhash
      };
    } else {
      return {
        found: false,
        hash: dhash
      };
    }
  } catch (error) {
    console.error('Error in checkDatabase:', error);
    return null;
  }
}

function calculateHammingDistance(hash1, hash2) {
  if (hash1.length !== hash2.length) {
    const minLength = Math.min(hash1.length, hash2.length);
    let distance = Math.abs(hash1.length - hash2.length);
    for (let i = 0; i < minLength; i++) {
      if (hash1[i] !== hash2[i]) {
        distance++;
      }
    }
    return distance;
  }
  let distance = 0;
  for (let i = 0; i < hash1.length; i++) {
    if (hash1[i] !== hash2[i]) {
      distance++;
    }
  }
  return distance;
}

function detectCaptcha() {
  const shadowHost = deepQuerySelector('awswaf-captcha');
  if (!shadowHost) {
    return false;
  }
  
  try {
    const shadowRoot = shadowHost.shadowRoot;
    if (!shadowRoot) {
      return false;
    }
    
    // ✅ RELAXED: If shadowRoot exists, consider CAPTCHA detected
    // Canvas might still be loading, but CAPTCHA widget is present
    const canvas = findCanvasInShadow(shadowRoot);
    
    // Jika tombol confirm sedang dalam status Loading, jangan proses captcha baru
    const curConfirmBtn = shadowRoot.querySelector('button.confirm-button, button[type="submit"]');
    if (curConfirmBtn && curConfirmBtn.textContent.toLowerCase().includes('loading')) {
      return false;
    }

    // If canvas found, definitely detected
    if (canvas) {
      return true;
    }
    
    // ✅ FALLBACK: No canvas yet, but shadowRoot exists
    // This means CAPTCHA is being rendered - give it a chance!
    // Check if shadowRoot has any content (not completely empty)
    const hasContent = shadowRoot.childNodes.length > 0 || 
                      shadowRoot.children.length > 0 ||
                      shadowRoot.querySelector('*'); // Any element
    
    if (hasContent) {
      return true;
    }
    
    return false;
  } catch (e) {
    return false;
  }
}

function getCaptchaCanvas() {
  const shadowHost = deepQuerySelector('awswaf-captcha');
  if (!shadowHost) {
    console.warn('⚠️ [CANVAS] shadowHost not found');
    return null;
  }
  try {
    const shadowRoot = shadowHost.shadowRoot;
    if (!shadowRoot) {
      console.warn('⚠️ [CANVAS] shadowRoot not found');
      return null;
    }
    const canvas = findCanvasInShadow(shadowRoot);
    if (!canvas) {
      console.warn('⚠️ [CANVAS] canvas element not found in shadowRoot');
      return null;
    }
    console.log('✅ [CANVAS] Canvas found successfully');
    return canvas;
  } catch (e) {
    console.error('❌ [CANVAS] Error:', e);
    return null;
  }
}

// Enhanced last processed captcha initialization
const initialTimestamp = Date.now();
let lastProcessedCaptcha = {
  dataURL: null,
  timestamp: 0,
  matchedPositions: [],
  isProcessing: false,
  hash: null,
  tileHashes: [],
  overallHash: null,
  clickedTiles: new Set(),
  captchaUrl: null,
  downloadedTiles: new Set(),
  tilesForLearning: [], // Track tiles for learning
  keyword: null, // ✅ ADDED: Store keyword for learning
  consecutiveFailures: 0, // ✅ NEW: Track consecutive failures
  lastFailureTime: 0, // ✅ NEW: Track last failure timestamp
  isInCooldown: false, // ✅ NEW: Prevent processing during cooldown
  lastAttemptTime: initialTimestamp // ✅ FIX: Initialize with current time, not 0
};

function getImageHash(dataURL) {
  return dataURL.split(',')[1].substring(0, 32);
}

function getCaptchaUrl(canvas) {
  if (!canvas) {
    return null;
  }
  if (canvas.src) {
    return canvas.src;
  }
  try {
    const dataURL = canvas.toDataURL();
    return dataURL;
  } catch (e) {
    return null;
  }
}

function getCaptchaInstruction() {
  const shadowHost = document.querySelector('awswaf-captcha');
  if (!shadowHost || !shadowHost.shadowRoot) return null;
  let allText = '';
  const walker = document.createTreeWalker(shadowHost.shadowRoot, NodeFilter.SHOW_TEXT, null);
  let node;
  while ((node = walker.nextNode())) {
    allText += node.textContent + '\n';
  }
  const lines = allText.split(/\n|\.|!|\?/);
  const idx = lines.findIndex(line => line.toLowerCase().includes('choose all'));
  if (idx !== -1) {
    let instr = lines[idx].trim();
    if (instr.length < 15 && lines[idx + 1]) {
      instr = (instr + ' ' + lines[idx + 1].trim()).trim();
    }
    return instr;
  }
  return null;
}

function parseInstruction(instruction) {
  if (!instruction) return { keyword: null, count: null };
  const lower = instruction.toLowerCase();
  // Try to capture formats like: "choose all 5 hats", "choose all the hats"
  let m = lower.match(/choose all\s+(\d+)\s+(?:of\s+)?(?:the\s+)?([a-z0-9\- ]+)/);
  if (m && m[2]) {
    return { keyword: m[2].trim(), count: parseInt(m[1], 10) || null };
  }
  m = lower.match(/choose all\s+(?:of\s+)?(?:the\s+)?([a-z0-9\- ]+)/);
  if (m && m[1]) return { keyword: m[1].trim(), count: null };
  // Fallback: last word as keyword
  const words = instruction.split(' ');
  const kw = words[words.length - 1].replace(/[^a-z0-9\-]/gi, '').trim();
  return { keyword: kw || null, count: null };
}

// FUNGSI INI TELAH DIMODIFIKASI SECARA KESELURUHAN DENGAN "JARING PENGAMAN" (try...finally)
async function captureAndProcess(el, forceRefresh = false, skipAutoClick = false) {
  // Jaring pengaman utama: Jika sudah sibuk, jangan proses lagi
  if (lastProcessedCaptcha.isProcessing && !forceRefresh) {
    console.log('⏭️ [CAPTURE] Already processing, skipping...');
    return;
  }

  // Tandai sebagai sibuk SEKARANG
  lastProcessedCaptcha.isProcessing = true;
  const captureStartTime = Date.now();
  console.log(`📸 [CAPTURE] Starting... (forceRefresh: ${forceRefresh}, skipAutoClick: ${skipAutoClick})`);

  try {
    if (!isChromeExtensionContext()) {
      console.error('❌ [CAPTURE] Chrome storage API not available');
      return; // Keluar dari fungsi jika API tidak ada
    }

    // ✅ FIXED: Ensure database is loaded before processing
    try {
      // console.log('📚 [DATABASE] Loading database.json...');
      await loadDatabase();
      // console.log(`✅ [DATABASE] Loaded: ${Object.keys(hashDatabase).length} entries`);
    } catch (loadError) {
      console.error('❌ [DATABASE] Failed to load:', loadError);
      return;
    }

    const dataURL = el.tagName === 'CANVAS' ? el.toDataURL() : el.src;
    const canvas = getCaptchaCanvas();
    const currentCaptchaUrl = getCaptchaUrl(canvas);
    
    if (!currentCaptchaUrl) {
      // console.warn('⚠️ [CAPTURE] Could not get CAPTCHA URL');
      return;
    }
    
    const now = Date.now(); // ✅ FIX: Define 'now' variable
    const isNewCaptcha = currentCaptchaUrl !== lastProcessedCaptcha.captchaUrl;
    // console.log(`🔍 [CAPTURE] CAPTCHA ${isNewCaptcha ? 'NEW' : 'SAME'} (force: ${forceRefresh})`);
    
    // ✅ REMOVED: Minimum delay between attempts - process new CAPTCHA immediately!
    
    if (isNewCaptcha || forceRefresh) {
      // console.log(`🆕 [CAPTURE] ${forceRefresh ? 'Force refresh' : 'New CAPTCHA detected'} - preparing state`);
      // ✅ PRESERVE failure tracking across CAPTCHA changes
      const preservedFailures = lastProcessedCaptcha.consecutiveFailures;
      const preservedFailureTime = lastProcessedCaptcha.lastFailureTime;
      const preservedCooldown = lastProcessedCaptcha.isInCooldown;
      
      lastProcessedCaptcha = {
        ...lastProcessedCaptcha,
        dataURL: null,
        timestamp: Date.now(),
        matchedPositions: [],
        hash: null,
        tileHashes: [],
        overallHash: null,
        clickedTiles: new Set(),
        captchaUrl: currentCaptchaUrl,
        downloadedTiles: new Set(),
        tilesForLearning: [],
        keyword: null,
        // ✅ PRESERVE these across CAPTCHA changes
        consecutiveFailures: preservedFailures,
        lastFailureTime: preservedFailureTime,
        isInCooldown: preservedCooldown
      };
      
      if (preservedFailures > 0) {
        // console.warn(`⚠️ [CAPTURE] New CAPTCHA but failure state preserved: ${preservedFailures} failures`);
      }
    }
    
    if (!isNewCaptcha && !forceRefresh) {
      // console.log('⏭️ [CAPTURE] Same CAPTCHA, skipping...');
      return;
    }
    
    // ✅ NEW: Update last attempt time
    lastProcessedCaptcha.lastAttemptTime = Date.now();
    
    const img = new Image();
    img.src = dataURL;
    
    // Menggunakan onload dalam promise agar lebih mudah ditangani
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = () => reject(new Error("Failed to load image for processing."));
    });

    const w = img.width, h = img.height;
    const tileW = Math.floor(w / 3), tileH = Math.floor(h / 3);
    
    // ✅ FIXED: Get learnedDatabase and settings from storage, but use in-memory hashDatabase
    const storageData = await safeStorageGet(['learnedDatabase', 'hashSettings']);
    const { learnedDatabase = {}, hashSettings } = storageData;
    const settings = hashSettings || { width: 9, height: 8, algorithm: 'dhash', threshold: 10 };

    const instruction = getCaptchaInstruction();
    const { keyword, count: expectedCount } = parseInstruction(instruction);
    // console.log(`📝 [INSTRUCTION] "${instruction}" → keyword: "${keyword}", count: ${expectedCount}`);
    
    const processingPromises = [];

    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 3; col++) {
        const tileCanvas = document.createElement('canvas');
        tileCanvas.width = tileW;
        tileCanvas.height = tileH;
        const ctx = tileCanvas.getContext('2d');
        ctx.drawImage(img, col * tileW, row * tileH, tileW, tileH, 0, 0, tileW, tileH);
        // Use compressed preview to reduce storage size
        const tileDataURL = tileCanvas.toDataURL('image/jpeg', 0.5);
        
        // ✅ Use in-memory hashDatabase instead of from storage
        const promise = checkDatabase(tileDataURL, learnedDatabase, hashDatabase, settings).then(matchResult => ({
          dataURL: tileDataURL,
          position: `${row}_${col}`,
          row: row,
          col: col,
          matchResult: matchResult,
          hash: matchResult ? matchResult.hash : null
        }));
        processingPromises.push(promise);
      }
    }
    
    const capturedTiles = await Promise.all(processingPromises);
    const processingDuration = Date.now() - captureStartTime;
    console.log(`⚡ [TILES] Processed 9 tiles in ${processingDuration}ms`);
    
    const matchedTiles = [], unknownTiles = [], wrongCategoryTiles = [];
    
    if (keyword) {
      capturedTiles.forEach(tile => {
        if (tile.matchResult && tile.matchResult.found) {
          if (tile.matchResult.match.folder.toLowerCase().includes(keyword.toLowerCase())) {
            matchedTiles.push({ ...tile, confidence: tile.matchResult.match.confidence, distance: tile.matchResult.match.distance });
          } else {
            wrongCategoryTiles.push(tile);
          }
        } else {
          // Hitung estimasi jarak ke label sebagai cadangan aman
          const est = estimateDistanceToLabel(tile.hash, keyword, 64);
          unknownTiles.push({ ...tile, estimatedDistance: est });
        }
      });
    }
    
    let finalClickPositions = [], tilesForLearning = [];
    const MAX_CLICKS = 9;
    
    const DEFAULT_TARGET = (expectedCount && expectedCount > 0) ? expectedCount : 5;
    const targetTotal = Math.min(DEFAULT_TARGET, MAX_CLICKS);
    console.log(`🎯 [STRATEGY] Target: ${targetTotal} clicks, Matched: ${matchedTiles.length}, Unknown: ${unknownTiles.length}, Wrong: ${wrongCategoryTiles.length}`);

    // Pilih matched terlebih dahulu
    matchedTiles.sort((a, b) => b.confidence - a.confidence); // ✅ Sort by HIGHEST confidence first
    const matchedSelected = matchedTiles.slice(0, Math.min(matchedTiles.length, targetTotal));
    
    // ✅ LOG: If we have more matched tiles than needed, show which ones we're skipping
    if (matchedTiles.length > targetTotal) {
      const skipped = matchedTiles.slice(targetTotal);
      // console.log(`ℹ️ [STRATEGY] Have ${matchedTiles.length} matched tiles, only need ${targetTotal}. Skipping ${skipped.length} lowest confidence tiles:`);
      skipped.forEach(tile => {
        // console.log(`   ⏭️ Skipped tile [${tile.row},${tile.col}] confidence ${tile.confidence.toFixed(2)}`);
      });
    }
    
    matchedSelected.forEach(tile => finalClickPositions.push({ row: tile.row, col: tile.col }));
    
    let remainingSlots = targetTotal - finalClickPositions.length;
    
    // ✅ STEP 1: Try unknown tiles first (best guess)
    if (remainingSlots > 0) {
      const candidates = unknownTiles
        .filter(t => typeof t.estimatedDistance === 'number')
        .sort((a, b) => (a.estimatedDistance - b.estimatedDistance));
      const selectedUnknowns = candidates.slice(0, remainingSlots);
      selectedUnknowns.forEach(tile => {
        finalClickPositions.push({ row: tile.row, col: tile.col });
        const confidenceFlag = (matchedSelected.length > 0) ? 'unknown_with_some_matched' : 'pure_guess';
        tilesForLearning.push({ tile: tile, expectedLabel: 'the ' + keyword, confidence: confidenceFlag });
      });
      remainingSlots = targetTotal - finalClickPositions.length;
    }
    
    // ✅ STEP 2: If still need more, use wrong category tiles with LOWEST confidence
    // (These are "uncertain" matches - might be misclassified in database)
    if (remainingSlots > 0 && wrongCategoryTiles.length > 0) {
      // console.log(`⚠️ [STRATEGY] Still need ${remainingSlots} more tiles, using wrong-category with lowest confidence...`);
      
      // Sort wrong category by LOWEST confidence first (most uncertain = most likely wrong classification)
      const wrongCandidates = wrongCategoryTiles
        .filter(t => t.matchResult && t.matchResult.match && typeof t.matchResult.match.confidence === 'number')
        .sort((a, b) => a.matchResult.match.confidence - b.matchResult.match.confidence); // ✅ LOWEST first!
      
      const selectedWrong = wrongCandidates.slice(0, remainingSlots);
      selectedWrong.forEach(tile => {
        finalClickPositions.push({ row: tile.row, col: tile.col });
        // console.log(`🤔 [STRATEGY] Adding wrong-category tile [${tile.row},${tile.col}] with low confidence ${tile.matchResult.match.confidence.toFixed(2)} (folder: ${tile.matchResult.match.folder})`);
        // ✅ FIXED: Add to learning so database can be corrected if CAPTCHA succeeds
        tilesForLearning.push({ 
          tile: { ...tile, hash: tile.hash || tile.matchResult?.hash }, 
          expectedLabel: 'the ' + keyword, 
          confidence: 'wrong_category_correction',
          previousLabel: tile.matchResult.match.folder // Track what it was wrongly classified as
        });
      });
    }

    if (finalClickPositions.length > MAX_CLICKS) {
      finalClickPositions = finalClickPositions.slice(0, MAX_CLICKS);
    }
    
    console.log(`✅ [FINAL] Selected ${finalClickPositions.length} tiles to click, ${tilesForLearning.length} for learning`);
    
    lastProcessedCaptcha.tilesForLearning = tilesForLearning;
    lastProcessedCaptcha.keyword = 'the ' + keyword;
    lastProcessedCaptcha.matchedPositions = finalClickPositions;
    
    // ✅ NEW: Build tiles distribution for analytics
    const tilesDistribution = {};
    // Count matched tiles (target category)
    if (matchedTiles.length > 0) {
      const targetLabel = 'the ' + keyword;
      tilesDistribution[targetLabel] = { count: matchedTiles.length, clicked: matchedSelected.length };
    }
    // Count wrong category tiles
    wrongCategoryTiles.forEach(tile => {
      const label = tile.matchResult.match.folder;
      if (!tilesDistribution[label]) {
        tilesDistribution[label] = { count: 0, clicked: 0 };
      }
      tilesDistribution[label].count++;
    });
    // Mark clicked wrongCategory tiles
    tilesForLearning.forEach(item => {
      if (item.confidence === 'wrong_category_correction' && item.previousLabel) {
        if (tilesDistribution[item.previousLabel]) {
          tilesDistribution[item.previousLabel].clicked++;
        }
      }
    });
    // Count unknown tiles
    if (unknownTiles.length > 0) {
      const clickedUnknowns = tilesForLearning.filter(item => item.confidence !== 'wrong_category_correction').length;
      tilesDistribution['unknown'] = { count: unknownTiles.length, clicked: clickedUnknowns };
    }
    lastProcessedCaptcha.tilesDistribution = tilesDistribution;

    if (finalClickPositions.length > 0 && !skipAutoClick) {
      const canvasToClick = getCaptchaCanvas();
      if (canvasToClick) {
        console.log(`🚀 [AUTO-CLICK] Starting auto-click for ${finalClickPositions.length} tiles...`);
        await autoClickCaptcha(canvasToClick, finalClickPositions, tilesForLearning, 'the ' + keyword);
      } else {
        console.warn('⚠️ [AUTO-CLICK] Canvas not found, skipping auto-click');
      }
    } else if (skipAutoClick) {
      console.log('⏭️ [AUTO-CLICK] Skipped (skipAutoClick=true)');
    } else {
      console.warn('⚠️ [AUTO-CLICK] No tiles to click');
    }

    // Store with trimmed payload to avoid chrome.storage quota issues
    try {
      const storedTiles = capturedTiles.map(tile => ({
        dataURL: tile.dataURL,
        position: tile.position,
        matchResult: tile.matchResult && tile.matchResult.match ? {
          found: !!tile.matchResult.found,
          match: {
            folder: tile.matchResult.match.folder,
            confidence: tile.matchResult.match.confidence
          }
        } : { found: false, match: null }
      }));
      const storedLearning = tilesForLearning.map(item => ({
        tile: { position: item.tile.position },
        expectedLabel: item.expectedLabel,
        confidence: item.confidence
      }));

      await safeStorageSet({
        captchaTiles: storedTiles,
        lastCaptured: Date.now(),
        captchaInstruction: instruction || '',
        captchaKeyword: 'the ' + (keyword || ''),
        captchaClickedPositions: finalClickPositions || [],
        tilesForLearning: storedLearning
      });
    } catch (storageErr) {
      // console.warn('⚠️ [STORAGE] Write skipped due to error:', storageErr);
    }
    
    const totalCaptureDuration = Date.now() - captureStartTime;
    console.log(`✅ [CAPTURE] Completed in ${totalCaptureDuration}ms`);

  } catch (error) {
    console.error("❌ [CAPTURE] Error during captureAndProcess:", error);
  } finally {
    lastProcessedCaptcha.isProcessing = false;
    console.log('🔓 [CAPTURE] Processing flag released');
  }
}

async function checkCaptchaStatus() {
  try {
    const captcha = document.querySelector('awswaf-captcha');
    if (!captcha) {
      // ✅ NEW: Reset failure counter when CAPTCHA disappears (successful verification)
      if (lastProcessedCaptcha.consecutiveFailures > 0) {
        // console.log('✅ [STATUS] CAPTCHA disappeared - resetting failure counter');
        lastProcessedCaptcha.consecutiveFailures = 0;
        lastProcessedCaptcha.lastFailureTime = 0;
        lastProcessedCaptcha.isInCooldown = false;
      }
      // console.log('✅ [STATUS] CAPTCHA not found (verified)');
      return true;
    }
    const isVisible = captcha.offsetParent !== null;
    if (!isVisible) {
      // ✅ NEW: Reset failure counter when CAPTCHA becomes invisible
      if (lastProcessedCaptcha.consecutiveFailures > 0) {
        // console.log('✅ [STATUS] CAPTCHA hidden - resetting failure counter');
        lastProcessedCaptcha.consecutiveFailures = 0;
        lastProcessedCaptcha.lastFailureTime = 0;
        lastProcessedCaptcha.isInCooldown = false;
      }
      // console.log('✅ [STATUS] CAPTCHA hidden (verified)');
      return true;
    }
    // console.log('⏳ [STATUS] CAPTCHA still visible (not verified)');
    return false;
  } catch (error) {
    console.error('❌ [STATUS] Error checking CAPTCHA status:', error);
    return false;
  }
}

async function clickConfirmButton() {
  console.log(`🔘 [CONFIRM] Waiting 400ms before searching for button...`);
  try {
    await new Promise(resolve => setTimeout(resolve, 400));
    
    let confirmButton = null;
    console.log(`🔘 [CONFIRM] Searching for confirm button...`);
    
    const selectors = [
      '//div[contains(@class, "awswaf-captcha")]//button[contains(text(), "Confirm")]',
      'awswaf-captcha::shadow button.confirm-button',
      'awswaf-captcha::shadow button[type="submit"]',
      'awswaf-captcha::shadow form button:first-child',
      'awswaf-captcha',
      'button.confirm-button',
      'button[type="submit"]',
      'form button:first-child'
    ];
    
    for (const selector of selectors) {
      if (selector.startsWith('//')) {
        const result = document.evaluate(
          selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
        );
        confirmButton = result.singleNodeValue;
      } else if (selector.includes('::shadow')) {
        const [hostSelector, shadowSelector] = selector.split('::shadow');
        const host = document.querySelector(hostSelector);
        if (host && host.shadowRoot) {
          confirmButton = host.shadowRoot.querySelector(shadowSelector);
        }
      } else if (selector === 'awswaf-captcha') {
        const captcha = document.querySelector(selector);
        if (captcha && captcha.shadowRoot) {
          confirmButton = captcha.shadowRoot.querySelector('button.confirm-button') ||
                        captcha.shadowRoot.querySelector('button[type="submit"]') ||
                        captcha.shadowRoot.querySelector('form button:first-child');
        }
      } else {
        confirmButton = document.querySelector(selector);
      }
      if (confirmButton) break;
    }
    
    if (!confirmButton) {
      const allButtons = document.querySelectorAll('button');
      for (const button of allButtons) {
        const buttonText = button.textContent.trim().toLowerCase();
        // ✅ CRITICAL: Only click "Confirm" button, NOT "Get new puzzle" or other buttons
        if (buttonText.includes('confirm') && !buttonText.includes('new') && !buttonText.includes('puzzle')) {
          confirmButton = button;
          break;
        }
      }
    }
    
    if (confirmButton) {
      // ✅ DOUBLE CHECK: Make sure it's NOT the "new puzzle" button
      const buttonText = confirmButton.textContent.trim().toLowerCase();
      if (buttonText.includes('new') || buttonText.includes('puzzle') || buttonText.includes('refresh')) {
        // console.warn(`⚠️ [CONFIRM] Found button but it's "${buttonText}" - NOT clicking!`);
        return false;
      }
      
      console.log(`✅ [CONFIRM] Button found: "${buttonText}", clicking...`);
      // No additional delay - click immediately after finding button
      
      const rect = confirmButton.getBoundingClientRect();
      // Tambahkan acak posisi untuk confirm button
      const randomX = (Math.random() - 0.5) * (rect.width * 0.4);
      const randomY = (Math.random() - 0.5) * (rect.height * 0.4);
      const x = rect.left + (rect.width / 2) + randomX;
      const y = rect.top + (rect.height / 2) + randomY;
      
      const mouseInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
      const pointerInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1, pointerType: 'mouse' };

      // Pointer/Mouse Move
      try { confirmButton.dispatchEvent(new PointerEvent('pointermove', pointerInit)); } catch (_) {}
      try { confirmButton.dispatchEvent(new MouseEvent('mousemove', mouseInit)); } catch (_) {}
      
      await new Promise(r => setTimeout(r, 30 + Math.random() * 30));
      
      // Mouse down
      try { confirmButton.dispatchEvent(new PointerEvent('pointerdown', pointerInit)); } catch (_) {}
      try { confirmButton.dispatchEvent(new MouseEvent('mousedown', mouseInit)); } catch (_) {}
      
      await new Promise(r => setTimeout(r, 40 + Math.random() * 50));
      
      // Mouse up and click (single click, avoid double submit)
      try { confirmButton.dispatchEvent(new PointerEvent('pointerup', pointerInit)); } catch (_) {}
      try { confirmButton.dispatchEvent(new MouseEvent('mouseup', mouseInit)); } catch (_) {}
      await new Promise(r => setTimeout(r, 20 + Math.random() * 30));
      try { confirmButton.click(); } catch (_) {
        try { confirmButton.dispatchEvent(new MouseEvent('click', mouseInit)); } catch (_) {}
      }
      
      console.log(`⏳ [CONFIRM] Menunggu server AWS WAF memverifikasi jawaban (polling hingga 15s)...`);
      let verified = false;
      for (let w = 0; w < 30; w++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        const isClosed = await checkCaptchaStatus();
        if (isClosed) {
          console.log(`✅ [CONFIRM] Verifikasi sukses! Modal CAPTCHA telah tertutup.`);
          verified = true;
          break;
        }

        // Cek apakah ada error sementara dari AWS WAF
        const shadowHost = document.querySelector('awswaf-captcha');
        const root = (shadowHost && shadowHost.shadowRoot) ? shadowHost.shadowRoot : document;
        const textContent = (root.textContent || "").toLowerCase();

        if (textContent.includes("temporary error") || textContent.includes("went wrong")) {
          console.warn(`⚠️ [CONFIRM] Terdeteksi 'Temporary error' dari AWS WAF. Mengklik tombol reload puzzle baru...`);
          const reloadButtons = root.querySelectorAll('button, svg, [role="button"]');
          for (const btn of reloadButtons) {
            const bText = (btn.getAttribute('aria-label') || btn.textContent || btn.getAttribute('title') || '').toLowerCase();
            if (bText.includes('refresh') || bText.includes('reload') || bText.includes('new') || bText.includes('puzzle')) {
              try { btn.click(); console.log(`🔄 [RELOAD] Tombol puzzle baru berhasil diklik.`); } catch(_) {}
              break;
            }
          }
          break;
        }

        const btnText = confirmButton ? confirmButton.textContent.trim().toLowerCase() : '';
        if (btnText.includes('loading') || root.querySelector('.loading, [class*="loading" i], [class*="spinner" i]')) {
          if (w % 4 === 0) console.log(`⏳ [CONFIRM] AWS masih memvalidasi token (${Math.round((w+1)*0.5)}s)...`);
          continue;
        }
      }
      return verified;
    } else {
      console.warn(`⚠️ [CONFIRM] Button not found!`);
      return false;
    }
  } catch (error) {
    console.error('❌ [CONFIRM] Error:', error);
    return false;
  }
}

async function autoClickCaptcha(canvas, positions, tilesForLearning, keyword) {
  const startTime = Date.now();
  console.log(`🖱️ [AUTO-CLICK] Starting for ${positions.length} tiles with keyword: "${keyword}"`);
  
  try {
    try { canvas.scrollIntoView({ behavior: 'instant', block: 'center' }); } catch (_) {}
    const rect = canvas.getBoundingClientRect();
    const tileWidth = rect.width / 3;
    const tileHeight = rect.height / 3;
    
    // console.log(`🖱️ [AUTO-CLICK] Canvas rect: ${rect.width}x${rect.height}, tile size: ${tileWidth}x${tileHeight}`);
    
    for (let i = 0; i < positions.length; i++) {
      const pos = positions[i];
      // console.log(`🖱️ [CLICK ${i+1}/${positions.length}] Tile [${pos.row},${pos.col}]`);
      
      // Tambahkan offset acak agar klik tidak persis di tengah
      const randomOffsetX = (Math.random() - 0.5) * (tileWidth * 0.4); 
      const randomOffsetY = (Math.random() - 0.5) * (tileHeight * 0.4);
      const x = Math.floor(rect.left + (pos.col * tileWidth) + (tileWidth / 2) + randomOffsetX);
      const y = Math.floor(rect.top + (pos.row * tileHeight) + (tileHeight / 2) + randomOffsetY);
      const mouseEventInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
      const pointerEventInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1, pointerType: 'mouse' };
      
      // ✅ Simulasi klik yang lebih realistis
      try { canvas.dispatchEvent(new PointerEvent('pointermove', pointerEventInit)); } catch (_) {}
      try { canvas.dispatchEvent(new MouseEvent('mousemove', mouseEventInit)); } catch (_) {}
      
      // Jeda sebelum menekan tombol (hover)
      await new Promise(r => setTimeout(r, 30 + Math.random() * 40));
      
      try { canvas.dispatchEvent(new PointerEvent('pointerdown', pointerEventInit)); } catch (_) {}
      try { canvas.dispatchEvent(new MouseEvent('mousedown', mouseEventInit)); } catch (_) {}
      
      // Jeda waktu tombol ditekan (manusia butuh ~50ms untuk melepas klik)
      await new Promise(r => setTimeout(r, 40 + Math.random() * 50));
      
      try { canvas.dispatchEvent(new PointerEvent('pointerup', pointerEventInit)); } catch (_) {}
      try { canvas.dispatchEvent(new MouseEvent('mouseup', mouseEventInit)); } catch (_) {}
      try { canvas.dispatchEvent(new MouseEvent('click', mouseEventInit)); } catch (_) {}
      
      // Jeda antar klik tile (200ms - 350ms responsif & natural)
      await new Promise(r => setTimeout(r, 200 + Math.floor(Math.random() * 150)));
    }
    
    const clickDuration = Date.now() - startTime;
    console.log(`🖱️ [AUTO-CLICK] Completed ${positions.length} clicks in ${clickDuration}ms`);
    
    // Tunggu AWS CAPTCHA memproses state seleksi tile
    const processingDelay = 800; // ✅ Waktu manusiawi agar WAF memproses state klik tile secara alami
    console.log(`⏳ [PROCESSING] Waiting ${processingDelay}ms for CAPTCHA to process tile selections...`);
    console.log(`📝 [INFO] Tiles clicked: ${positions.map(p => `[${p.row},${p.col}]`).join(', ')}`);
    await new Promise(r => setTimeout(r, processingDelay));
    
    console.log(`🔘 [CONFIRM] Attempting to click confirm button...`);
    
    const isVerified = await clickConfirmButton();
    
    const totalDuration = Date.now() - startTime;
    
    // ✅ NEW: Handle failure tracking
    if (!isVerified) {
      lastProcessedCaptcha.consecutiveFailures++;
      lastProcessedCaptcha.lastFailureTime = Date.now();
      lastProcessedCaptcha.lastAttemptTime = Date.now(); // ✅ Update attempt time on failure
      console.warn(`❌ [VERIFY FAILED] Total time: ${totalDuration}ms, Consecutive failures: ${lastProcessedCaptcha.consecutiveFailures}`);
      
      // ✅ NEW: Enter cooldown after repeated failures
      if (lastProcessedCaptcha.consecutiveFailures >= 3) {
        const cooldownDuration = Math.min(lastProcessedCaptcha.consecutiveFailures * 5000, 30000); // Max 30s
        lastProcessedCaptcha.isInCooldown = true;
        // console.warn(`⏸️ [COOLDOWN START] Duration: ${cooldownDuration/1000}s after ${lastProcessedCaptcha.consecutiveFailures} failures`);
        
        setTimeout(() => {
          lastProcessedCaptcha.isInCooldown = false;
          lastProcessedCaptcha.consecutiveFailures = 0;
          // console.log('✅ [COOLDOWN END] Resuming CAPTCHA detection');
        }, cooldownDuration);
      } else {
        const nextRetryIn = 8 - Math.floor((Date.now() - lastProcessedCaptcha.lastFailureTime) / 1000);
        // console.log(`⏳ [RETRY] Will retry after ${Math.max(0, nextRetryIn)}s delay (failures: ${lastProcessedCaptcha.consecutiveFailures})`);
      }
      
      return false;
    }
    
    // ✅ NEW: Reset failure counter on success
    console.log(`✅ [VERIFY SUCCESS] Total time: ${totalDuration}ms, Resetting failure counter`);
    lastProcessedCaptcha.consecutiveFailures = 0;
    lastProcessedCaptcha.lastFailureTime = 0;
    lastProcessedCaptcha.lastAttemptTime = Date.now(); // ✅ Update attempt time
    
    // Learning if success
    if (isVerified && keyword && isChromeExtensionContext()) {
      const hashesToLearn = []; // For unknown tiles (new learning)
      const corrections = []; // ✅ NEW: For wrong category tiles (corrections)
      const learningStats = { high_confidence: 0, medium_confidence: 0, low_confidence: 0, wrong_category_correction: 0 };
      
      tilesForLearning.forEach(item => {
        if (item.tile.hash) {
          if (item.confidence === 'wrong_category_correction' && item.previousLabel) {
            // ✅ NEW: This is a correction, not new learning
            corrections.push({
              hash: item.tile.hash,
              oldLabel: item.previousLabel,
              newLabel: keyword
            });
            learningStats.wrong_category_correction++;
          } else {
            // Regular learning (unknown tiles)
            hashesToLearn.push(item.tile.hash);
            if (item.confidence === 'unknown_with_matched') learningStats.high_confidence++;
            else if (item.confidence === 'unknown_with_some_matched') learningStats.medium_confidence++;
            else learningStats.low_confidence++;
          }
        }
      });
      
      // ✅ NEW: Always send captcha history data (even if no learning/corrections)
      try {
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            action: 'learnMultipleHashes',
            hashes: hashesToLearn,
            label: keyword,
            confidence: learningStats,
            corrections: corrections,
            // ✅ NEW: Add tiles distribution for analytics
            tilesDistribution: lastProcessedCaptcha.tilesDistribution || {},
            totalClicked: positions.length
          }, (response) => {
            if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
            else resolve(response);
          });
        });
        
        if (response && response.success) {
          // console.log(`✅ Learned ${response.count} new, corrected ${response.corrected} patterns for "${keyword}"`);
        }
      } catch (sendError) {
        console.error('❌ Failed to send learn message:', sendError);
      }
    }
    
    return isVerified;
    
  } catch (error) {
    console.error('Error in autoClickCaptcha:', error);
    // ✅ NEW: Track errors as failures
    lastProcessedCaptcha.consecutiveFailures++;
    lastProcessedCaptcha.lastFailureTime = Date.now();
    return false;
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!isChromeExtensionContext()) {
    sendResponse({ success: false, error: 'Chrome APIs not available' });
    return false;
  }

  if (request && request.action === 'ping') {
    sendResponse({ success: true, message: 'Content script is active' });
    return true;
  }
  
  // ✅ NEW: Get cooldown status
  if (request && request.action === 'getCooldownStatus') {
    const cooldownEndTime = lastProcessedCaptcha.isInCooldown ? 
      (lastProcessedCaptcha.lastFailureTime + Math.min(lastProcessedCaptcha.consecutiveFailures * 5000, 30000)) : 0;
    const remainingTime = Math.max(0, cooldownEndTime - Date.now());
    
    sendResponse({
      success: true,
      isInCooldown: lastProcessedCaptcha.isInCooldown,
      consecutiveFailures: lastProcessedCaptcha.consecutiveFailures,
      lastFailureTime: lastProcessedCaptcha.lastFailureTime,
      remainingTime: remainingTime
    });
    return true;
  }
  
  if (request && request.action === 'test-detection') {
    const captchaDetected = detectCaptcha();
    const canvas = getCaptchaCanvas();
    sendResponse({ 
      success: true, 
      captchaDetected: captchaDetected,
      canvasFound: !!canvas,
      message: `CAPTCHA detected: ${captchaDetected}, Canvas found: ${!!canvas}`
    });
    return true;
  }

  if (request && request.action === 'refresh-captcha') {
    const canvas = getCaptchaCanvas();
    if (canvas) {
      // ✅ FIXED: Set skipAutoClick to FALSE to enable auto-click on refresh
      captureAndProcess(canvas, true, false).then(() => {
        sendResponse({ success: true });
      }).catch(error => {
        console.error('Error in refresh-captcha:', error);
        sendResponse({ success: false, error: 'Error processing CAPTCHA' });
      });
      return true;
    } else {
      sendResponse({ success: false, error: 'No CAPTCHA found' });
    }
  }
  
  if (request && request.action === 'click-captcha') {
    const canvas = getCaptchaCanvas();
    if (canvas && lastProcessedCaptcha.matchedPositions.length > 0) {
      const tilesForLearning = lastProcessedCaptcha.tilesForLearning || [];
      const keyword = lastProcessedCaptcha.keyword || null;
      autoClickCaptcha(canvas, lastProcessedCaptcha.matchedPositions, tilesForLearning, keyword).then(() => {
        sendResponse({ success: true });
      }).catch(error => {
        sendResponse({ success: false, error: 'Error clicking CAPTCHA' });
      });
      return true;
    } else {
      const errorMsg = !canvas ? 'No CAPTCHA found' : 'No positions to click';
      sendResponse({ success: false, error: errorMsg });
    }
  }
  return true;
});

// Enhanced main initialization with better error handling and retry logic
(async () => {
    let initAttempts = 0;
    const maxInitAttempts = 3;
    let isInitialized = false; // ✅ ADDED: Flag to prevent re-initialization
    let fallbackInterval = null; // ✅ ADDED: Store interval reference
    
    const attemptInitialization = async () => {
        // ✅ FIXED: Don't re-initialize if already successful
        if (isInitialized) {
            // console.log('✅ Already initialized, skipping re-initialization');
            return;
        }
        
        initAttempts++;
        // console.log(`🚀 Starting content script initialization (attempt ${initAttempts}/${maxInitAttempts})...`);
        
        try {
            // Step 1: Wait for Chrome APIs
            // console.log('🔄 Step 1: Waiting for Chrome APIs...');
            await waitForChromeAPIs(10000);
            
            // Step 2: Wait for background script
            // console.log('🔄 Step 2: Waiting for background script...');
            await waitForInitialization(15000);
            
            // Step 3: Wait for DOM to be ready
            // console.log('🔄 Step 3: Ensuring DOM is ready...');
            if (document.readyState !== 'complete') {
                await new Promise(resolve => {
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', resolve, { once: true });
                    } else {
                        window.addEventListener('load', resolve, { once: true });
                    }
                });
            }
            
            // ✅ Step 4: Load database from file
            // console.log('🔄 Step 4: Loading database from file...');
            try {
                await loadDatabase();
                const dbSize = Object.keys(hashDatabase).length;
                if (dbSize === 0) {
                    throw new Error('Database loaded but empty');
                }
                // console.log(`✅ Database loaded successfully: ${dbSize} entries`);
            } catch (dbError) {
                console.error('❌ Database loading failed:', dbError);
                throw dbError; // Re-throw to trigger retry
            }
            
            // console.log('✅ All initialization steps completed successfully');
            
            // ✅ FIXED: Set flag to prevent re-initialization
            isInitialized = true;
            
            // ✅ FIXED: Clear fallback interval if it exists
            if (fallbackInterval) {
                clearInterval(fallbackInterval);
                fallbackInterval = null;
                // console.log('✅ Fallback mode disabled');
            }
            
            // Setup CAPTCHA monitoring
            let lastDetectionTime = 0;
            const DETECTION_COOLDOWN = 800; // Faster cooldown to reduce missed detections
            
            const checkAndProcessCaptcha = async () => {
                if (!isChromeExtensionContext()) {
                    console.log('🔴 [CHECK] Chrome API not available');
                    return;
                }
                
                // ✅ CRITICAL: Prevent concurrent processing
                if (lastProcessedCaptcha.isProcessing) {
                    console.log('🔒 [BLOCKED] Already processing, skipping this check');
                    return;
                }
                
                // ✅ NEW: Skip if in cooldown after repeated failures
                if (lastProcessedCaptcha.isInCooldown) {
                    const cooldownEndTime = lastProcessedCaptcha.lastFailureTime + Math.min(lastProcessedCaptcha.consecutiveFailures * 5000, 30000);
                    const remainingTime = Math.max(0, cooldownEndTime - Date.now());
                    console.log(`⏸️ [COOLDOWN] Active - ${lastProcessedCaptcha.consecutiveFailures} failures, ${Math.ceil(remainingTime/1000)}s remaining`);
                    return;
                }
                
                const now = Date.now();
                
                const timeSinceLastProcess = now - lastProcessedCaptcha.timestamp;
                if (timeSinceLastProcess < 1000) {
                    console.log(`⏭️ [SKIP] Too soon since last process (${Math.ceil(timeSinceLastProcess/1000)}s < 1s)`);
                    return;
                }
                
                const timeSinceLastDetection = now - lastDetectionTime;
                if (timeSinceLastDetection < DETECTION_COOLDOWN) {
                    console.log(`⏭️ [SKIP] Detection cooldown (${timeSinceLastDetection}ms < ${DETECTION_COOLDOWN}ms)`);
                    return;
                }
                
                console.log('🔍 [CHECK] Checking for CAPTCHA...');
                if (detectCaptcha()) {
                    const timeSinceLastAttempt = Date.now() - lastProcessedCaptcha.lastAttemptTime;
                    const isInitialAttempt = lastProcessedCaptcha.lastAttemptTime === initialTimestamp;
                    
                    if (isInitialAttempt) {
                        console.log(`🎯 [DETECT] CAPTCHA found (first attempt), starting processing...`);
                    } else {
                        console.log(`🎯 [DETECT] CAPTCHA found (${Math.ceil(timeSinceLastAttempt/1000)}s since last attempt), starting processing...`);
                    }
                    
                    lastDetectionTime = now;
                    
                    // ✅ FIX: Wait for canvas to be ready (retry up to 10 times)
                    let canvas = null;
                    for (let retry = 0; retry < 10; retry++) {
                        canvas = getCaptchaCanvas();
                        if (canvas) {
                            console.log(`✅ [CANVAS] Found after ${retry} retries`);
                            break;
                        }
                        console.log(`⏳ [CANVAS] Not ready yet, retry ${retry + 1}/10...`);
                        await new Promise(r => setTimeout(r, 800)); // Wait 800ms between retries
                    }
                    
                    if (canvas) {
                        console.log('🖼️ [CANVAS] Found, capturing tiles...');
                        try {
                            await captureAndProcess(canvas, false, false);
                        } catch (error) {
                            console.error('❌ [ERROR] Processing failed:', error);
                            // ✅ NEW: Track processing errors as failures
                            lastProcessedCaptcha.consecutiveFailures++;
                            lastProcessedCaptcha.lastFailureTime = Date.now();
                            console.warn(`⚠️ [FAILURE] Consecutive failures: ${lastProcessedCaptcha.consecutiveFailures}`);
                        }
                    } else {
                        console.warn('⚠️ [CANVAS] Not found despite CAPTCHA detection');
                    }
                } else {
                    console.log('✅ [CHECK] No CAPTCHA detected');
                }
            };
            
            // Enhanced mutation observer
            let checkTimeout;
            let mutationCount = 0;
            let lastMutationTime = 0;
            
            const observer = new MutationObserver((mutations) => {
                // ✅ NEW: Skip if in cooldown
                if (lastProcessedCaptcha.isInCooldown) return;
                
                const now = Date.now();
                
                // ✅ NEW: Detect rapid mutations (potential infinite loop)
                if (now - lastMutationTime < 500) {
                    mutationCount++;
                    if (mutationCount > 10) {
                        // console.warn('⚠️ [MUTATION] Rapid mutations detected (${mutationCount}) - possible CAPTCHA refresh loop');
                        lastProcessedCaptcha.isInCooldown = true;
                        setTimeout(() => {
                            lastProcessedCaptcha.isInCooldown = false;
                            mutationCount = 0;
                            // console.log('✅ [MUTATION] Cooldown ended');
                        }, 5000);
                        return;
                    }
                } else {
                    mutationCount = 0;
                }
                lastMutationTime = now;
                
                // Only process if there are meaningful changes
                const hasRelevantChanges = mutations.some(mutation => {
                    return mutation.type === 'childList' && mutation.addedNodes.length > 0;
                });
                
                if (hasRelevantChanges) {
                    // console.log('🔄 [MUTATION] Relevant DOM changes detected, scheduling check in 0.5s...');
                    clearTimeout(checkTimeout);
                    checkTimeout = setTimeout(checkAndProcessCaptcha, 500); // ✅ REDUCED: 1500ms → 500ms for faster detection!
                }
            });
            
            observer.observe(document.body, {
                childList: true, 
                subtree: true, 
                attributes: false // ✅ CHANGED: Disable attribute watching to reduce false triggers
            });
            
            // Initial check after a delay
            console.log('🚀 [INIT] Scheduling initial CAPTCHA check in 2s...');
            setTimeout(checkAndProcessCaptcha, 2000); // ✅ Increased from 1500ms

            // Periodic watchdog to re-trigger detection in case of missed mutations
            // ✅ RE-ENABLED with faster timing for retry after failures
            setInterval(() => {
                try {
                    // ✅ Skip watchdog if in cooldown
                    if (lastProcessedCaptcha.isInCooldown) return;
                    
                    // ✅ Skip if currently processing
                    if (lastProcessedCaptcha.isProcessing) return;
                    
                    const now = Date.now();
                    const timeSinceLastProcess = now - lastProcessedCaptcha.timestamp;
                    const timeSinceLastFailure = now - lastProcessedCaptcha.lastFailureTime;
                    const timeSinceLastAttempt = now - lastProcessedCaptcha.lastAttemptTime;
                    
                    // ✅ Skip watchdog if this is initial state
                    if (lastProcessedCaptcha.lastAttemptTime === initialTimestamp) {
                        return;
                    }
                    
                    // ✅ SMART watchdog: Only trigger if CAPTCHA detected AND enough time passed
                    const hasCaptcha = detectCaptcha();
                    if (!hasCaptcha) return; // No CAPTCHA, nothing to do
                    
                    // ✅ FAST retry after failure: 5s (not 20s!)
                    const shouldCheckAfterFailure = lastProcessedCaptcha.consecutiveFailures > 0 && 
                                                   timeSinceLastFailure > 5000; // 5 seconds after failure
                    
                    // ✅ Normal check: 30s if no recent activity
                    const shouldCheckNormal = lastProcessedCaptcha.consecutiveFailures === 0 && 
                                            timeSinceLastAttempt > 30000; // 30 seconds idle
                    
                    if (shouldCheckAfterFailure) {
                        // console.log(`🔁 [WATCHDOG] Retry after failure (failure: ${Math.ceil(timeSinceLastFailure/1000)}s ago)`);
                        checkAndProcessCaptcha();
                    } else if (shouldCheckNormal) {
                        // console.log(`🔁 [WATCHDOG] Periodic check (idle: ${Math.ceil(timeSinceLastAttempt/1000)}s)`);
                        checkAndProcessCaptcha();
                    }
                } catch (_) {}
            }, 3000); // ✅ FASTER: Check every 3 seconds (was 10s)
            
        } catch (error) {
            console.error(`❌ Initialization failed:`, error);
            
            if (initAttempts < maxInitAttempts) {
                const retryDelay = initAttempts * 3000;
                setTimeout(attemptInitialization, retryDelay);
            } else {
                setupFallbackMode();
            }
        }
    };
    
    // Setup fallback mode for when initialization completely fails
    const setupFallbackMode = () => {
        if (isInitialized || fallbackInterval) return;
        
        fallbackInterval = setInterval(() => {
            if (isInitialized) {
                clearInterval(fallbackInterval);
                fallbackInterval = null;
                return;
            }
            
            if (isChromeExtensionContext()) {
                initAttempts = 0;
                attemptInitialization();
            }
        }, 30000);
    };
    
    // Start initialization
    attemptInitialization();
})();
