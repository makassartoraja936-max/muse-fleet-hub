document.addEventListener('DOMContentLoaded', function() {
  const loadingDiv = document.getElementById('loading');
  const errorDiv = document.getElementById('error');
  const contentDiv = document.getElementById('content');
  const refreshBtn = document.getElementById('refresh-btn');

  // Store current filter and captcha history data
  let currentFilter = 'all';
  let captchaHistoryData = [];

  // Check if Chrome APIs are available
  function isChromeExtensionContext() {
    return typeof chrome !== 'undefined' && 
           chrome.storage && 
           chrome.storage.local && 
           chrome.runtime;
  }

  if (!isChromeExtensionContext()) {
    showError('Chrome Extension APIs not available');
    return;
  }

  function showError(message) {
    loadingDiv.style.display = 'none';
    contentDiv.style.display = 'none';
    errorDiv.style.display = 'block';
    errorDiv.textContent = 'Error: ' + message;
  }

  function showLoading() {
    loadingDiv.style.display = 'block';
    contentDiv.style.display = 'none';
    errorDiv.style.display = 'none';
  }

  function showContent() {
    loadingDiv.style.display = 'none';
    errorDiv.style.display = 'none';
    contentDiv.style.display = 'block';
  }

  function loadAnalytics() {
    showLoading();
    
    chrome.runtime.sendMessage({ action: 'getLearningAnalytics' }, function(response) {
      if (chrome.runtime.lastError) {
        showError('Failed to load analytics: ' + chrome.runtime.lastError.message);
        return;
      }

      if (!response || !response.success) {
        showError('Failed to load analytics: ' + (response?.error || 'Unknown error'));
        return;
      }

      displayAnalytics(response.analytics);
      showContent();
    });
  }

  function displayAnalytics(analytics) {
    // Update overview stats
    document.getElementById('total-learned').textContent = analytics.totalLearned || 0;
    document.getElementById('successful-captchas').textContent = analytics.successfulCaptchas || 0;
    document.getElementById('unique-labels').textContent = analytics.uniqueLabels || 0;
    document.getElementById('database-size').textContent = analytics.currentDatabaseSize || 0;

    // Display label statistics
    displayLabelStats(analytics.labelStats || {});

    // Store captcha history data and display with filters
    captchaHistoryData = (analytics.captchaHistory || []).filter(entry => 
      (entry.learned && entry.learned > 0) || (entry.corrected && entry.corrected > 0)
    );
    displayCategoryFilters(captchaHistoryData);
    displayCaptchaHistory(captchaHistoryData, currentFilter);
  }

  function displayLabelStats(labelStats) {
    const container = document.getElementById('label-stats');
    container.innerHTML = '';

    if (Object.keys(labelStats).length === 0) {
      container.innerHTML = '<div class="no-data">No learning data available yet</div>';
      return;
    }

    // Sort labels by count (descending)
    const sortedLabels = Object.entries(labelStats)
      .sort(([,a], [,b]) => b.count - a.count);

    sortedLabels.forEach(([label, stats]) => {
      const labelDiv = document.createElement('div');
      labelDiv.className = 'label-stat';
      
      const lastUpdated = new Date(stats.lastUpdated).toLocaleString();
      
      labelDiv.innerHTML = `
        <div>
          <div class="label-name">${label}</div>
          <div class="history-date">Last updated: ${lastUpdated}</div>
        </div>
        <div class="label-count">${stats.count}</div>
      `;
      
      container.appendChild(labelDiv);
    });
  }

  // NEW: Display category filter buttons
  function displayCategoryFilters(captchaHistory) {
    const container = document.getElementById('category-filters');
    container.innerHTML = '';

    if (!captchaHistory || captchaHistory.length === 0) {
      return;
    }

    // Count entries per category
    const categoryCounts = {};
    captchaHistory.forEach(entry => {
      const label = entry.label;
      if (!categoryCounts[label]) {
        categoryCounts[label] = 0;
      }
      categoryCounts[label]++;
    });

    // Create filter container
    const filtersDiv = document.createElement('div');
    filtersDiv.className = 'category-filters';

    // Add "All" button
    const allBtn = document.createElement('button');
    allBtn.className = 'filter-btn' + (currentFilter === 'all' ? ' active' : '');
    allBtn.innerHTML = `All <span class="count">${captchaHistory.length}</span>`;
    allBtn.addEventListener('click', () => {
      currentFilter = 'all';
      updateFilterButtons();
      displayCaptchaHistory(captchaHistoryData, 'all');
    });
    filtersDiv.appendChild(allBtn);

    // Add category buttons (sorted by count descending)
    const sortedCategories = Object.entries(categoryCounts)
      .sort(([,a], [,b]) => b - a);

    sortedCategories.forEach(([label, count]) => {
      const btn = document.createElement('button');
      btn.className = 'filter-btn' + (currentFilter === label ? ' active' : '');
      const displayLabel = label.replace('the ', '');
      btn.innerHTML = `${displayLabel} <span class="count">${count}</span>`;
      btn.addEventListener('click', () => {
        currentFilter = label;
        updateFilterButtons();
        displayCaptchaHistory(captchaHistoryData, label);
      });
      filtersDiv.appendChild(btn);
    });

    container.appendChild(filtersDiv);
  }

  // Update filter button active states
  function updateFilterButtons() {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach((btn, index) => {
      if (index === 0) {
        // "All" button
        btn.className = 'filter-btn' + (currentFilter === 'all' ? ' active' : '');
      } else {
        // Category buttons - check by label text
        const labelText = btn.textContent.split(' ')[0];
        const fullLabel = 'the ' + labelText;
        btn.className = 'filter-btn' + (currentFilter === fullLabel ? ' active' : '');
      }
    });
  }

  // Display CAPTCHA History with tiles distribution
  function displayCaptchaHistory(captchaHistory, filter) {
    const container = document.getElementById('captcha-history');
    container.innerHTML = '';

    if (!captchaHistory || captchaHistory.length === 0) {
      container.innerHTML = '<div class="no-data">No learning/correction history available yet</div>';
      return;
    }

    // Apply filter
    let filteredHistory = captchaHistory;
    if (filter && filter !== 'all') {
      filteredHistory = captchaHistory.filter(entry => entry.label === filter);
    }

    if (filteredHistory.length === 0) {
      container.innerHTML = '<div class="no-data">No entries for this category</div>';
      return;
    }

    filteredHistory.forEach(entry => {
      const entryDiv = document.createElement('div');
      entryDiv.className = 'captcha-entry';
      
      const date = new Date(entry.timestamp);
      const dateStr = date.toLocaleString();
      
      // Build tiles distribution HTML
      let tilesHtml = '';
      const distribution = entry.tilesDistribution || {};
      const targetLabel = entry.label;
      
      // Sort: target label first, then unknown, then others
      const sortedLabels = Object.keys(distribution).sort((a, b) => {
        if (a === targetLabel) return -1;
        if (b === targetLabel) return 1;
        if (a === 'unknown') return 1;
        if (b === 'unknown') return -1;
        return 0;
      });
      
      sortedLabels.forEach(label => {
        const info = distribution[label];
        const isTarget = label === targetLabel;
        const isUnknown = label === 'unknown';
        const hasClicked = info.clicked > 0;
        
        let className = 'tile-category';
        if (isTarget) className += ' matched';
        else if (isUnknown) className += ' unknown';
        else if (hasClicked) className += ' clicked';
        
        // Format count display
        let countDisplay = '';
        if (isTarget) {
          countDisplay = info.clicked > 0 ? `${info.count} ✓` : `${info.count}`;
        } else if (info.clicked > 0 && info.clicked < info.count) {
          countDisplay = `${info.count} (${info.clicked}✓)`;
        } else if (info.clicked > 0 && info.clicked === info.count) {
          countDisplay = `${info.count} ✓`;
        } else {
          countDisplay = `${info.count}`;
        }
        
        const displayLabel = label === 'unknown' ? 'unknown' : label.replace('the ', '');
        
        tilesHtml += `
          <span class="${className}">
            <span class="cat-name">${displayLabel}</span>
            <span class="cat-count">${countDisplay}</span>
          </span>
        `;
      });
      
      // Count matched, unknown, wrongCategory clicks
      let matchedClicks = 0, unknownClicks = 0, wrongClicks = 0;
      sortedLabels.forEach(label => {
        const info = distribution[label];
        if (label === targetLabel) {
          matchedClicks = info.clicked || 0;
        } else if (label === 'unknown') {
          unknownClicks = info.clicked || 0;
        } else if (info.clicked > 0) {
          wrongClicks += info.clicked;
        }
      });
      
      let clickedBreakdown = [];
      if (matchedClicks > 0) clickedBreakdown.push(`${matchedClicks} matched`);
      if (unknownClicks > 0) clickedBreakdown.push(`${unknownClicks} unknown`);
      if (wrongClicks > 0) clickedBreakdown.push(`${wrongClicks} wrongCategory`);
      
      const clickedText = `Clicked: <strong>${entry.totalClicked}</strong> (${clickedBreakdown.join(' + ')})`;
      
      // Corrections info
      let correctionsText = '';
      if (entry.corrected > 0 && entry.corrections && entry.corrections.length > 0) {
        const correctionSummary = {};
        entry.corrections.forEach(c => {
          const from = c.from.replace('the ', '');
          if (!correctionSummary[from]) correctionSummary[from] = 0;
          correctionSummary[from]++;
        });
        const correctionParts = Object.entries(correctionSummary)
          .map(([from, count]) => `${from}→${targetLabel.replace('the ', '')}`)
          .join(', ');
        correctionsText = ` (${correctionParts})`;
      }
      
      entryDiv.innerHTML = `
        <div class="captcha-header">
          <span class="captcha-target">Choose all ${targetLabel}</span>
          <span class="captcha-status">SUCCESS</span>
        </div>
        <div class="captcha-body">
          <div class="tiles-distribution">
            <div class="tiles-distribution-title">Tiles detected (9 total):</div>
            ${tilesHtml}
          </div>
          <div class="captcha-summary">
            <span class="summary-item">${clickedText}</span>
            <span class="summary-item learned">Learned: <strong>${entry.learned || 0}</strong></span>
            <span class="summary-item corrected">Corrected: <strong>${entry.corrected || 0}</strong>${correctionsText}</span>
            <span class="summary-item">${dateStr}</span>
          </div>
        </div>
      `;
      
      container.appendChild(entryDiv);
    });
  }

  // Event listeners
  refreshBtn.addEventListener('click', loadAnalytics);

  // Listen for storage changes to auto-refresh
  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'local' && (changes.learningAnalytics || changes.learnedDatabase)) {
      console.log('Analytics data changed, refreshing...');
      loadAnalytics();
    }
  });

  // Initial load
  loadAnalytics();
});
