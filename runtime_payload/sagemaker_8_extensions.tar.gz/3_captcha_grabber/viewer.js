document.addEventListener('DOMContentLoaded', function() {
  const jsonOutput = document.getElementById('json-output');
  const copyBtn = document.getElementById('copy-btn');

  // Check if Chrome APIs are available
  function isChromeExtensionContext() {
    return typeof chrome !== 'undefined' && 
           chrome.storage && 
           chrome.storage.local;
  }

  if (!isChromeExtensionContext()) {
    jsonOutput.textContent = 'Chrome Extension APIs not available';
    copyBtn.disabled = true;
    return;
  }

  // Load learned database
  chrome.storage.local.get('learnedDatabase', function(result) {
    if (chrome.runtime.lastError) {
      console.error('Error loading learned database:', chrome.runtime.lastError);
      jsonOutput.textContent = 'Error loading learned database: ' + chrome.runtime.lastError.message;
      copyBtn.disabled = true;
      return;
    }

    if (!result.learnedDatabase || Object.keys(result.learnedDatabase).length === 0) {
      jsonOutput.textContent = 'No learned data found.';
      copyBtn.disabled = true;
      copyBtn.style.backgroundColor = '#ccc';
      return;
    }

    try {
      // Convert JavaScript object to pretty JSON string
      // Remove opening and closing braces for easy merging
      const jsonString = JSON.stringify(result.learnedDatabase, null, 2);
      const contentWithoutBraces = jsonString.slice(2, -2).trim();
      
      // Display in the pre element
      jsonOutput.textContent = contentWithoutBraces;

      // Copy button functionality
      copyBtn.addEventListener('click', () => {
        if (!navigator.clipboard) {
          // Fallback for older browsers
          const textArea = document.createElement('textarea');
          textArea.value = contentWithoutBraces;
          document.body.appendChild(textArea);
          textArea.select();
          
          try {
            document.execCommand('copy');
            copyBtn.textContent = 'Copied!';
            copyBtn.style.backgroundColor = '#28a745';
          } catch (err) {
            console.error('Fallback copy failed:', err);
            copyBtn.textContent = 'Copy Failed!';
            copyBtn.style.backgroundColor = '#dc3545';
          }
          
          document.body.removeChild(textArea);
          
          setTimeout(() => {
            copyBtn.textContent = 'Copy to Clipboard';
            copyBtn.style.backgroundColor = '#007BFF';
          }, 2000);
        } else {
          // Modern clipboard API
          navigator.clipboard.writeText(contentWithoutBraces).then(() => {
            copyBtn.textContent = 'Copied!';
            copyBtn.style.backgroundColor = '#28a745';
            
            setTimeout(() => {
              copyBtn.textContent = 'Copy to Clipboard';
              copyBtn.style.backgroundColor = '#007BFF';
            }, 2000);
          }).catch(err => {
            console.error('Failed to copy text:', err);
            copyBtn.textContent = 'Copy Failed!';
            copyBtn.style.backgroundColor = '#dc3545';
            
            setTimeout(() => {
              copyBtn.textContent = 'Copy to Clipboard';
              copyBtn.style.backgroundColor = '#007BFF';
            }, 2000);
          });
        }
      });

      // Add additional info
      const entryCount = Object.keys(result.learnedDatabase).length;
      const uniqueLabels = new Set(Object.values(result.learnedDatabase));
      
      const infoDiv = document.createElement('div');
      infoDiv.style.cssText = `
        margin-top: 15px;
        padding: 10px;
        background-color: #e9ecef;
        border-radius: 4px;
        font-size: 14px;
      `;
      infoDiv.innerHTML = `
        <strong>Statistics:</strong><br>
        Total Entries: ${entryCount}<br>
        Unique Labels: ${uniqueLabels.size}<br>
        Labels: ${Array.from(uniqueLabels).join(', ')}
      `;
      
      document.body.appendChild(infoDiv);

    } catch (error) {
      console.error('Error processing learned database:', error);
      jsonOutput.textContent = 'Error processing data: ' + error.message;
      copyBtn.disabled = true;
    }
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'local' && changes.learnedDatabase) {
      // Reload the page when learned database changes
      location.reload();
    }
  });
});