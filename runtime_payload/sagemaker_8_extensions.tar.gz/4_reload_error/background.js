// Fungsi untuk mengecek error di halaman SageMaker
function checkForErrors(tabId) {
    // Fungsi JavaScript yang akan dijalankan di halaman
    function checkErrorScript() {
        const specificErrorMessages = [
            "There is no runtime available right now. Please change the compute type or try again later.",
            "Your user session has ended. Please sign in to continue.",
            "The server currently has too many requests. Please try again later.",
            "Something went wrong. Please allow script downloading from domain *.awswaf.com, refresh the page and try again. See more in FAQ.",
            "Connection failed",
            "Session expired",
            "Service unavailable",
            "Internal server error",
            "Bad gateway",
            "Gateway timeout",
            "Unable to connect",
            "Request timeout",
            "Server error occurred"
        ];

        // Fungsi untuk mengecek teks di elemen-elemen penting saja
        function checkImportantElements() {
            // Hanya cek elemen yang kemungkinan besar mengandung pesan error
            const importantSelectors = [
                '[role="alert"]',
                '[role="alertdialog"]',
                '.alert',
                '.error',
                '.error-message',
                '.notification',
                '.toast',
                '.warning',
                '[class*="error-"]',
                '[class*="alert-"]',
                '[id*="error"]',
                '[id*="alert"]'
            ];

            let importantText = '';
            importantSelectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    // Hanya ambil elemen yang terlihat
                    if (element.offsetParent !== null && (element.innerText || element.textContent)) {
                        importantText += ' ' + (element.innerText || element.textContent);
                    }
                });
            });

            return importantText.toLowerCase();
        }

        // Fungsi untuk mengecek elemen overlay/modal khusus yang benar-benar error
        function checkErrorOverlays() {
            const errorOverlaySelectors = [
                '[role="dialog"][aria-label*="error" i]',
                '[role="dialog"][aria-label*="failed" i]',
                '.modal.error',
                '.overlay.error',
                '.dialog.error',
                '.captcha-container .error',
                '[class*="error-dialog"]',
                '[class*="error-modal"]',
                '[class*="error-overlay"]'
            ];

            let errorOverlayText = '';
            errorOverlaySelectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    if (element.offsetParent !== null) { // Element is visible
                        errorOverlayText += ' ' + (element.innerText || element.textContent || '');
                    }
                });
            });

            return errorOverlayText.toLowerCase();
        }

        // Gabungkan teks dari area yang relevan saja
        const importantText = checkImportantElements();
        const overlayText = checkErrorOverlays();
        const combinedText = (importantText + ' ' + overlayText).toLowerCase();

        // Debug: log apa yang sedang dicek (hanya jika ada teks)
        if (combinedText.trim().length > 0) {
            console.log('Checking text:', combinedText.substring(0, 200) + '...');
        }

        // Periksa apakah salah satu pesan error spesifik muncul
        for (let message of specificErrorMessages) {
            if (combinedText.includes(message.toLowerCase())) {
                console.log('Specific error detected:', message);
                return true; // Error ditemukan
            }
        }

        // Cek elemen dengan style error yang benar-benar menunjukkan error
        const criticalErrorElements = document.querySelectorAll('.alert-danger, .text-danger, .error-critical, [style*="color: red"][class*="error"]');
        if (criticalErrorElements.length > 0) {
            for (let element of criticalErrorElements) {
                if (element.offsetParent !== null && element.innerText && element.innerText.trim().length > 0) {
                    // Pastikan ini benar-benar pesan error, bukan sekedar elemen merah
                    const elementText = element.innerText.toLowerCase();
                    if (elementText.includes('error') || elementText.includes('failed') || elementText.includes('unable')) {
                        console.log('Critical error element detected:', element.innerText);
                        return true;
                    }
                }
            }
        }

        return false; // Tidak ada error
    }

    // Jalankan fungsi di tab aktif
    chrome.scripting.executeScript(
        {
            target: { tabId: tabId },
            func: checkErrorScript,
        },
        (results) => {
            if (results && results[0] && results[0].result) {
                console.log('Reloading tab due to error detection');
                chrome.tabs.reload(tabId);
            } else {
                console.log('No errors detected, continuing normal operation');
            }
        }
    );
}

// Jalankan pengecekan setiap 31 detik (hanya di luar halaman login agar tidak mengganggu proses login/captcha)
setInterval(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0 && tabs[0].url && tabs[0].url.includes("studiolab.sagemaker.aws") && !tabs[0].url.includes("/login")) {
            checkForErrors(tabs[0].id);
        }
    });
}, 31000); // Diubah dari 10000 ke 21000 (21 detik)

// Listener saat ekstensi diinstal
chrome.runtime.onInstalled.addListener(() => {
    // Membuat alarm yang berjalan setiap 4 menit
    chrome.alarms.create('keepAlive', { periodInMinutes: 4 });
});

// Listener saat Chrome dibuka kembali
chrome.runtime.onStartup.addListener(() => {
    chrome.alarms.create('keepAlive', { periodInMinutes: 4 });
});

// Listener untuk alarm
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'keepAlive') {
        // Keeping service worker alive
    }
});