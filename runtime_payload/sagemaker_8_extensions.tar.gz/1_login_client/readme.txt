untuk 
1. XDAG
2. 10 deti ganti akun