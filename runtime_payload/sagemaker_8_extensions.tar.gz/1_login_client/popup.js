// popup.js

// Deklarasi elemen secara global agar bisa diakses semua fungsi
let workerIdInput, saveWorkerIdBtn, workerIdStatus;
let accountListTextarea, loginCountSpan, activeAccountSpan, activeAccountIndexSpan, accountCountSpan, problematicCountSpan;
let changeAccountButton, clearTabsButton, saveButton, resetButton, exportConfigBtn;
let problematicAccountList, retryStatus, retryStatusText, restoreAccountBtn, clearProblematicBtn, copyProblematicBtn, cleanFormatBtn;
let debugHeader, debugSection, testUrlInput, testUrlBtn, testResult, forceAccountSwitchBtn;

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  workerIdInput = document.getElementById("workerId");
  saveWorkerIdBtn = document.getElementById("saveWorkerIdBtn");
  workerIdStatus = document.getElementById("workerIdStatus");
  accountListTextarea = document.getElementById("accountList");
  loginCountSpan = document.getElementById("loginCount");
  activeAccountSpan = document.getElementById("activeAccount");
  activeAccountIndexSpan = document.getElementById("activeAccountIndex");
  accountCountSpan = document.getElementById("accountCount");
  problematicCountSpan = document.getElementById("problematicCount");

  changeAccountButton = document.getElementById("changeAccountButton");
  clearTabsButton = document.getElementById("clearTabsButton");
  saveButton = document.getElementById("saveButton");
  resetButton = document.getElementById("resetButton");
  exportConfigBtn = document.getElementById("exportConfigBtn");

  // Elemen baru untuk akun bermasalah dan retry status
  problematicAccountList = document.getElementById("problematicAccountList");
  retryStatus = document.getElementById("retryStatus");
  retryStatusText = document.getElementById("retryStatusText");
  restoreAccountBtn = document.getElementById("restoreAccountBtn");
  clearProblematicBtn = document.getElementById("clearProblematicBtn");
  copyProblematicBtn = document.getElementById("copyProblematicBtn");
  cleanFormatBtn = document.getElementById("cleanFormatBtn");

  // Debug elements
  debugHeader = document.getElementById("debugHeader");
  debugSection = document.getElementById("debugSection");
  testUrlInput = document.getElementById("testUrlInput");
  testUrlBtn = document.getElementById("testUrlBtn");
  testResult = document.getElementById("testResult");
  forceAccountSwitchBtn = document.getElementById("forceAccountSwitchBtn");

  // Load Data Awal & pemicu cek restore background
  loadData();
  try {
    chrome.runtime.sendMessage({ action: "popup_opened" });
  } catch(e) {}

  // ================================
  // EVENT LISTENERS
  // ================================

  saveWorkerIdBtn.addEventListener("click", () => {
    const workerId = workerIdInput.value.trim();
    if (workerId) {
      chrome.storage.local.set({ workerId: workerId }, () => {
        workerIdStatus.style.display = "inline";
        setTimeout(() => workerIdStatus.style.display = "none", 3000);
      });
    } else {
      alert("Worker ID tidak boleh kosong!");
    }
  });

  debugHeader.addEventListener("click", () => debugSection.classList.toggle("visible"));
  saveButton.addEventListener("click", handleSaveAccounts);
  resetButton.addEventListener("click", resetCounter);
  if (exportConfigBtn) exportConfigBtn.addEventListener("click", handleExportConfig);
  changeAccountButton.addEventListener("click", handleChangeAccount);
  clearTabsButton.addEventListener("click", handleClearTabsAndCache);
  
  restoreAccountBtn.addEventListener("click", restoreProblematicAccount);
  clearProblematicBtn.addEventListener("click", clearAllProblematicAccounts);
  copyProblematicBtn.addEventListener("click", copyProblematicAccountsToClipboard);
  
  if (cleanFormatBtn) cleanFormatBtn.addEventListener("click", cleanAccountFormat);
  
  // Pendaftaran event listener untuk pesan dari Background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "update_retry_status") {
      updateRetryStatus(message.status, message.show, message.color);
    } else if (message.action === "refresh_display") {
      loadData();
    }
  });
});

function getTodayDateKey() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const date = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${date}`;
}

/**
 * Perbarui tampilan akun: daftar akun, loginCount (24 jam), activeAccount.
 */
function updateDisplay(data) {
  if (data.accounts) {
    accountListTextarea.value = data.accounts;
  }
  if (data.problematicAccounts) {
    problematicAccountList.value = data.problematicAccounts;
  }
  const todayKey = getTodayDateKey();
  const count24h = typeof data.loginCount === 'number' ? data.loginCount : 0;
  loginCountSpan.textContent = count24h;
  activeAccountSpan.textContent = data.activeAccount
    ? data.activeAccount.split("|")[0]
    : "-";
  
  // Hitung jumlah akun
  const accountLines = data.accounts 
    ? data.accounts.split("\n").filter(line => line.trim() !== "") 
    : [];
  accountCountSpan.textContent = `${accountLines.length} akun`;
  
  // Hitung jumlah akun bermasalah
  const problematicLines = data.problematicAccounts 
    ? data.problematicAccounts.split("\n").filter(line => line.trim() !== "") 
    : [];
  problematicCountSpan.textContent = `${problematicLines.length} akun`;
  
  // Cari nomor baris akun aktif
  if (data.activeAccount && accountLines.length > 0) {
    const activeIndex = accountLines.findIndex(acc => acc === data.activeAccount);
    if (activeIndex !== -1) {
      activeAccountIndexSpan.textContent = `(baris ${activeIndex + 1}/${accountLines.length})`;
    } else {
      activeAccountIndexSpan.textContent = "";
    }
  } else {
    activeAccountIndexSpan.textContent = "";
  }
}

/**
 * Update status retry di GUI
 */
function updateRetryStatus(message, show = true, color = "") {
  if (show) {
    retryStatusText.textContent = message;
    
    if (color === "green") {
      retryStatus.style.backgroundColor = "#d4edda";
      retryStatus.style.color = "#155724";
      retryStatus.style.borderColor = "#c3e6cb";
      retryStatus.style.padding = "8px";
      retryStatus.style.borderRadius = "4px";
      retryStatus.style.border = "1px solid #c3e6cb";
    } else {
      retryStatus.style.backgroundColor = "";
      retryStatus.style.color = "";
      retryStatus.style.borderColor = "";
      retryStatus.style.padding = "";
      retryStatus.style.borderRadius = "";
      retryStatus.style.border = "";
    }
    
    retryStatus.style.display = "block";
  } else {
    retryStatus.style.display = "none";
  }
}

/**
 * Validate and fix account format in storage
 * Accounts should be in format: username|password
 */
function validateAccountFormat() {
  chrome.storage.local.get(["accounts", "activeAccount"], (items) => {
    console.log("🔍 [popup] Validating account format...");
    console.log("🔍 Current accounts:", items.accounts);
    console.log("🔍 Current activeAccount:", items.activeAccount);
    
    // Check main accounts list
    if (items.accounts) {
      const accountLines = items.accounts.split("\n").filter(line => line.trim() !== "");
      let hasInvalidAccounts = false;
      
      accountLines.forEach((account, index) => {
        if (!account.includes("|")) {
          console.error(`❌ [popup] Account ${index + 1} missing password: '${account}'`);
          hasInvalidAccounts = true;
        } else {
          const [username, password] = account.split("|");
          if (!username || !password || password === 'undefined' || password.trim() === '') {
            console.error(`❌ [popup] Account ${index + 1} has invalid password: Username='${username}', Password='${password}'`);
            hasInvalidAccounts = true;
          }
        }
      });
      
      if (hasInvalidAccounts) {
        alert("⚠️ ACCOUNT FORMAT ERROR!\n\nSome accounts are missing passwords. Please check your account list and ensure all accounts are in format:\n\nusername|password\n\nExample:\nuser@email.com|mypassword123\n\nPlease fix the account format and reload the extension.");
      }
    }
    
    // Check activeAccount
    if (items.activeAccount && !items.activeAccount.includes("|")) {
      console.error(`❌ [popup] ActiveAccount missing password: '${items.activeAccount}'`);
      alert("⚠️ ACTIVE ACCOUNT ERROR!\n\nThe active account is missing its password. This will cause login failures.\n\nPlease check your account list and ensure the active account has a password.");
    }
  });
}

/**
 * Muat data dari chrome.storage dan tampilkan di UI.
 */
function loadData() {
  const todayKey = `dailyPaste_${getTodayDateKey()}`;
  chrome.storage.local.get(
    ["workerId", "accounts", "originalAccounts", "loginCount", "loginCountDate", "activeAccount", "problematicAccounts", todayKey],
    (items) => {
      // Load Worker ID
      if (items.workerId) {
        document.getElementById("workerId").value = items.workerId;
      }

      // Hitung total eksekusi login/paste riil dari seluruh akun dalam siklus 24 jam hari ini
      const history = items[todayKey] || {};
      let total24h = 0;
      Object.values(history).forEach(item => {
        if (item && typeof item.count === 'number') {
          total24h += item.count;
        }
      });

      // Jika belum ada paste di history tapi ada loginCount hari ini, pakai loginCount
      if (total24h === 0 && items.loginCountDate === getTodayDateKey() && typeof items.loginCount === 'number') {
        total24h = items.loginCount;
      }

      items.loginCount = total24h;
      updateDisplay(items);
      
      // Validate account format after loading
      validateAccountFormat();
    }
  );
}



/**
 * Enhanced manual account change with better error handling
 */
function changeAccount() {
  // Disable button to prevent double-clicking
  changeAccountButton.disabled = true;
  changeAccountButton.textContent = "Switching...";
  
  chrome.storage.local.get(["accounts", "loginCount", "activeAccount"], (items) => {
    try {
      const accountLines = items.accounts
        ? items.accounts.split("\n").filter((line) => line.trim() !== "")
        : [];
      if (accountLines.length === 0) {
        alert("Daftar akun kosong. Silakan tambahkan akun terlebih dahulu.");
        return;
      }

      // Validate all accounts before proceeding
      const invalidAccounts = accountLines.filter(account => {
        return !account.includes("|") || account.split("|").length !== 2;
      });
      
      if (invalidAccounts.length > 0) {
        alert(`⚠️ Ada ${invalidAccounts.length} akun dengan format tidak valid. Pastikan semua akun dalam format: email|password`);
        return;
      }

      // ENHANCED: Use centralized sequence management instead of local calculation
      // Send message to background to handle account switching with persistent sequence
      chrome.runtime.sendMessage(
        { action: "switch_account_from_popup" },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error(`[popup] Failed to switch account:`, chrome.runtime.lastError.message);
            alert(`❌ Error switching account: ${chrome.runtime.lastError.message}`);
          } else {
            console.log(`[popup] ✅ Account switch request sent to background`);
            // Refresh display to show new active account
            setTimeout(() => {
              loadData();
            }, 1000);
          }
        }
      );
    } catch (err) {
      console.error(`[popup] Error in changeAccount:`, err);
      alert(`❌ Error saat mengganti akun: ${err.message}`);
    } finally {
      // Re-enable button
      changeAccountButton.disabled = false;
      changeAccountButton.textContent = "Ganti Akun";
    }
  });
}

/**
 * Restore semua akun dari daftar bermasalah kembali ke daftar utama
 */
function restoreProblematicAccount() {
  const problematicText = problematicAccountList.value.trim();
  if (problematicText === "") {
    alert("Tidak ada akun bermasalah untuk di-restore.");
    return;
  }
  
  const problematicLines = problematicText.split("\n").filter(line => line.trim() !== "");
  if (problematicLines.length === 0) {
    alert("Tidak ada akun bermasalah untuk di-restore.");
    return;
  }
  
  const accountCount = problematicLines.length;
  const confirmMessage = `Yakin ingin me-restore semua ${accountCount} akun bermasalah ke daftar utama?`;
  
  if (!confirm(confirmMessage)) {
    return;
  }
  
  // Restore semua akun sekaligus
  chrome.storage.local.get(["accounts"], (items) => {
    const currentAccounts = items.accounts || "";
    
    // Gabungkan semua akun bermasalah ke daftar utama
    const allAccountsToRestore = problematicLines.join("\n");
    const newAccounts = currentAccounts ? 
      currentAccounts + "\n" + allAccountsToRestore : 
      allAccountsToRestore;
    
    chrome.storage.local.set({
      accounts: newAccounts,
      problematicAccounts: "" // Clear semua akun bermasalah
    }, () => {
      // Immediately update the textareas to show instant feedback
      accountListTextarea.value = newAccounts;
      problematicAccountList.value = "";
      // Sinkronkan ke Supabase — hapus entri PROBLEM di dashboard
      chrome.runtime.sendMessage({ action: "sync_delete_from_supabase", status: "PROBLEM" });
      // Also reload data to ensure consistency
      loadData();
      alert(`Berhasil me-restore ${accountCount} akun ke daftar utama.`);
    });
  });
}

/**
 * Copy problematic accounts to clipboard
 */
function copyProblematicAccountsToClipboard() {
  const problematicText = problematicAccountList.value.trim();
  if (problematicText === "") {
    alert("Tidak ada akun bermasalah untuk di-copy.");
    return;
  }
  
  // Copy to clipboard
  navigator.clipboard.writeText(problematicText).then(() => {
    const accountCount = problematicText.split("\n").filter(line => line.trim() !== "").length;
    alert(`Berhasil copy ${accountCount} akun bermasalah ke clipboard.`);
  }).catch(err => {
    console.error('Failed to copy to clipboard:', err);
    // Fallback method for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = problematicText;
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      const accountCount = problematicText.split("\n").filter(line => line.trim() !== "").length;
      alert(`Berhasil copy ${accountCount} akun bermasalah ke clipboard.`);
    } catch (fallbackErr) {
      alert('Gagal copy ke clipboard. Silakan copy manual.');
    } finally {
      document.body.removeChild(textArea);
    }
  });
}

/**
 * Clear semua akun bermasalah
 */
function clearAllProblematicAccounts() {
  if (confirm("Yakin ingin menghapus semua akun bermasalah?")) {
    chrome.storage.local.set({ problematicAccounts: "" }, () => {
      // Immediately clear the textarea to show instant feedback
      problematicAccountList.value = "";
      // Sinkronkan ke Supabase
      chrome.runtime.sendMessage({ action: "sync_delete_from_supabase", status: "PROBLEM" });
      // Also reload data to ensure consistency
      loadData();
      alert("Semua akun bermasalah telah dihapus.");
    });
  }
}


/**
 * WebSocket functionality removed - was used to send status to server
 */
function sendStatusToServer(activity) {
  // WebSocket functionality removed
  console.log(`[popup] Activity: ${activity}`);
}

/**
 * Tombol Reset Counter
 */
function resetCounter() {
  const todayKey = `dailyPaste_${getTodayDateKey()}`;
  chrome.storage.local.set(
    { loginCount: 0, loginCountDate: getTodayDateKey(), [todayKey]: {}, activeAccount: null, activeAccountTimestamp: null },
    () => {
      updateDisplay({ accounts: accountListTextarea.value, loginCount: 0, loginCountDate: getTodayDateKey(), activeAccount: null });
      alert("Login counter 24 jam berhasil di-reset ke 0.");
      // WebSocket functionality removed - sendStatusToServer("counter_reset");
    }
  );
}

/**
 * Tombol Simpan Daftar Akun dengan sequence state initialization
 */
function handleSaveAccounts() {
  const text = accountListTextarea.value.trim();
  if (text === "") {
    alert("Daftar akun tidak boleh kosong.");
    return;
  }
  
  // Initialize sequence state when saving accounts
  const accountLines = text.split("\n").filter(line => line.trim() !== "");
  const sequenceState = {
    originalSequence: accountLines,
    currentIndex: -1,
    lastActiveAccount: null
  };
  
  chrome.storage.local.set({ 
    accounts: text, 
    originalAccounts: text,
    account_sequence_state: sequenceState
  }, () => {
    alert("Daftar akun berhasil disimpan.");
    console.log(`[popup] 💾 Initialized sequence state for ${accountLines.length} accounts`);
    
    // Perbarui tampilan
    chrome.storage.local.get(["loginCount", "activeAccount"], (items) => {
      updateDisplay({ accounts: text, loginCount: items.loginCount, activeAccount: items.activeAccount });
    });
    // WebSocket functionality removed - sendStatusToServer("accounts_saved");
  });
}

/**
 * Otomatis mengonversi daftar akun dari antarmuka GUI dan ID Worker
 * ke dalam format JSON yang valid, lalu menyimpannya langsung ke file config.json
 * tanpa mengharuskan pengguna mengetik sintaks JSON manual.
 */
async function handleExportConfig() {
  const workerId = (workerIdInput.value || "PC-01").trim();
  const text = accountListTextarea.value.trim();

  const accountLines = text
    ? text.split("\n").map(l => l.trim()).filter(l => l && l.includes("|"))
    : [];

  if (accountLines.length === 0) {
    alert("Daftar akun masih kosong atau belum berformat username|password.");
    return;
  }

  const configObj = {
    workerId: workerId || "PC-01",
    accounts: accountLines
  };

  const jsonString = JSON.stringify(configObj, null, 2);

  // 1. Coba File System Access API jika didukung browser Chrome
  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: "config.json",
        types: [{
          description: "JSON Configuration File",
          accept: { "application/json": [".json"] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(jsonString);
      await writable.close();
      alert(`✅ File config.json berhasil disimpan langsung ke folder!\n\nID: ${configObj.workerId}\nTotal: ${accountLines.length} akun.`);
      return;
    } catch (err) {
      if (err.name === "AbortError") return; // user batalkan dialog
      console.warn("showSaveFilePicker fallback:", err);
    }
  }

  // 2. Fallback: Unduh otomatis file config.json
  try {
    const blob = new Blob([jsonString], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "config.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    alert(`✅ File config.json berhasil di-generate & diunduh otomatis!\n\nID: ${configObj.workerId}\nTotal: ${accountLines.length} akun.\n\nAnda tidak perlu edit manual, cukup pindahkan/timpa file ini ke folder ekstensi Anda.`);
  } catch (e) {
    // 3. Fallback salin ke clipboard jika unduh terhalang
    navigator.clipboard.writeText(jsonString).then(() => {
      alert("✅ Format config.json telah disalin ke clipboard! Anda tinggal paste ke file config.json tanpa perlu menyusun JSON manual.");
    });
  }
}

/**
 * Tombol Tutup Semua Tab & Hapus Cache
 */
function handleClearTabsAndCache() {
  clearTabsButton.disabled = true;
  clearTabsButton.textContent = "Sedang Berjalan…";
  chrome.runtime.sendMessage({ action: "clearTabsAndCache" });
  // Tidak perlu re-enable karena saat semua tab tertutup, popup akan otomatis tertutup
}

// ================================
// 3. Event Listeners
// ================================
document.addEventListener("DOMContentLoaded", () => {
  // Muat data awal
  loadData();
  // WebSocket connection status removed - getConnectionStatus();

  // WebSocket functionality removed - saveProfileBtn and connectBtn

  // Simpan Daftar Akun
  saveButton.addEventListener("click", handleSaveAccounts);

  // Reset Counter
  resetButton.addEventListener("click", resetCounter);

  // Ganti Akun Manual
  changeAccountButton.addEventListener("click", changeAccount);

  // Tutup Tab & Hapus Cache
  clearTabsButton.addEventListener("click", handleClearTabsAndCache);
  
  // Restore & Clear Problematic Accounts
  restoreAccountBtn.addEventListener("click", restoreProblematicAccount);
  clearProblematicBtn.addEventListener("click", clearAllProblematicAccounts);
  copyProblematicBtn.addEventListener("click", copyProblematicAccountsToClipboard);
  
  // Restore & Clear Phone Verification Accounts (BIRU)
  restorePhoneBtn.addEventListener("click", restorePhoneVerificationAccounts);
  copyPhoneBtn.addEventListener("click", copyPhoneVerificationToClipboard);
  clearPhoneBtn.addEventListener("click", clearAllPhoneVerificationAccounts);

  // Pendaftaran event listener untuk pesan dari Background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "update_retry_status") {
      updateRetryStatus(message.status, message.show, message.color);
    } else if (message.action === "refresh_display") {
      loadData();
    }
    return false;
  });
}); // <--- PENUTUP YANG BENAR UNTUK DOMContentLoaded

// ================================
// END OF DOMContentLoaded
// ================================
