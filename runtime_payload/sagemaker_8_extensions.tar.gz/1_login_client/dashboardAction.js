// dashboardAction.js
// Deteksi phone verification requirement di halaman dashboard

console.log("[dashboardAction] Script injected, URL:", window.location.href);

let phoneCheckTriggered = false;
let projectErrorCheckTriggered = false;

/**
 * Deteksi apakah teks merupakan banner pengumuman/informasi AWS SageMaker (bukan error)
 */
function isAnnouncementNotice(text) {
  if (!text) return false;
  const lowerText = text.toLowerCase();
  
  const announcementPatterns = [
    "no longer be open to new customers",
    "no longer open to new customers",
    "is no longer open",
    "explore amazon sagemaker studio",
    "capabilities similar to amazon sagemaker studio lab",
    "sagemaker studio (free tier)"
  ];
  
  return announcementPatterns.some(pattern => lowerText.includes(pattern));
}

/**
 * Deteksi popup phone verification dengan multiple strategies
 */
function detectPhoneVerificationPopup() {
  const bodyText = (document.body.innerText || document.body.textContent || "").toLowerCase();
  
  // Strategy 1: Check visible modal / dialog containers for explicit phone verification prompts
  const dialogSelectors = [
    "[role='dialog']",
    "[role='alertdialog']",
    ".modal",
    ".dialog",
    ".popup",
    "[class*='modal' i]",
    "[class*='dialog' i]",
    "[class*='popup' i]"
  ];
  
  for (const selector of dialogSelectors) {
    try {
      const dialogs = document.querySelectorAll(selector);
      for (const dialog of dialogs) {
        if (isElementVisible(dialog)) {
          const dialogText = (dialog.innerText || dialog.textContent || "").toLowerCase();
          if (isAnnouncementNotice(dialogText)) continue;
          
          const phoneKeywords = [
            "mobile phone number required",
            "phone number required",
            "add a mobile number",
            "verify your number",
            "verify your mobile",
            "enter phone number",
            "mobile verification",
            "phone verification"
          ];
          
          if (phoneKeywords.some(kw => dialogText.includes(kw))) {
            console.log(`[dashboardAction] ⚠️ Phone verification dialog detected with text: "${dialogText.substring(0, 60)}..."`);
            return true;
          }
        }
      }
    } catch (err) {
      // Ignore selector errors
    }
  }

  // Strategy 2: Check visible phone input elements
  const telInputSelectors = [
    "input[type='tel']",
    "input[name*='phone' i]",
    "input[name*='mobile' i]"
  ];
  
  for (const selector of telInputSelectors) {
    try {
      const inputs = document.querySelectorAll(selector);
      for (const input of inputs) {
        if (isElementVisible(input)) {
          console.log(`[dashboardAction] ⚠️ Visible phone input field detected via selector: "${selector}"`);
          return true;
        }
      }
    } catch (err) {
      // Ignore selector errors
    }
  }
  
  return false;
}

/**
 * Check if element is visible
 */
function isElementVisible(element) {
  if (!element) return false;
  
  // Check basic visibility
  if (element.offsetParent === null && 
      window.getComputedStyle(element).position !== 'fixed') {
    return false;
  }
  
  const style = window.getComputedStyle(element);
  return style.display !== 'none' && 
         style.visibility !== 'hidden' && 
         style.opacity !== '0' &&
         element.offsetWidth > 0 && 
         element.offsetHeight > 0;
}

/**
 * Handle ketika project error terdeteksi (Disabled - Pergantian akun hanya pada 3 kondisi resmi)
 */
function handleProjectLoadingError() {
  // Disabled: Biarkan ekstensi lain atau user yang mengelola runtime tanpa memicu switch akun prematur
  return;
}

/**
 * Deteksi error "problem when loading your project" (Disabled)
 */
function detectProjectLoadingError() {
  return false;
}

/**
 * Handle ketika phone verification terdeteksi
 */
function handlePhoneVerificationRequired() {
  if (phoneCheckTriggered) return;
  phoneCheckTriggered = true;
  
  console.log("[dashboardAction] 📱 Phone verification required - sending to background");
  
  // Kirim langsung ke background, biarkan background yang ambil activeAccount
  chrome.runtime.sendMessage({
    action: "phone_verification_detected",
    errorType: "phone_verification_required",
    errorMessage: "Mobile phone number required - Account needs phone verification"
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("[dashboardAction] ❌ Failed to send message:", chrome.runtime.lastError.message);
      // Retry sekali setelah 2 detik
      setTimeout(() => {
        chrome.runtime.sendMessage({
          action: "phone_verification_detected",
          errorType: "phone_verification_required",
          errorMessage: "Mobile phone number required - Account needs phone verification (retry)"
        });
      }, 2000);
    } else {
      console.log("[dashboardAction] ✅ Message sent to background successfully");
    }
  });
}

/**
 * Setup MutationObserver untuk mendeteksi popup yang muncul dinamis
 */
function setupMutationObserver() {
  console.log("[dashboardAction] Setting up MutationObserver for dynamic popup detection...");
  
  let debounceTimer = null;
  
  const observer = new MutationObserver((mutations) => {
    if (phoneCheckTriggered || projectErrorCheckTriggered) {
      observer.disconnect();
      return;
    }
    
    // Debounce untuk menghindari check berlebihan
    if (debounceTimer) clearTimeout(debounceTimer);
    
    debounceTimer = setTimeout(() => {
      // Cek setiap ada perubahan DOM
      if (detectPhoneVerificationPopup()) {
        console.log("[dashboardAction] 🎯 Phone verification popup detected via MutationObserver!");
        observer.disconnect();
        handlePhoneVerificationRequired();
      }
      
      if (detectProjectLoadingError()) {
        console.log("[dashboardAction] 🎯 Project error detected via MutationObserver!");
        observer.disconnect();
        handleProjectLoadingError();
      }
    }, 300); // Debounce 300ms
  });
  
  // Observe seluruh body untuk perubahan
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'hidden']
  });
  
  // Stop observer setelah 50 menit (sepanjang waktu utama ekstensi)
  setTimeout(() => {
    if (!phoneCheckTriggered && !projectErrorCheckTriggered) {
      console.log("[dashboardAction] ⏰ Observer timeout (50 minutes) - stopping observation");
      observer.disconnect();
    }
  }, 3000000); // 50 menit
  
  return observer;
}

/**
 * Periodic check sebagai backup - lebih agresif
 */
function startPeriodicCheck() {
  let checkCount = 0;
  const maxChecks = 1500; // 1500 checks x 2 seconds = 50 minutes
  
  const intervalId = setInterval(() => {
    if (phoneCheckTriggered || projectErrorCheckTriggered) {
      clearInterval(intervalId);
      return;
    }
    
    checkCount++;
    
    // Log setiap 30 detik (15 checks) saja untuk mengurangi spam
    if (checkCount % 15 === 0) {
      console.log(`[dashboardAction] Periodic check #${checkCount}/${maxChecks}...`);
    }
    
    if (detectPhoneVerificationPopup()) {
      console.log("[dashboardAction] 🎯 Phone verification popup detected via periodic check!");
      clearInterval(intervalId);
      handlePhoneVerificationRequired();
      return;
    }
    
    if (detectProjectLoadingError()) {
      console.log("[dashboardAction] 🎯 Project error detected via periodic check!");
      clearInterval(intervalId);
      handleProjectLoadingError();
      return;
    }
    
    if (checkCount >= maxChecks) {
      console.log("[dashboardAction] ✅ No phone/project error detected after 50 minutes");
      clearInterval(intervalId);
    }
  }, 2000); // Check setiap 2 detik
  
  return intervalId;
}

/**
 * Quick initial checks dengan multiple delays
 */
function runInitialChecks() {
  // Check segera
  if (detectPhoneVerificationPopup()) {
    console.log("[dashboardAction] 🎯 Phone verification detected immediately!");
    handlePhoneVerificationRequired();
    return true;
  }
  
  if (detectProjectLoadingError()) {
    console.log("[dashboardAction] 🎯 Project error detected immediately!");
    handleProjectLoadingError();
    return true;
  }
  
  // Check setelah berbagai delay untuk menangkap popup yang muncul lambat
  const delays = [500, 1000, 2000, 3000, 5000];
  
  delays.forEach(delay => {
    setTimeout(() => {
      if (!phoneCheckTriggered && detectPhoneVerificationPopup()) {
        console.log(`[dashboardAction] 🎯 Phone verification detected after ${delay}ms!`);
        handlePhoneVerificationRequired();
      }
      if (!projectErrorCheckTriggered && detectProjectLoadingError()) {
        console.log(`[dashboardAction] 🎯 Project error detected after ${delay}ms!`);
        handleProjectLoadingError();
      }
    }, delay);
  });
  
  return false;
}

/**
 * Inisialisasi
 */
function init() {
  console.log("[dashboardAction] Initializing on dashboard page...");
  console.log("[dashboardAction] Current URL:", window.location.href);
  
  // Run initial checks dengan multiple timing
  const foundImmediately = runInitialChecks();
  
  if (!foundImmediately) {
    // Setup observer untuk deteksi dinamis
    setupMutationObserver();
    
    // Backup: periodic check yang lebih agresif
    startPeriodicCheck();
  }
}

// Entry point - pastikan DOM sudah siap
if (document.readyState === "complete") {
  init();
} else if (document.readyState === "interactive") {
  // DOM ready tapi resources mungkin masih loading
  setTimeout(init, 500);
} else {
  window.addEventListener("DOMContentLoaded", () => {
    setTimeout(init, 500); // Tambah delay setelah DOMContentLoaded
  });
}

// Fallback: jika load event belum terjadi
window.addEventListener("load", () => {
  if (!phoneCheckTriggered) {
    console.log("[dashboardAction] Window load event - running additional check");
    setTimeout(() => {
      if (!phoneCheckTriggered && detectPhoneVerificationPopup()) {
        console.log("[dashboardAction] 🎯 Phone verification detected on window load!");
        handlePhoneVerificationRequired();
      }
    }, 1000);
  }
});
