// background.js

// ================================
// 1. Variabel dan Inisialisasi Global
// ================================

// Timer untuk pergantian akun otomatis
let accountSwitchTimer = null;
const ACCOUNT_SWITCH_INTERVAL = 50 * 60 * 1000; // 50 menit dalam milidetik
let timeRemaining = ACCOUNT_SWITCH_INTERVAL;
let isTimerRunning = false;

// Timer untuk auto-close tabs dan switch account jika bukan di halaman dashboard (/users/*) (3 menit)
let inactivityTimer = null;
const INACTIVITY_TIMEOUT = 3 * 60 * 1000; // 3 menit dalam milidetik
let inactivityTimeRemaining = INACTIVITY_TIMEOUT;
const INACTIVITY_TIMER_STORAGE_KEY = "inactivity_timer_start";
let isInactivityTimerRunning = false;
let lastKnownPage = null;
let tabLoadingStates = new Map(); // Track loading states for each tab
let extensionNavigationInProgress = false; // Flag untuk extension-triggered navigation

// Cooldown & lock untuk mencegah loop ganti akun beruntun dalam hitungan detik
let isAccountSwitchingLock = false;
let lastAccountSwitchTime = 0;
const ACCOUNT_SWITCH_COOLDOWN_MS = 15000; // 15 detik cooldown minimal antar switch

// Set untuk menyimpan tabId yang sudah pernah dipicu switch akun
const switchedTabs = new Set();

// Daftar halaman yang dikenal (tidak memicu inactivity timer)
const KNOWN_PAGES = [
  'chrome://extensions/',
  'chrome://newtab/',
  'chrome-extension://',
  'data:text/html'
];

// LOGIKA BARU:
// ✅ SEMUA SageMaker domains (*.sagemaker.aws) = SAFE = Badge hijau (timer utama)
// ❌ NON-SageMaker domains = UNKNOWN = Badge orange (timer 7 menit)
// ❌ about:blank (new tab) = UNKNOWN = Badge orange (timer 7 menit)

// PERSISTENT ACCOUNT SEQUENCE STATE & DAILY 24-HOUR PASTE TRACKER
const ACCOUNT_SEQUENCE_KEY = "account_sequence_state";

/**
 * Mendapatkan format tanggal hari ini (YYYY-MM-DD) berdasarkan jam lokal (reset jam 12 malam)
 */
function getTodayDateKey() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const date = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${date}`;
}

/**
 * Membaca riwayat jumlah paste hari ini untuk seluruh akun
 */
async function getDailyPasteHistory() {
  const todayKey = `dailyPaste_${getTodayDateKey()}`;
  const data = await new Promise(r => chrome.storage.local.get([todayKey], r));
  return data[todayKey] || {};
}

/**
 * Menghitung total seluruh paste/login sukses dari semua akun hari ini (siklus 24 jam)
 */
async function getDailyTotalLogins() {
  const history = await getDailyPasteHistory();
  let total = 0;
  Object.values(history).forEach(item => {
    if (item && typeof item.count === 'number') {
      total += item.count;
    }
  });
  return total;
}

/**
 * Otomatis memuat konfigurasi dari config.json (workerId & accounts)
 * Mengunci akun aktif terakhir (persistent) agar browser yang di-close
 * saat dibuka kembali tetap melanjutkan dari akun terakhir, bukan kembali ke akun #1.
 */
async function loadConfigFile() {
  try {
    const configUrl = chrome.runtime.getURL("config.json");
    const response = await fetch(configUrl);
    if (!response.ok) {
      console.log("[Config] config.json tidak ditemukan, menggunakan penyimpanan lokal yang ada.");
      return;
    }
    const config = await response.json();
    if (!config) return;

    const storage = await new Promise((r) =>
      chrome.storage.local.get(["workerId", "accounts", "activeAccount", ACCOUNT_SEQUENCE_KEY], r)
    );

    const updates = {};

    // 1. Worker ID: set jika ada di config.json
    if (config.workerId && typeof config.workerId === "string") {
      const trimmedWid = config.workerId.trim();
      if (trimmedWid && storage.workerId !== trimmedWid) {
        console.log(`[Config] ⚙️ Sinkronisasi workerId dari config.json: ${trimmedWid}`);
        updates.workerId = trimmedWid;
      }
    }

    // 2. Accounts: dukung format array ["user|pass", ...] maupun string newline
    let configAccounts = [];
    if (Array.isArray(config.accounts)) {
      configAccounts = config.accounts.map(a => String(a).trim()).filter(a => a.includes("|"));
    } else if (typeof config.accounts === "string") {
      configAccounts = config.accounts.split("\n").map(a => a.trim()).filter(a => a.includes("|"));
    }

    if (configAccounts.length > 0) {
      const configAccountsStr = configAccounts.join("\n");
      if (!storage.accounts || storage.accounts.trim() !== configAccountsStr) {
        console.log(`[Config] 📋 Memuat ${configAccounts.length} akun dari config.json`);
        updates.accounts = configAccountsStr;
        updates.originalAccounts = configAccountsStr;
      }

      // 3. PENTING: KUNCI AKUN TERAKHIR (PERSISTENT ACTIVE ACCOUNT)
      // JIKA activeAccount SUDAH ADA dan masih valid di daftar akun:
      // PERTAHANKAN! JANGAN TIMPA!
      const currentActive = storage.activeAccount;
      const cleanUser = (str) => (str ? str.split("|")[0].trim().toLowerCase() : "");
      const isCurrentActiveValid =
        currentActive &&
        configAccounts.some(acc => cleanUser(acc) === cleanUser(currentActive));

      if (!isCurrentActiveValid || !currentActive) {
        console.log(`[Config] Inisialisasi awal activeAccount: ${configAccounts[0].split('|')[0]}`);
        updates.activeAccount = configAccounts[0];
        updates.activeAccountTimestamp = Date.now();
        updates[ACCOUNT_SEQUENCE_KEY] = {
          originalSequence: [...configAccounts],
          currentIndex: 0,
          lastActiveAccount: configAccounts[0]
        };
      } else {
        console.log(`[Config] 🔒 Mempertahankan activeAccount terakhir: ${currentActive.split('|')[0]}`);
        // Pastikan originalSequence terisi
        let seq = storage[ACCOUNT_SEQUENCE_KEY];
        const activeIdx = configAccounts.findIndex(acc => cleanUser(acc) === cleanUser(currentActive));
        if (!seq || !Array.isArray(seq.originalSequence) || seq.originalSequence.length === 0) {
          updates[ACCOUNT_SEQUENCE_KEY] = {
            originalSequence: [...configAccounts],
            currentIndex: activeIdx >= 0 ? activeIdx : 0,
            lastActiveAccount: currentActive
          };
        }
      }
    }

    if (Object.keys(updates).length > 0) {
      await new Promise(r => chrome.storage.local.set(updates, r));
      console.log("[Config] ✅ Konfigurasi otomatis berhasil disimpan ke storage");
      chrome.runtime.sendMessage({ action: "refresh_display" }).catch(() => {});
    }
  } catch (err) {
    console.warn("[Config] Info config.json:", err.message);
  }
}

/**
 * Mencatat paste sukses untuk akun aktif, menghitung durasi 1 putaran jika paste #2,
 * dan mengirim laporan PASTE_SUCCESS ke database Supabase admin dashboard.
 */
async function recordAccountPaste(account) {
  if (!account || !account.includes("|")) return;
  const todayKey = `dailyPaste_${getTodayDateKey()}`;
  const username = account.split("|")[0];

  return new Promise((resolve) => {
    chrome.storage.local.get([todayKey, "workerId"], (data) => {
      const history = data[todayKey] || {};
      const accRecord = history[username] || { count: 0, timestamps: [] };

      const now = Date.now();
      accRecord.count = (accRecord.count || 0) + 1;
      accRecord.timestamps = accRecord.timestamps || [];
      accRecord.timestamps.push(now);
      history[username] = accRecord;

      // Hitung total seluruh akun hari ini
      let totalLoginsToday = 0;
      Object.values(history).forEach(item => {
        if (item && typeof item.count === 'number') {
          totalLoginsToday += item.count;
        }
      });

      chrome.storage.local.set({
        [todayKey]: history,
        loginCount: totalLoginsToday,
        loginCountDate: getTodayDateKey()
      }, () => {
        let msg = "";
        if (accRecord.count === 1) {
          msg = "Paste #1 (Putaran 1)";
        } else if (accRecord.count === 2) {
          const durationMs = accRecord.timestamps[1] - accRecord.timestamps[0];
          const durationMin = Math.round(durationMs / 60000);
          const hours = Math.floor(durationMin / 60);
          const mins = durationMin % 60;
          msg = `Paste #2 (Putaran selesai - Durasi: ${hours}j ${mins}m)`;
        } else {
          msg = `Paste #${accRecord.count}`;
        }

        console.log(`[background] 📊 PASTE_SUCCESS untuk ${username}: ${msg} (Total 24 Jam: ${totalLoginsToday}x)`);
        sendReportToAdmin(account, "PASTE_SUCCESS", msg);
        // Kirim juga update HEARTBEAT dengan total login 24 jam yang akurat
        sendReportToAdmin(account, "HEARTBEAT", `Sukses paste ${username} (login 24 jam: ${totalLoginsToday}x)`);
        chrome.runtime.sendMessage({ action: "refresh_display" }).catch(() => {});
        resolve(accRecord);
      });
    });
  });
}

/**
 * Get persistent account sequence state from storage
 */
function getAccountSequenceState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([ACCOUNT_SEQUENCE_KEY, "accounts", "originalAccounts"], (items) => {
      const originalAccounts = items.originalAccounts || items.accounts;
      const sequenceState = items[ACCOUNT_SEQUENCE_KEY] || {
        originalSequence: originalAccounts ? originalAccounts.split("\n").filter(line => line.trim() !== "") : [],
        currentIndex: -1,
        lastActiveAccount: null
      };
      
      console.log(`[background] 🔄 Loaded sequence state:`, {
        originalSequence: sequenceState.originalSequence.map(acc => acc.split('|')[0] + '|[HIDDEN]'),
        currentIndex: sequenceState.currentIndex,
        lastActiveAccount: sequenceState.lastActiveAccount ? sequenceState.lastActiveAccount.split('|')[0] + '|[HIDDEN]' : 'none'
      });
      
      resolve(sequenceState);
    });
  });
}

/**
 * Save persistent account sequence state to storage
 */
function saveAccountSequenceState(sequenceState) {
  console.log(`[background] 💾 Saving sequence state:`, {
    originalSequence: sequenceState.originalSequence.map(acc => acc.split('|')[0] + '|[HIDDEN]'),
    currentIndex: sequenceState.currentIndex,
    lastActiveAccount: sequenceState.lastActiveAccount ? sequenceState.lastActiveAccount.split('|')[0] + '|[HIDDEN]' : 'none'
  });
  
  chrome.storage.local.set({ [ACCOUNT_SEQUENCE_KEY]: sequenceState });
}

/**
 * Get next account in sequence, maintaining persistent state
 */
async function getNextAccountInSequence(availableAccounts) {
  const sequenceState = await getAccountSequenceState();
  const { originalSequence, currentIndex, lastActiveAccount } = sequenceState;
  
  console.log(`[background] 🎯 Getting next account in sequence...`);
  console.log(`[background] Available accounts:`, availableAccounts.map(acc => acc.split('|')[0] + '|[HIDDEN]'));
  console.log(`[background] Original sequence:`, originalSequence.map(acc => acc.split('|')[0] + '|[HIDDEN]'));
  console.log(`[background] Current index: ${currentIndex}`);
  
  if (availableAccounts.length === 0) {
    console.error(`[background] ❌ No available accounts`);
    return null;
  }
  
  // If original sequence is empty or different, rebuild it
  if (originalSequence.length === 0) {
    console.log(`[background] 🔄 Rebuilding sequence state from available accounts`);
    const cleanUser = (str) => (str ? str.split("|")[0].trim().toLowerCase() : "");
    const activeAcc = sequenceState.lastActiveAccount;
    let initialIndex = 0;
    if (activeAcc) {
      const idx = availableAccounts.findIndex(acc => cleanUser(acc) === cleanUser(activeAcc));
      if (idx >= 0) initialIndex = idx;
    }
    const newSequenceState = {
      originalSequence: [...availableAccounts],
      currentIndex: initialIndex,
      lastActiveAccount: availableAccounts[initialIndex]
    };
    saveAccountSequenceState(newSequenceState);
    return availableAccounts[initialIndex];
  }
  
  // Baca riwayat paste hari ini untuk membatasi akun maksimal 2 kali per siklus 24 jam
  const dailyHistory = await getDailyPasteHistory();

  // Cari akun berikutnya dalam urutan yang masih tersedia dan paste < 2x hari ini
  let nextIndex = (currentIndex + 1) % originalSequence.length;
  let attempts = 0;
  let eligibleCandidate = null;
  let eligibleIndex = -1;

  while (attempts < originalSequence.length) {
    const candidateAccount = originalSequence[nextIndex];

    if (availableAccounts.includes(candidateAccount)) {
      const candidateUser = candidateAccount.split("|")[0];
      const countToday = dailyHistory[candidateUser]?.count || 0;

      if (countToday < 2) {
        eligibleCandidate = candidateAccount;
        eligibleIndex = nextIndex;
        break;
      } else {
        console.log(`[background] ⏸️ Akun ${candidateUser} sudah mencapai batas 2x paste hari ini (dilewati).`);
      }
    } else {
      console.log(`[background] ⏭️ Skipping unavailable account: ${candidateAccount.split('|')[0]} (index ${nextIndex})`);
    }

    nextIndex = (nextIndex + 1) % originalSequence.length;
    attempts++;
  }

  if (eligibleCandidate) {
    console.log(`[background] ✅ Found next eligible account in sequence: ${eligibleCandidate.split('|')[0]} (index ${currentIndex} → ${eligibleIndex})`);

    const updatedState = {
      ...sequenceState,
      currentIndex: eligibleIndex,
      lastActiveAccount: eligibleCandidate
    };
    saveAccountSequenceState(updatedState);

    return eligibleCandidate;
  }

  // Cek fallback dari availableAccounts yang masih < 2x
  for (const acc of availableAccounts) {
    const u = acc.split("|")[0];
    if ((dailyHistory[u]?.count || 0) < 2) {
      console.log(`[background] 🔄 Fallback ke akun yang belum 2x: ${u}`);
      const fallbackState = {
        originalSequence: [...availableAccounts],
        currentIndex: 0,
        lastActiveAccount: acc
      };
      saveAccountSequenceState(fallbackState);
      return acc;
    }
  }

  // Jika SEMUA akun sudah 2x paste hari ini:
  console.log(`[background] 🏁 Seluruh akun (${availableAccounts.length}) telah mencapai batas maksimal 2x paste hari ini! Menunggu siklus berikutnya.`);
  sendReportToAdmin("-", "HEARTBEAT", "Semua akun telah mencapai batas 2x paste hari ini (Siklus 24 jam selesai)");
  return null;
}

// Make debug function available globally
if (typeof window !== 'undefined') {
  window.debugSequenceState = debugSequenceState;
}

/**
 * Debug function to check sequence state (available in console)
 */
function debugSequenceState() {
  console.log(`[background] === DEBUGGING SEQUENCE STATE ===`);
  chrome.storage.local.get([ACCOUNT_SEQUENCE_KEY, "accounts", "activeAccount", "problematicAccounts"], (items) => {
    console.log(`💾 Storage Contents:`, {
      accounts: items.accounts ? items.accounts.split('\n').map(acc => acc.split('|')[0] + '|[HIDDEN]') : [],
      activeAccount: items.activeAccount ? items.activeAccount.split('|')[0] + '|[HIDDEN]' : 'none',
      problematicAccounts: items.problematicAccounts ? items.problematicAccounts.split('\n').map(acc => acc.split('|')[0] + '|[HIDDEN]') : [],
      sequenceState: items[ACCOUNT_SEQUENCE_KEY] || 'not initialized'
    });
    
    if (items[ACCOUNT_SEQUENCE_KEY]) {
      const state = items[ACCOUNT_SEQUENCE_KEY];
      console.log(`🎯 Sequence State Details:`, {
        originalSequence: state.originalSequence.map(acc => acc.split('|')[0] + '|[HIDDEN]'),
        currentIndex: state.currentIndex,
        lastActiveAccount: state.lastActiveAccount ? state.lastActiveAccount.split('|')[0] + '|[HIDDEN]' : 'none'
      });
    }
  });
}

/**
 * Debug function for inactivity timer state
 */
function debugInactivityTimer() {
  console.log(`[background] === DEBUGGING INACTIVITY TIMER ===`);
  console.log(`🕰️ Timer State:`, {
    isInactivityTimerRunning: isInactivityTimerRunning,
    inactivityTimeRemaining: inactivityTimeRemaining,
    lastKnownPage: lastKnownPage,
    extensionNavigationInProgress: extensionNavigationInProgress
  });
  console.log(`📦 Loading States:`, Array.from(tabLoadingStates.entries()));
  
  // Check current active tab
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs.length > 0) {
      const tab = tabs[0];
      console.log(`🔄 Current Active Tab:`, {
        id: tab.id,
        url: tab.url,
        status: tab.status,
        isKnownPage: isKnownPage(tab.url, tab.id)
      });
    }
  });
}

// ================================
// 2. Fungsi Timer Pergantian Akun
// ================================

/**
 * Check if URL is a known/safe page that should not trigger inactivity timer
 * CORRECTED logic: SEMUA SageMaker pages (termasuk user profile) = SAFE (timer utama)
 * HANYA halaman NON-SageMaker yang trigger timer 7 menit
 */
function isKnownPage(url, tabId = null) {
  // Handle empty or system URLs
  if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('data:')) {
    console.log(`[background] 🔍 Safe URL (system): ${url}`);
    return true;
  }
  
  console.log(`[background] 🔍 Checking URL for inactivity timer: ${url}`);
  
  // If extension-triggered navigation is in progress, treat as safe
  if (extensionNavigationInProgress) {
    console.log(`[background] ✅ Extension navigation in progress, treating as safe`);
    return true;
  }
  
  // Check if tab is currently loading (safer to wait)
  if (tabId && tabLoadingStates.has(tabId)) {
    const loadingState = tabLoadingStates.get(tabId);
    if (loadingState.isLoading) {
      console.log(`[background] ⏳ Tab ${tabId} still loading, treating as safe`);
      return true;
    }
  }
  
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    // 1. SEMUA Halaman SageMaker Studio Lab (Login, Users Dashboard, Jupyter, dll) = SAFE
    // Terdiri dari studiolab.sagemaker.aws (login, users/*) dan *.studio.us-east-2.sagemaker.aws
    if (hostname.endsWith("sagemaker.aws") || hostname === "studiolab.sagemaker.aws") {
      console.log(`[background] ✅ Halaman SageMaker Domain (SAFE - Login/Dashboard/Jupyter): ${url}`);
      return true;
    }

    // 2. Halaman Login / Auth AWS & Amazon (Cognito, Sign-in AWS, AWS Console) = SAFE
    if (hostname.endsWith("amazoncognito.com") || 
        hostname.endsWith("aws.amazon.com") || 
        hostname.endsWith("amazon.com")) {
      console.log(`[background] ✅ Halaman AWS/Amazon Auth (SAFE): ${url}`);
      return true;
    }
    
    // 3. Chrome/Extension system pages
    for (const knownUrl of KNOWN_PAGES) {
      if (url.startsWith(knownUrl)) {
        console.log(`[background] ✅ System page - badge hijau: ${knownUrl}`);
        return true;
      }
    }
    
  } catch (err) {
    console.warn(`[background] ⚠️ Could not parse URL: ${url}`);
    return false;
  }
  
  // SELAIN HALAMAN SAGEMAKER / AWS / SYSTEM = MEMICU TIMER 3 MENIT INACTIVITY
  console.log(`[background] ⏳ Halaman di luar SageMaker/AWS (Timer 3 menit aktif): ${url}`);
  return false;
}

/**
 * Inactivity timer disabled - Account switching ONLY happens on:
 * 1. Successful Jupyter paste
 * 2. Main timer expiration (50 mins)
 * 3. Login errors (max retries reached)
 */
function startInactivityTimer(url, tabId = null) {
  // Disabled to prevent unwanted account switching when other extensions or tabs are active
  return;
}

/**
 * Stop inactivity timer
 */
function stopInactivityTimer() {
  if (inactivityTimer) {
    clearInterval(inactivityTimer);
    inactivityTimer = null;
  }
  isInactivityTimerRunning = false;
  chrome.storage.local.remove([INACTIVITY_TIMER_STORAGE_KEY]);
  console.log(`[background] ⏹️ Inactivity timer stopped and storage cleared`);
}

/**
 * Check for stuck/failed loading tabs and handle appropriately
 */
function checkStuckLoadingTabs() {
  const now = Date.now();
  const LOADING_TIMEOUT = 30000; // 30 seconds timeout for loading
  
  for (const [tabId, state] of tabLoadingStates.entries()) {
    if (state.isLoading && (now - state.startTime) > LOADING_TIMEOUT) {
      console.warn(`[background] ⚠️ Tab ${tabId} stuck loading for ${Math.round((now - state.startTime)/1000)}s`);
      
      // Check if tab still exists and is indeed stuck
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          // Tab no longer exists
          tabLoadingStates.delete(tabId);
          return;
        }
        
        if (tab && tab.status === 'loading') {
          console.log(`[background] 🔄 Tab ${tabId} confirmed stuck, treating as safe (connection issue)`);
          // Update state to prevent inactivity timer
          tabLoadingStates.set(tabId, {
            isLoading: true, // Keep as loading to prevent timer
            startTime: now, // Reset timeout
            url: state.url,
            stuckLoading: true
          });
        } else {
          // Tab finished loading, update state
          tabLoadingStates.set(tabId, {
            isLoading: false,
            startTime: now,
            url: tab.url || state.url
          });
        }
      });
    }
  }
}

// Run stuck loading check every 30 seconds
setInterval(checkStuckLoadingTabs, 30000);

/**
 * Update badge to show inactivity countdown
 */
function updateInactivityBadge() {
  if (!isInactivityTimerRunning) return;
  
  const minutes = Math.floor(inactivityTimeRemaining / 60000);
  const seconds = Math.floor((inactivityTimeRemaining % 60000) / 1000);
  const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  
  // Show inactivity countdown with different color
  chrome.action.setBadgeText({ text: `⚠${timeString}` });
  chrome.action.setBadgeBackgroundColor({ color: '#FF5722' }); // Orange-red for warning
}

/**
 * Handle inactivity timeout - close tabs and return to login WITHOUT changing account
 */
async function handleInactivityTimeout() {
  try {
    console.log(`[background] 🧹 Handling inactivity timeout - clearing tabs without account change`);
    
    // Stop inactivity timer
    stopInactivityTimer();
    
    // Get current active account (DON'T change it)
    const items = await new Promise((resolve) => {
      chrome.storage.local.get(['activeAccount'], resolve);
    });
    
    // Create new login tab FIRST (to prevent browser close)
    const newTab = await chrome.tabs.create({
      url: "https://studiolab.sagemaker.aws/login",
      active: true
    });
    
    console.log(`[background] 🆕 Created fresh login tab: ${newTab.id}`);
    
    // THEN close all OTHER tabs (not the new one)
    const allTabs = await chrome.tabs.query({});
    console.log(`[background] 🗑️ Closing ${allTabs.length - 1} other tabs...`);
    
    for (const tab of allTabs) {
      if (tab.id !== newTab.id) { // Keep the new login tab
        try {
          await chrome.tabs.remove(tab.id);
        } catch (err) {
          console.warn(`[background] Failed to close tab ${tab.id}:`, err.message);
        }
      }
    }
    
    // Clear browsing data AFTER tab management
    await clearAllBrowsingData();
    console.log(`[background] ✅ Browsing data cleared`);
    
    // Wait for tab to be ready
    await waitForTabReady(newTab.id);
    
    // Inject content script and trigger login with SAME account
    const injectionSuccess = await ensureContentScriptInjected(newTab.id);
    if (injectionSuccess && items.activeAccount) {
      console.log(`[background] 🔄 Auto-login with same account: ${items.activeAccount.split('|')[0]}`);
      
      try {
        await sendMessageToContentScript(newTab.id, {
          action: 'performLogin',
          account: items.activeAccount
        });
        console.log(`[background] ✅ Login command sent successfully`);
      } catch (err) {
        console.warn(`[background] Failed to send login command:`, err.message);
      }
    }
    
    console.log(`[background] ✅ Inactivity timeout handled successfully - browser stays open`);
    
  } catch (err) {
    console.error(`[background] ❌ Error handling inactivity timeout:`, err);
    // Fallback: create basic login tab
    chrome.tabs.create({ url: "https://studiolab.sagemaker.aws/login" });
  }
}

/**
 * Memulai timer untuk pergantian akun otomatis
 */
function startAccountSwitchTimer() {
  if (accountSwitchTimer) {
    clearInterval(accountSwitchTimer);
  }
  
  timeRemaining = ACCOUNT_SWITCH_INTERVAL;
  isTimerRunning = true;
  
  // Update badge segera saat timer dimulai
  updateTimerBadge();
  
  accountSwitchTimer = setInterval(() => {
    timeRemaining -= 1000;
    updateTimerBadge();
    
    if (timeRemaining <= 0) {
      console.log(`[background] Timer reached 0, starting account switch sequence...`);
      
      // Use the enhanced switchAccountAutomatically function
      switchAccountAutomatically()
        .then(() => {
          console.log(`[background] Timer-triggered account switch completed successfully`);
        })
        .catch((err) => {
          console.error(`[background] Timer-triggered account switch failed:`, err);
          // Fallback: try manual approach
          setTimeout(() => {
            handleClearTabsAndCache().then(() => {
              resetAccountSwitchTimer();
            }).catch(() => {
              resetAccountSwitchTimer();
            });
          }, 3000);
        });
    }
  }, 1000);
}

/**
 * Update badge timer di semua tab
 */
function updateTimerBadge() {
  // Show account switch timer normally
  const minutes = Math.floor(timeRemaining / 60000);
  const seconds = Math.floor((timeRemaining % 60000) / 1000);
  const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  
  // Update badge di semua tab
  chrome.action.setBadgeText({ text: timeString });
  chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
}

/**
 * Mereset timer pergantian akun
 */
function resetAccountSwitchTimer() {
  if (accountSwitchTimer) {
    clearInterval(accountSwitchTimer);
  }
  timeRemaining = ACCOUNT_SWITCH_INTERVAL;
  startAccountSwitchTimer();
}

/**
 * Menghentikan timer pergantian akun
 */
function stopAccountSwitchTimer() {
  if (accountSwitchTimer) {
    clearInterval(accountSwitchTimer);
    accountSwitchTimer = null;
  }
  isTimerRunning = false;
  
  // Only clear badge if no inactivity timer is running
  if (!isInactivityTimerRunning) {
    chrome.action.setBadgeText({ text: '' });
  }
}

// ================================
// 2. Fungsi Switch Account Otomatis
// ================================



/**
 * Mengganti akun secara otomatis:
 * - Ambil daftar akun, loginCount, activeAccount dari storage
 * - Hitung indeks berikutnya, update storage
 * - Kirim perintah performLogin ke semua tab login SageMaker yang terbuka
 */
/**
 * Enhanced account switching with persistent sequence state
 */
function switchAccountAutomatically() {
  return new Promise(async (resolve, reject) => {
    try {
      const nowTime = Date.now();
      if (isAccountSwitchingLock || (nowTime - lastAccountSwitchTime < ACCOUNT_SWITCH_COOLDOWN_MS)) {
        console.warn(`[background] 🛑 Account switch locked/throttled (${Math.round((nowTime - lastAccountSwitchTime)/1000)}s since last switch). Skipped to prevent loop.`);
        resolve(false);
        return;
      }

      isAccountSwitchingLock = true;
      lastAccountSwitchTime = nowTime;

      // Reset lock setelah cooldown 15 detik agar tidak terkunci selamanya jika ada error
      setTimeout(() => {
        isAccountSwitchingLock = false;
      }, ACCOUNT_SWITCH_COOLDOWN_MS);

      const items = await new Promise((resolve) => {
        chrome.storage.local.get(["accounts", "loginCount", "loginCountDate", "activeAccount"], resolve);
      });
      
      const accountLines = items.accounts
        ? items.accounts.split("\n").filter((line) => line.trim() !== "")
        : [];
        
      if (accountLines.length === 0) {
        console.log(`[background] No accounts available for switching`);
        reject(new Error("No accounts available"));
        return;
      }

      // Use centralized sequence management
      const nextAccount = await getNextAccountInSequence(accountLines);
      
      if (!nextAccount) {
        console.log(`[background] ⏸️ Tidak ada akun berikutnya yang memenuhi syarat (semua akun sudah mencapai kuota 2x paste hari ini).`);
        resolve(false);
        return;
      }

      // Validate next account format
      if (!nextAccount.includes("|")) {
        console.error(`[background] Invalid next account format: ${nextAccount}`);
        reject(new Error("Invalid account format"));
        return;
      }

      const [username, password] = nextAccount.split("|");
      if (!username || !password || password === 'undefined' || password.trim() === '') {
        console.error(`[background] Invalid account credentials: ${username}`);
        reject(new Error("Invalid account credentials"));
        return;
      }

      // Hitung login dalam kurun waktu 24 jam (reset jam 12 malam)
      const todayKey = getTodayDateKey();
      const current24hLogins = await getDailyTotalLogins();
      const now = Date.now();
      
      console.log(`[background] 🔄 Auto-switching to: ${nextAccount.split('|')[0]} (sudah ${current24hLogins}x login/paste sukses hari ini)`);
      
      // Update storage
      chrome.storage.local.set(
        {
          activeAccount: nextAccount,
          activeAccountTimestamp: now,
          loginCount: current24hLogins,
          loginCountDate: todayKey,
        },
        async () => {
          console.log(`[background] Account updated in storage: ${nextAccount.split('|')[0]}`);
          
          try {
            // Kirim Laporan HEARTBEAT (Online Status)
            sendReportToAdmin(nextAccount, "HEARTBEAT", `Switching ke akun ${nextAccount.split('|')[0]} (login 24 jam: ${current24hLogins}x)`);

            console.log(`[background] Auto-switch ke akun #${newLoginCount}: ${nextAccount.split('|')[0]}`);
            
            // Sequential approach: first try existing tabs, then handle creation/clearing
            const success = await handleExistingLoginTabs(nextAccount);
            
            if (success) {
              console.log(`[background] Successfully used existing tab for: ${nextAccount.split('|')[0]}`);
              resolve(true);
            } else {
              console.log(`[background] No responsive tabs, creating fresh environment for: ${nextAccount.split('|')[0]}`);
              await handleFreshTabCreation(nextAccount);
              resolve(true);
            }
            
            // Reset timer after successful account switch
            resetAccountSwitchTimer();
            
          } catch (err) {
            console.error(`[background] Error in account switch process:`, err);
            reject(err);
          }
        }
      );
    } catch (err) {
      console.error(`[background] Error in switchAccountAutomatically:`, err);
      reject(err);
    }
  });
}

/**
 * Handle existing login tabs with improved reliability and navigation safety
 */
async function handleExistingLoginTabs(nextAccount) {
  return new Promise((resolve) => {
    chrome.tabs.query({ url: "https://studiolab.sagemaker.aws/login*" }, async (tabs) => {
      if (!tabs || tabs.length === 0) {
        console.log(`[background] No existing login tabs found`);
        resolve(false);
        return;
      }
      
      console.log(`[background] Found ${tabs.length} existing login tabs, checking responsiveness...`);
      
      // Set extension navigation flag
      extensionNavigationInProgress = true;
      
      // Try tabs sequentially, not in parallel
      for (const tab of tabs) {
        try {
          const ready = await isTabReady(tab.id);
          if (!ready) {
            console.log(`[background] Tab ${tab.id} not ready, skipping`);
            continue;
          }
          
          console.log(`[background] Attempting to send performLogin to tab ${tab.id}`);
          await sendMessageToContentScript(tab.id, {
            action: "performLogin", 
            account: nextAccount
          });
          
          console.log(`[background] Successfully sent performLogin to tab ${tab.id} for account: ${nextAccount.split('|')[0]}`);
          
          // Verify account switch success after a delay
          setTimeout(() => {
            verifyAccountSwitch(nextAccount);
            // Clear navigation flag after some time
            setTimeout(() => {
              extensionNavigationInProgress = false;
            }, 10000);
          }, 5000);
          
          resolve(true);
          return;
          
        } catch (err) {
          console.warn(`[background] Tab ${tab.id} failed:`, err.message);
          continue;
        }
      }
      
      console.log(`[background] No responsive tabs found among ${tabs.length} existing tabs`);
      extensionNavigationInProgress = false;
      resolve(false);
    });
  });
}

/**
 * Handle fresh tab creation with clean environment and navigation safety
 */
async function handleFreshTabCreation(nextAccount) {
  try {
    console.log(`[background] Creating fresh environment for: ${nextAccount.split('|')[0]}`);
    
    // Set extension navigation flag
    extensionNavigationInProgress = true;
    
    // Clear all tabs and cache first
    const clearResult = await handleClearTabsAndCache();
    if (!clearResult.success) {
      throw new Error(`Failed to clear tabs: ${clearResult.message}`);
    }
    
    console.log(`[background] Fresh environment created successfully for: ${nextAccount.split('|')[0]}`);
    
    // Verify account switch success after environment is ready
    setTimeout(() => {
      verifyAccountSwitch(nextAccount);
      // Clear navigation flag after sufficient time
      setTimeout(() => {
        extensionNavigationInProgress = false;
      }, 15000);
    }, 8000);
    
    return true;
  } catch (err) {
    console.error(`[background] Failed to create fresh environment:`, err);
    extensionNavigationInProgress = false;
    // Fallback: just create new tab
    chrome.tabs.create({ url: "https://studiolab.sagemaker.aws/login" });
    throw err;
  }
}

/**
 * Verify that account switch was successful
 */
function verifyAccountSwitch(expectedAccount) {
  chrome.storage.local.get(['activeAccount'], (items) => {
    if (items.activeAccount === expectedAccount) {
      console.log(`[background] ✅ Account switch verified: ${expectedAccount.split('|')[0]}`);
    } else {
      console.warn(`[background] ⚠️ Account switch verification failed. Expected: ${expectedAccount.split('|')[0]}, Got: ${items.activeAccount ? items.activeAccount.split('|')[0] : 'none'}`);
      // Could implement retry logic here if needed
    }
  });
}

/**
 * Check if tab is ready for communication
 */
function isTabReady(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) {
        resolve(false);
        return;
      }
      
      const ready = tab && 
                   tab.status === 'complete' && 
                   tab.url && 
                   tab.url.includes('/login') &&
                   !tab.url.includes('chrome-extension://');
      
      resolve(ready);
    });
  });
}

/**
 * Ensure content script is properly injected and ready
 */
async function ensureContentScriptInjected(tabId) {
  try {
    console.log(`[background] Ensuring content script injected in tab ${tabId}`);
    
    // Check if tab is ready first
    const ready = await isTabReady(tabId);
    if (!ready) {
      console.warn(`[background] Tab ${tabId} not ready for injection`);
      return false;
    }
    
    // 1. Test ping first to check if content script is ALREADY injected & responsive
    const isAlreadyAlive = await new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { action: "ping" }, (response) => {
        if (!chrome.runtime.lastError && response && response.status === "ready") {
          resolve(true);
        } else {
          resolve(false);
        }
      });
    });

    if (isAlreadyAlive) {
      console.log(`[background] ✅ Content script is already injected and responding to ping in tab ${tabId}`);
      return true;
    }
    
    // 2. Only executeScript if ping failed (script not yet loaded)
    console.log(`[background] Content script not responding to ping, injecting via executeScript...`);
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    });
    
    console.log(`[background] Content script injected, waiting for initialization...`);
    
    // Wait for script to initialize
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Test ping to ensure script is ready
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, {action: "ping"}, (response) => {
        const success = !chrome.runtime.lastError;
        console.log(`[background] Content script post-injection ping test: ${success ? 'SUCCESS' : 'FAILED'}`);
        resolve(success);
      });
    });
  } catch (err) {
    console.error(`[background] Content script injection failed:`, err);
    return false;
  }
}

/**
 * Kirim pesan ke content script dengan retry mechanism yang lebih robust
 */
function sendMessageToContentScript(tabId, message, retries = 3) {
  return new Promise(async (resolve, reject) => {
    console.log(`[background] Sending message to tab ${tabId}, retries left: ${retries}`);
    
    // First ensure tab is ready and content script is injected
    const scriptReady = await ensureContentScriptInjected(tabId);
    if (!scriptReady && retries <= 1) {
      reject(new Error(`Content script not ready in tab ${tabId}`));
      return;
    }
    
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        console.warn(`[background] Message failed (${retries} retries left):`, chrome.runtime.lastError.message);
        
        if (retries > 0) {
          // Retry with delay
          setTimeout(() => {
            sendMessageToContentScript(tabId, message, retries - 1)
              .then(resolve)
              .catch(reject);
          }, 2000);
        } else {
          reject(new Error("Max retries reached"));
        }
      } else {
        console.log(`[background] Message sent successfully to tab ${tabId}`);
        resolve(response);
      }
    });
  });
}

// ================================
// 4. Fungsi Account Management (Problematic Accounts)
// ================================

/**
 * Pindahkan akun yang butuh phone verification langsung ke akun bermasalah (merah)
 */
function moveAccountToPhoneVerification(account, errorType, errorMessage) {
  console.log(`[background] Alihkan phone verification langsung ke moveAccountToProblematic: ${account?.split('|')[0]}`);
  moveAccountToProblematic(account, "phone_verification_required", errorMessage || "Mobile phone number required");
}

// ================================
// KONFIGURASI SUPABASE
// ================================
// ⚠️ GANTI DENGAN NILAI DARI PROJECT SUPABASE ANDA:
// Supabase Dashboard → Settings → API
const SUPABASE_URL = "https://tjmljgyubusaguytslpn.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRqbWxqZ3l1YnVzYWd1eXRzbHBuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc0NzI3MTEsImV4cCI6MjA5MzA0ODcxMX0.vfz1FooQlUN_u-HmlfEzURaDtg7FZH83fmIiyZwVIv4";

// ================================
// FUNGSI KIRIM DATA KE SUPABASE
// ================================
function sendReportToAdmin(account, type, errorMsg) {
  chrome.storage.local.get(["workerId"], (res) => {
    const workerId = res.workerId || "UNKNOWN_PC";

    // HEARTBEAT boleh tanpa akun, yang lain harus ada format username|password
    if (type !== "HEARTBEAT" && (!account || !account.includes("|"))) return;

    fetch(`${SUPABASE_URL}/rest/v1/accounts_log`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        worker_id: workerId,
        account: account || "-",
        status: type,
        message: errorMsg || "-"
      })
    })
    .then(response => {
      if (response.ok) {
        console.log(`[Supabase] ✅ Laporan terkirim: ${type} dari ${workerId}`);
      } else {
        response.text().then(t => console.error(`[Supabase] ❌ Error response: ${t}`));
      }
    })
    .catch(error => console.error(`[Supabase] ❌ Fetch error:`, error));
  });
}

// ================================
// POLLING PERINTAH RESTORE DARI ADMIN (SUPER ROBUST & GUARANTEED SYNC)
// ================================
let isPollingRestore = false;

function pollRestoreCommands() {
  if (isPollingRestore) return;
  chrome.storage.local.get(["workerId"], (res) => {
    const workerId = (res.workerId || "").trim();
    if (!workerId || workerId === "UNKNOWN_PC") return;

    isPollingRestore = true;
    fetch(`${SUPABASE_URL}/rest/v1/restore_commands?worker_id=eq.${encodeURIComponent(workerId)}&executed=eq.false&select=*&order=created_at.asc`, {
      method: 'GET',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(commands => {
      isPollingRestore = false;
      if (!Array.isArray(commands) || commands.length === 0) return;
      console.log(`[Supabase] 📥 Diterima ${commands.length} perintah restore dari Admin untuk ${workerId}`);
      executeBatchRestore(commands);
    })
    .catch(error => {
      isPollingRestore = false;
      console.error(`[Supabase] ❌ Polling restore error:`, error);
    });
  });
}

// Proses SEMUA perintah restore sekaligus dengan pencocokan username fleksibel & dukungan RESTORE_ALL_PROBLEMATIC
function executeBatchRestore(commands) {
  if (!Array.isArray(commands) || commands.length === 0) return;

  const allIds = commands.map(c => c.id).filter(Boolean);

  chrome.storage.local.get(["accounts", "problematicAccounts", "phoneVerificationAccounts", ACCOUNT_SEQUENCE_KEY], (items) => {
    const cleanAccountLine = (str) => {
      if (!str) return "";
      return str.trim().replace(/\r/g, "");
    };

    const getUsername = (str) => {
      if (!str) return "";
      return cleanAccountLine(str).split("|")[0].trim().toLowerCase();
    };

    let mainAccounts = (items.accounts || "")
      .split("\n")
      .map(cleanAccountLine)
      .filter(l => l.includes("|"));

    let problematicList = (items.problematicAccounts || "")
      .split("\n")
      .map(cleanAccountLine)
      .filter(l => l.includes("|"));

    let phoneList = (items.phoneVerificationAccounts || "")
      .split("\n")
      .map(cleanAccountLine)
      .filter(l => l.includes("|"));

    // Deteksi perintah RESTORE_ALL_PROBLEMATIC atau wildcard account: "*"
    const hasRestoreAll = commands.some(cmd =>
      cmd.restore_type === "RESTORE_ALL_PROBLEMATIC" ||
      cmd.account === "*" ||
      cmd.account === "ALL"
    );

    let restoredCount = 0;
    let deletedCount = 0;

    if (hasRestoreAll) {
      console.log(`[Supabase] 🔄 Eksekusi RESTORE_ALL_PROBLEMATIC: Memulihkan SEMUA ${problematicList.length} akun bermasalah di ekstensi`);
      
      // Pindahkan SEMUA akun bermasalah kembali ke mainAccounts
      problematicList.forEach(acc => {
        const u = getUsername(acc);
        if (u) {
          const exists = mainAccounts.some(m => getUsername(m) === u);
          if (!exists) {
            mainAccounts.push(acc);
            restoredCount++;
          }
        }
      });

      // Bersihkan juga sisa list verifikasi HP jika ada
      phoneList.forEach(acc => {
        const u = getUsername(acc);
        if (u) {
          const exists = mainAccounts.some(m => getUsername(m) === u);
          if (!exists) {
            mainAccounts.push(acc);
            restoredCount++;
          }
        }
      });

      problematicList = [];
      phoneList = [];
    } else {
      // Eksekusi per akun berdasarkan pencocokan username (case-insensitive & trimmed)
      commands.forEach(cmd => {
        if (!cmd.account) return;
        const rawAccount = cmd.account.trim();
        const targetUser = getUsername(rawAccount);
        if (!targetUser) return;

        const isDeleteOnly = cmd.restore_type === "DELETE_PROBLEM" || cmd.restore_type === "DELETE_PHONE";

        // Temukan akun lengkap (username|password) dari storage lokal atau dari payload perintah
        const foundProb = problematicList.find(l => getUsername(l) === targetUser);
        const foundPhone = phoneList.find(l => getUsername(l) === targetUser);
        const fullAccount = foundProb || foundPhone || (rawAccount.includes("|") ? rawAccount : null);

        // Hapus akun dari daftar bermasalah secara kebal spasi dan casing
        problematicList = problematicList.filter(l => getUsername(l) !== targetUser);
        phoneList = phoneList.filter(l => getUsername(l) !== targetUser);

        if (isDeleteOnly) {
          deletedCount++;
        } else {
          // Pulihkan ke mainAccounts jika belum terdaftar
          if (fullAccount) {
            const exists = mainAccounts.some(m => getUsername(m) === targetUser);
            if (!exists) {
              mainAccounts.push(fullAccount);
              restoredCount++;
            }
          }
        }
      });
    }

    // Pastikan daftar akun utama bersih dan unik per username
    const uniqueMain = [];
    const seenUsers = new Set();
    mainAccounts.forEach(acc => {
      const u = getUsername(acc);
      if (u && !seenUsers.has(u)) {
        seenUsers.add(u);
        uniqueMain.push(acc);
      }
    });

    // Perbarui sequence state agar akun yang dipulihkan langsung siap dieksekusi giliran rotasi
    let seqState = items[ACCOUNT_SEQUENCE_KEY];
    if (seqState && Array.isArray(seqState.originalSequence)) {
      uniqueMain.forEach(acc => {
        const u = getUsername(acc);
        if (!seqState.originalSequence.some(o => getUsername(o) === u)) {
          seqState.originalSequence.push(acc);
        }
      });
    } else {
      seqState = {
        originalSequence: [...uniqueMain],
        currentIndex: -1,
        lastActiveAccount: null
      };
    }

    // Simpan hasil ke storage lokal
    chrome.storage.local.set({
      accounts: uniqueMain.join("\n"),
      problematicAccounts: problematicList.join("\n"),
      phoneVerificationAccounts: phoneList.join("\n"),
      [ACCOUNT_SEQUENCE_KEY]: seqState
    }, () => {
      console.log(`[Supabase] ✅ Sinkronisasi restore selesai: ${uniqueMain.length} akun aktif, ${problematicList.length} bermasalah.`);
      chrome.runtime.sendMessage({ action: "refresh_display" }).catch(() => {});
      markRestoreExecutedBatch(allIds);

      // Jika akun bermasalah lokal sudah 0, pastikan accounts_log di Supabase juga bersih
      if (problematicList.length === 0) {
        deleteFromSupabaseLog("PROBLEM");
        deleteFromSupabaseLog("PHONE_VERIFICATION");
      }

      sendReportToAdmin("-", "HEARTBEAT", `Restore berhasil: ${allIds.length} perintah dieksekusi. Sisa bermasalah di PC: ${problematicList.length}`);
    });
  });
}

// Tandai semua ID selesai dalam PATCH request (mendukung batch chunking)
function markRestoreExecutedBatch(ids) {
  if (!ids || ids.length === 0) return;
  const chunkSize = 50;
  for (let i = 0; i < ids.length; i += chunkSize) {
    const chunk = ids.slice(i, i + chunkSize);
    const idList = chunk.join(",");
    fetch(`${SUPABASE_URL}/rest/v1/restore_commands?id=in.(${idList})`, {
      method: 'PATCH',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({ executed: true, executed_at: new Date().toISOString() })
    })
    .then(response => {
      if (response.ok) console.log(`[Supabase] ✅ ${chunk.length} restore commands ditandai executed=true`);
      else response.text().then(t => console.error(`[Supabase] ❌ Mark batch error: ${t}`));
    })
    .catch(error => console.error(`[Supabase] ❌ Mark executed batch error:`, error));
  }
}

// Sinkronisasi otomatis: jika ada akun bermasalah di lokal yang belum tercatat di Supabase, daftarkan
function syncLocalProblematicToAdmin() {
  chrome.storage.local.get(["workerId", "problematicAccounts"], async (items) => {
    const workerId = (items.workerId || "").trim();
    if (!workerId || workerId === "UNKNOWN_PC") return;
    const probLines = (items.problematicAccounts || "")
      .split("\n")
      .map(l => l.trim())
      .filter(l => l.includes("|"));
    if (probLines.length === 0) return;

    try {
      const resp = await fetch(`${SUPABASE_URL}/rest/v1/accounts_log?worker_id=eq.${encodeURIComponent(workerId)}&status=eq.PROBLEM&select=account`, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      if (!resp.ok) return;
      const remoteLogs = await resp.json();
      const remoteUsers = new Set((remoteLogs || []).map(r => (r.account || "").split("|")[0].trim().toLowerCase()));

      probLines.forEach(acc => {
        const u = acc.split("|")[0].trim().toLowerCase();
        if (u && !remoteUsers.has(u)) {
          console.log(`[Supabase] 🔄 Sinkronisasi akun bermasalah lokal ke admin: ${u}`);
          sendReportToAdmin(acc, "PROBLEM", "Akun bermasalah lokal (auto-sync)");
        }
      });
    } catch(e) {
      // silent
    }
  });
}

// Inisialisasi polling & timer
setInterval(pollRestoreCommands, 20 * 1000); // Polling setiap 20 detik saat service worker aktif
setTimeout(pollRestoreCommands, 5 * 1000);
setTimeout(syncLocalProblematicToAdmin, 10 * 1000);

// ----------------------------------------------------

/**
 * Pindahkan akun bermasalah ke daftar terpisah dengan persistent sequence management
 */
function moveAccountToProblematic(account, errorType, errorMessage) {
  // Kirim laporan ke Server Admin
  sendReportToAdmin(account, "PROBLEM", errorMessage || errorType);
  
  console.log(`[background] moveAccountToProblematic called with:`, {
    account: account ? account.split('|')[0] + '|[HIDDEN]' : 'null',
    errorType: errorType,
    errorMessage: errorMessage?.substring(0, 100)
  });
  
  // Validate account format
  if (!account || !account.includes("|")) {
    console.error(`[background] Invalid account format: ${account}`);
    return;
  }
  
  const [username, password] = account.split("|");
  if (!username || !password || password === 'undefined') {
    console.error(`[background] Account has undefined/empty password: ${account}`);
    return;
  }
  
  chrome.storage.local.get(["accounts", "problematicAccounts"], async (items) => {
    const accountLines = items.accounts
      ? items.accounts.split("\n").filter((line) => line.trim() !== "")
      : [];
    
    console.log(`[background] Current account lines:`, accountLines.map(line => line.split('|')[0] + '|[HIDDEN]'));
    console.log(`[background] Looking to remove account: ${username}|[HIDDEN]`);
    console.log(`[background] Current activeAccount: ${items.activeAccount ? items.activeAccount.split('|')[0] + '|[HIDDEN]' : 'none'}`);
    
    // Remove account from main list
    const updatedAccounts = accountLines.filter(line => line !== account);
    
    console.log(`[background] Accounts after removal:`, updatedAccounts.map(line => line.split('|')[0] + '|[HIDDEN]'));
    
    // Add to problematic list - keep same format as main list (username|password only)
    const problematicList = items.problematicAccounts || "";
    const updatedProblematic = problematicList
      ? problematicList + "\n" + account  // Just the account, no error description
      : account;
    
    console.log(`[background] Updated problematic accounts:`, updatedProblematic.split('\n').map(line => line.split('|')[0] + '|[HIDDEN]'));
    
    // Check if there are remaining accounts
    if (updatedAccounts.length === 0) {
      console.log(`[background] No more accounts remaining after moving problematic account`);
      chrome.storage.local.set({
        accounts: "",
        problematicAccounts: updatedProblematic,
        activeAccount: ""
      });
      return;
    }
    
    // Use centralized sequence management to get next account
    const nextAccount = await getNextAccountInSequence(updatedAccounts);
    
    if (!nextAccount) {
      console.error(`[background] ❌ No valid next account found after removing problematic account`);
      return;
    }
    
    console.log(`[background] 🎯 Next account determined by persistent sequence: ${nextAccount.split('|')[0]}`);
    
    // Save updated lists and set new active account
    chrome.storage.local.set({
      accounts: updatedAccounts.join("\n"),
      problematicAccounts: updatedProblematic,
      activeAccount: nextAccount,  // Set next account as active
      activeAccountTimestamp: Date.now()
    }, () => {
      console.log(`[background] Account moved to problematic: ${username} (Error: ${errorType})`);
      console.log(`[background] Next active account set to: ${nextAccount.split('|')[0]}|[HIDDEN]`);
      
      // Clear tabs and cache, then the extension will use the new activeAccount
      console.log(`[background] Clearing tabs and cache before switching to next account...`);
      handleClearTabsAndCache().then(() => {
        console.log(`[background] Tabs cleared successfully, fresh tab created for next account: ${nextAccount.split('|')[0]}`);
        // Timer will be reset by the clearTabsAndCache handler
        resetAccountSwitchTimer();
      }).catch(err => {
        console.error(`[background] Error clearing tabs:`, err);
        // Fallback: just create new tab with the new active account
        chrome.tabs.create({ url: "https://studiolab.sagemaker.aws/login" });
        resetAccountSwitchTimer();
      });
      
      // Notify popup to refresh display
      chrome.runtime.sendMessage({ action: "refresh_display" });
      
      // Send status to server - WebSocket functionality removed
      // sendStatusUpdate("account_moved_to_problematic");
    });
  });
}

// ================================
// 5. Fungsi Clear Tabs & Hapus Cache
// ================================

/**
 * Enhanced tab and cache clearing with better error handling and navigation safety
 */
async function handleClearTabsAndCache() {
  try {
    console.log(`[background] Starting enhanced clearTabsAndCache process...`);
    
    // Set navigation flag
    extensionNavigationInProgress = true;
    
    // Clear all browsing data first
    await clearAllBrowsingData();
    console.log(`[background] ✅ Browsing data cleared successfully`);
    
    // Clear lingering timer timestamps from storage
    chrome.storage.local.remove(["jupyter_timer_start", "inactivity_timer_start", "login_retry_state"]);
    console.log(`[background] 🧹 Removed stale timer states from storage`);
    
    // Get all tabs before creating new one
    const allTabs = await chrome.tabs.query({});
    console.log(`[background] Found ${allTabs.length} existing tabs to close`);
    
    // Create new login tab
    const newTab = await chrome.tabs.create({
      url: "https://studiolab.sagemaker.aws/login",
      active: true
    });
    console.log(`[background] ✅ New login tab created with ID: ${newTab.id}`);
    
    // Track new tab loading state
    tabLoadingStates.set(newTab.id, {
      isLoading: true,
      startTime: Date.now(),
      url: "https://studiolab.sagemaker.aws/login"
    });
    
    // Close all other tabs (with error handling)
    for (const tab of allTabs) {
      if (tab.id !== newTab.id) {
        try {
          await chrome.tabs.remove(tab.id);
          // Remove from loading states
          tabLoadingStates.delete(tab.id);
        } catch (err) {
          console.warn(`[background] Failed to close tab ${tab.id}:`, err.message);
        }
      }
    }
    console.log(`[background] ✅ Other tabs closed, only login tab remains`);
    
    // Enhanced tab readiness check
    await waitForTabReady(newTab.id);
    
    // Update loading state
    tabLoadingStates.set(newTab.id, {
      isLoading: false,
      startTime: Date.now(),
      url: "https://studiolab.sagemaker.aws/login"
    });
    
    // Inject content script with retry mechanism
    const injectionSuccess = await ensureContentScriptInjected(newTab.id);
    if (injectionSuccess) {
      console.log(`[background] ✅ Content script ready in new tab`);
      
      // Get current active account and send login command
      const items = await new Promise((resolve) => {
        chrome.storage.local.get(['activeAccount'], resolve);
      });
      
      if (items.activeAccount) {
        console.log(`[background] Sending performLogin to new tab for: ${items.activeAccount.split('|')[0]}`);
        
        try {
          await sendMessageToContentScript(newTab.id, {
            action: 'performLogin',
            account: items.activeAccount
          });
          console.log(`[background] ✅ Login command sent successfully`);
        } catch (err) {
          console.warn(`[background] Failed to send login command:`, err.message);
        }
      } else {
        console.warn(`[background] No activeAccount found for auto-login`);
      }
    } else {
      console.warn(`[background] Content script injection failed, tab ready for manual use`);
    }
    
    // Clear navigation flag after some time
    setTimeout(() => {
      extensionNavigationInProgress = false;
    }, 10000);
    
    return { success: true };
    
  } catch (err) {
    console.error(`[background] ❌ Error in enhanced handleClearTabsAndCache:`, err);
    extensionNavigationInProgress = false;
    
    // Fallback: create a basic login tab
    try {
      const fallbackTab = await chrome.tabs.create({
        url: "https://studiolab.sagemaker.aws/login"
      });
      console.log(`[background] 🔄 Fallback tab created: ${fallbackTab.id}`);
    } catch (fallbackErr) {
      console.error(`[background] ❌ Fallback tab creation failed:`, fallbackErr);
    }
    
    return { success: false, message: err.message || String(err) };
  }
}

/**
 * Wait for tab to be fully ready
 */
function waitForTabReady(tabId, maxWait = 15000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    
    const checkTab = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          console.warn(`[background] Tab ${tabId} no longer exists`);
          resolve(false);
          return;
        }
        
        const elapsed = Date.now() - startTime;
        const ready = tab && tab.status === 'complete' && tab.url && tab.url.includes('/login');
        
        if (ready) {
          console.log(`[background] ✅ Tab ${tabId} ready after ${elapsed}ms`);
          resolve(true);
        } else if (elapsed > maxWait) {
          console.warn(`[background] ⏰ Tab ${tabId} timeout after ${elapsed}ms`);
          resolve(false);
        } else {
          setTimeout(checkTab, 500);
        }
      });
    };
    
    checkTab();
  });
}

/**
 * Menghapus semua data browsing (cache, cookies, history, dll.) sejak epoch.
 */
function clearAllBrowsingData() {
  return new Promise((resolve, reject) => {
    chrome.browsingData.remove(
      { since: 0 },
      {
        appcache: true,
        cache: true,
        cookies: true,
        downloads: true,
        fileSystems: true,
        formData: true,
        history: true,
        indexedDB: true,
        localStorage: true,
        pluginData: true,
        passwords: true,
        serviceWorkers: true,
        webSQL: true,
      },
      () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      }
    );
  });
}

// ================================
// 6. Listener chrome.runtime.onMessage
// ================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(`[background] Received message:`, message);
  
  if (message.action === "clearTabsAndCache") {
    handleClearTabsAndCache()
      .then((result) => {
        if (result.success) {
          resetAccountSwitchTimer();
          console.log(`[background] ✅ Clear tabs completed successfully`);
        } else {
          console.error(`[background] ❌ Clear tabs failed: ${result.message}`);
          resetAccountSwitchTimer(); // Reset timer even on failure
        }
      })
      .catch((err) => {
        console.error(`[background] ❌ Clear tabs error:`, err);
        resetAccountSwitchTimer();
      });
  } else if (message.action === "paste_success") {
    // Tab Jupyter Lab sukses melakukan paste ke terminal
    console.log(`[background] 📋 Notifikasi paste_success diterima dari tab Jupyter Lab`);
    chrome.storage.local.get(["activeAccount"], (res) => {
      if (res.activeAccount) {
        recordAccountPaste(res.activeAccount);
      }
    });
  } else if (message.action === "clearTabsAndSwitchAccount") {
    // New action: Clear tabs/cache AND switch to next account
    console.log(`[background] clearTabsAndSwitchAccount triggered - using enhanced sequential approach`);
    
    // Use the enhanced switchAccountAutomatically function
    switchAccountAutomatically()
      .then(() => {
        console.log(`[background] Enhanced account switch completed successfully`);
        // sendStatusUpdate("account_switched_after_jupyter_completion"); // WebSocket functionality removed
      })
      .catch((err) => {
        console.error(`[background] Enhanced account switch failed:`, err);
        // Fallback: still try to clear tabs and reset timer
        handleClearTabsAndCache()
          .then(() => resetAccountSwitchTimer())
          .catch(() => resetAccountSwitchTimer());
      });
  } else if (message.action === "switch_account_from_popup") {
    switchAccountAutomatically()
      .then(() => {
        console.log(`[background] Manual account switch from popup completed`);
        sendResponse({ success: true });
      })
      .catch((err) => {
        console.error(`[background] Manual account switch from popup failed:`, err);
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep message channel open for async response
  } else if (message.action === "switch_account_from_server") {
    switchAccountAutomatically()
      .then(() => {
        console.log(`[background] Server-triggered account switch completed`);
        sendResponse({ success: true });
      })
      .catch((err) => {
        console.error(`[background] Server-triggered account switch failed:`, err);
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep message channel open for async response
  } else if (message.action === "force_inactivity_timeout") {
    // Manual trigger for inactivity timeout (for testing or user request)
    console.log(`[background] Manual inactivity timeout triggered`);
    handleInactivityTimeout()
      .then(() => {
        console.log(`[background] Manual inactivity timeout completed`);
        sendResponse({ success: true });
      })
      .catch((err) => {
        console.error(`[background] Manual inactivity timeout failed:`, err);
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep message channel open for async response
  } else if (message.action === "move_account_to_problematic" || message.action === "move_account_to_phone_verification" || message.action === "phone_verification_detected") {
    // Alihkan langsung ke akun bermasalah karena kategori verifikasi HP sudah ditiadakan
    chrome.storage.local.get(["activeAccount"], (items) => {
      const targetAcc = message.account || items.activeAccount;
      if (targetAcc) {
        console.log(`[background] Phone verification dialihkan ke akun bermasalah: ${targetAcc.split('|')[0]}`);
        moveAccountToProblematic(targetAcc, "phone_verification_required", message.errorMessage || "Mobile phone number required");
      }
    });
  } else if (message.action === "sync_delete_from_supabase") {
    // Popup merestored/menghapus akun lokal — sinkronkan ke Supabase
    deleteFromSupabaseLog(message.status);
  } else if (message.action === "popup_opened" || message.action === "check_restore") {
    // Saat popup dibuka, segera polling restore commands dan sinkronkan akun bermasalah lokal
    pollRestoreCommands();
    syncLocalProblematicToAdmin();
  }
  return false;
});

// Hapus semua entri accounts_log milik worker ini berdasarkan status
function deleteFromSupabaseLog(status) {
  chrome.storage.local.get(["workerId"], (res) => {
    const workerId = res.workerId;
    if (!workerId || workerId === "UNKNOWN_PC") return;
    const statusFilter = status === "PHONE_VERIFICATION"
      ? "status=eq.PHONE_VERIFICATION"
      : "status=eq.PROBLEM";
    fetch(`${SUPABASE_URL}/rest/v1/accounts_log?worker_id=eq.${encodeURIComponent(workerId)}&${statusFilter}`, {
      method: 'DELETE',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
      }
    })
    .then(r => { if (r.ok) console.log(`[Supabase] 🧹 Sync: dihapus ${status} entries untuk ${workerId}`); })
    .catch(e => console.error('[Supabase] sync delete error:', e));
  });
}

// ================================
// 7. Listener chrome.tabs.onActivated - Enhanced with inactivity monitoring and loading safety
// ================================

// Pastikan timer tetap berjalan saat tab diaktifkan
chrome.tabs.onActivated.addListener((activeInfo) => {
  if (isTimerRunning) {
    updateTimerBadge();
  }
  
  // Check if activated tab is known page
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    
    console.log(`[background] 🔄 Tab activated: ${tab.url || 'no URL yet'}`);
    
    // If tab has no URL yet, wait for onUpdated
    if (!tab.url) return;
    
    const isKnown = isKnownPage(tab.url, activeInfo.tabId);
    
    if (isKnown) {
      // Known page activated - stop inactivity timer
      if (isInactivityTimerRunning) {
        console.log(`[background] ✅ Activated known page, stopping inactivity timer`);
        stopInactivityTimer();
        // Resume normal badge display
        if (isTimerRunning) {
          updateTimerBadge();
        }
      }
    } else {
      // Unknown page activated - start/restart inactivity timer with safety checks
      if (!extensionNavigationInProgress) {
        console.log(`[background] ⚠️ Activated unknown page: ${tab.url}`);
        startInactivityTimer(tab.url, activeInfo.tabId);
      } else {
        console.log(`[background] 🚫 Extension navigation in progress, not starting timer for: ${tab.url}`);
      }
    }
  });
});

// ================================
// 8. Listener Network Error Resmi (chrome.webNavigation.onErrorOccurred & tabs.onUpdated)
// ================================

// 8.1 Listener resmi C++ Network Layer Chrome (Log only, no automatic account switch)
if (chrome.webNavigation && chrome.webNavigation.onErrorOccurred) {
  chrome.webNavigation.onErrorOccurred.addListener((details) => {
    // Log only - Do not automatically switch account on transient network errors
    if (details.frameId === 0) {
      console.log(`[background] ℹ️ webNavigation info: Code: ${details.error}, URL: ${details.url}`);
    }
  });
}

// 8.2 Listener chrome.tabs.onUpdated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Do not switch accounts on tab titles or error pages

  // Track loading states
  if (changeInfo.status) {
    if (changeInfo.status === "loading") {
      tabLoadingStates.set(tabId, {
        isLoading: true,
        startTime: Date.now(),
        url: tab.url || 'loading...'
      });
      console.log(`[background] 🔄 Tab ${tabId} started loading: ${tab.url}`);
    } else if (changeInfo.status === "complete") {
      tabLoadingStates.set(tabId, {
        isLoading: false,
        startTime: Date.now(),
        url: tab.url || 'unknown'
      });
      console.log(`[background] ✅ Tab ${tabId} finished loading: ${tab.url}`);
    }
  }
  
  // Update badge saat tab diperbarui
  if (changeInfo.status === "complete" && isTimerRunning) {
    updateTimerBadge();
  }
  
  // Monitor page changes for inactivity timer - only when loading is complete
  if (changeInfo.status === "complete" && tab.url) {
    console.log(`[background] 🔍 Tab ${tabId} navigation complete: ${tab.url}`);
    
    const isKnown = isKnownPage(tab.url, tabId);
    
    if (isKnown) {
      // Known page (SageMaker) - stop inactivity timer if running
      if (isInactivityTimerRunning) {
        console.log(`[background] ✅ Navigated to SageMaker page, stopping inactivity timer`);
        stopInactivityTimer();
        // Resume normal badge display
        if (isTimerRunning) {
          updateTimerBadge();
        }
      }
    } else {
      // Unknown page (NON-SageMaker) - start/restart inactivity timer
      if (!extensionNavigationInProgress) {
        console.log(`[background] ⚠️ Navigated to unknown page: ${tab.url}`);
        // Replace any existing timer with new one for this page
        startInactivityTimer(tab.url, tabId);
      } else {
        console.log(`[background] 🚫 Extension navigation in progress, not starting timer for: ${tab.url}`);
      }
    }
  }
  
  // REMOVED: Automatic account switching on Jupyter Lab tab creation
  // This was causing unwanted tab closures when users manually opened Jupyter Lab
  // The logic below has been commented out to prevent interference with user workflow
  
  /*
  // Logika existing untuk deteksi Jupyter Lab - DISABLED
  if (changeInfo.status === "complete" && tab.url) {
    const regexLab = /^https:\/\/[^\/]+\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/;
    if (regexLab.test(tab.url)) {
      if (!switchedTabs.has(tabId)) {
        switchedTabs.add(tabId);
        switchAccountAutomatically(); // This was causing unwanted behavior
      }
    }
  }
  */
});

// ================================
// 9. Listener chrome.tabs.onCreated - Detect new tab creation
// ================================

chrome.tabs.onCreated.addListener((tab) => {
  console.log(`[background] 🆕 New tab created: ${tab.id}`);
  
  // Only start timer if tab already has a concrete non-known URL.
  // Empty/about:blank tabs will be evaluated by onUpdated when navigation completes.
  if (tab.url && !isKnownPage(tab.url, tab.id) && !extensionNavigationInProgress) {
    console.log(`[background] ⚠️ New tab created with unknown URL (${tab.url}) - starting 3-minute timer`);
    startInactivityTimer(tab.url, tab.id);
  } else {
    console.log(`[background] ℹ️ New tab created (waiting for navigation/completion): ${tab.id}`);
  }
});

// ================================
// 10. Listener chrome.tabs.onRemoved - Enhanced cleanup
// ================================

chrome.tabs.onRemoved.addListener((tabId) => {
  if (switchedTabs.has(tabId)) {
    switchedTabs.delete(tabId);
  }
  
  // Clean up loading states
  if (tabLoadingStates.has(tabId)) {
    tabLoadingStates.delete(tabId);
  }
  
  console.log(`[background] 🗑️ Tab ${tabId} removed and cleaned up`);
  
  // If the removed tab was the one with inactivity timer, stop the timer
  // and check remaining tabs
  if (isInactivityTimerRunning) {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs.length > 0) {
        const activeTab = tabs[0];
        console.log(`[background] 🔄 Checking remaining active tab after removal: ${activeTab.url}`);
        
        const isKnown = isKnownPage(activeTab.url, activeTab.id);
        if (isKnown) {
          console.log(`[background] ✅ Active tab is known, stopping inactivity timer`);
          stopInactivityTimer();
          if (isTimerRunning) {
            updateTimerBadge();
          }
        }
      }
    });
  }
});

// ================================
// 10. Alarm untuk Memastikan Service Worker Tetap Aktif & Polling Restore Terjamin
// ================================

function ensureServiceWorkerAlarms() {
  chrome.alarms.get("keepAlive", (alarm) => {
    if (!alarm) {
      chrome.alarms.create("keepAlive", { periodInMinutes: 0.5 });
      console.log("[Alarms] Alarm keepAlive dibuat (setiap 30 detik).");
    }
  });
  chrome.alarms.get("pollRestoreAlarm", (alarm) => {
    if (!alarm) {
      chrome.alarms.create("pollRestoreAlarm", { periodInMinutes: 0.5 });
      console.log("[Alarms] Alarm pollRestoreAlarm dibuat.");
    }
  });
}

// Inisialisasi alarm langsung saat script dimuat
ensureServiceWorkerAlarms();

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive" || alarm.name === "pollRestoreAlarm") {
    console.log(`[KeepAlive] Alarm triggered (${alarm.name}) - menjalankan polling restore`);
    pollRestoreCommands();
  }
});

// ================================
// 11. Inisialisasi Saat Background Pertama Kali Dijalankan
// ================================

chrome.runtime.onStartup.addListener(async () => {
  console.log("[AutoSwitch] Extension dimulai via onStartup...");
  ensureServiceWorkerAlarms();
  await loadConfigFile();
  startAccountSwitchTimer();
  pollRestoreCommands();
  setTimeout(syncLocalProblematicToAdmin, 8 * 1000);
});

chrome.runtime.onInstalled.addListener(async () => {
  console.log("[AutoSwitch] Extension diinstal/diperbarui via onInstalled...");
  ensureServiceWorkerAlarms();
  await loadConfigFile();
  startAccountSwitchTimer();
  pollRestoreCommands();
  setTimeout(syncLocalProblematicToAdmin, 8 * 1000);
});

// Jalankan auto-load config.json saat service worker pertama kali dibangun
loadConfigFile();

// Hentikan timer saat extension dinonaktifkan
chrome.runtime.onSuspend.addListener(() => {
  console.log("[AutoSwitch] Extension dinonaktifkan, menghentikan timer...");
  stopAccountSwitchTimer();
});
