// content.js

// ================================
// 1. Variables for retry mechanism
// ================================
if (typeof window.__contentScriptLoaded === "undefined") {
  window.__contentScriptLoaded = true;
  window.retryCount = 0;
  window.currentAccount = null;
  window.isProcessingError = false;
  window.monitoringTimers = [];
  window.accountValidationLock = false;
}

var retryCount = window.retryCount || 0;
var MAX_RETRIES = 5;
var currentAccount = window.currentAccount || null;
var isProcessingError = window.isProcessingError || false;
var monitoringTimers = window.monitoringTimers || []; // Track monitoring timers to clear them
var accountValidationLock = window.accountValidationLock || false; // Prevent concurrent validation

// Key untuk menyimpan retry state di storage
var RETRY_STORAGE_KEY = RETRY_STORAGE_KEY || "login_retry_state";

/**
 * Clear all monitoring timers
 */
function clearMonitoringTimers() {
  if (Array.isArray(monitoringTimers)) {
    monitoringTimers.forEach(timerId => clearTimeout(timerId));
  }
  monitoringTimers = [];
  window.monitoringTimers = [];
  console.log(`[content.js] Cleared all monitoring timers`);
}

/**
 * Load retry state dari storage
 */
function loadRetryState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([RETRY_STORAGE_KEY], (items) => {
      const retryState = items[RETRY_STORAGE_KEY];
      if (retryState && retryState.account === currentAccount) {
        retryCount = retryState.count || 0;
        console.log(`[content.js] Loaded retry state: ${retryCount}/${MAX_RETRIES} for account: ${currentAccount}`);
      } else {
        retryCount = 0;
        console.log(`[content.js] Fresh retry state for account: ${currentAccount}`);
      }
      resolve();
    });
  });
}

/**
 * Save retry state ke storage
 */
function saveRetryState() {
  const retryState = {
    account: currentAccount,
    count: retryCount,
    timestamp: Date.now()
  };
  chrome.storage.local.set({ [RETRY_STORAGE_KEY]: retryState }, () => {
    console.log(`[content.js] Saved retry state: ${retryCount}/${MAX_RETRIES} for account: ${currentAccount}`);
  });
}

/**
 * Clear retry state dari storage
 */
function clearRetryState() {
  chrome.storage.local.remove([RETRY_STORAGE_KEY], () => {
    console.log(`[content.js] Cleared retry state`);
  });
}

// ================================
// 2. Helper: Log activity (WebSocket functionality removed)
// ================================
function sendStatusUpdate(activity) {
  // WebSocket status update functionality removed
  console.log(`[content.js] Activity: ${activity} at ${window.location.href}`);
}

// ================================
// 3. Error detection functions
// ================================

/**
 * Debug function untuk manually test error detection
 */
function testErrorDetection() {
  console.log("[content.js] === TESTING ERROR DETECTION ===");
  
  // Check the specific error container
  try {
    const errorContainer = document.evaluate(
      "/html/body/div[2]/div/div/div",
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue;
    
    if (errorContainer) {
      console.log("Error container found:", {
        textContent: errorContainer.textContent,
        innerHTML: errorContainer.innerHTML,
        visible: errorContainer.offsetParent !== null
      });
    } else {
      console.log("Error container NOT found at XPath: /html/body/div[2]/div/div/div");
    }
  } catch (err) {
    console.log("Error checking XPath:", err);
  }
  
  // Test error detection function
  const errorInfo = detectLoginErrors();
  console.log("Error detection result:", errorInfo);
}

// Make function available globally for manual testing
window.testErrorDetection = testErrorDetection;

/**
 * Test function to check storage contents - available in console
 */
function testStorageContents() {
  console.log("[content.js] === TESTING STORAGE CONTENTS ===");
  chrome.storage.local.get(["activeAccount", "accounts", "problematicAccounts"], (items) => {
    console.log("📁 Storage contents:", {
      activeAccount: items.activeAccount,
      accounts: items.accounts ? items.accounts.split('\n') : [],
      problematicAccounts: items.problematicAccounts ? items.problematicAccounts.split('\n') : []
    });
    
    if (items.activeAccount) {
      const [username, password] = items.activeAccount.split('|');
      console.log("🔍 ActiveAccount analysis:", {
        original: items.activeAccount,
        username: username,
        password: password,
        passwordLength: password ? password.length : 'undefined',
        isValid: !!(username && password && password !== 'undefined' && password.trim() !== '')
      });
    }
  });
}

// Make test function available globally
window.testStorageContents = testStorageContents;

/**
 * Test input detection function - available in console
 */
function testInputDetection() {
  console.log("[content.js] === TESTING INPUT DETECTION ===");
  
  // Test username detection
  findInputWithMultipleStrategies('username')
    .then(usernameInput => {
      if (usernameInput) {
        console.log("✅ Username input found:", usernameInput);
        console.log("Username input details:", {
          tagName: usernameInput.tagName,
          type: usernameInput.type,
          name: usernameInput.name,
          id: usernameInput.id,
          className: usernameInput.className,
          placeholder: usernameInput.placeholder
        });
      } else {
        console.error("❌ Username input NOT found");
      }
    })
    .catch(err => console.error("❌ Username detection error:", err));
  
  // Test password detection
  findInputWithMultipleStrategies('password')
    .then(passwordInput => {
      if (passwordInput) {
        console.log("✅ Password input found:", passwordInput);
        console.log("Password input details:", {
          tagName: passwordInput.tagName,
          type: passwordInput.type,
          name: passwordInput.name,
          id: passwordInput.id,
          className: passwordInput.className,
          placeholder: passwordInput.placeholder
        });
      } else {
        console.error("❌ Password input NOT found");
      }
    })
    .catch(err => console.error("❌ Password detection error:", err));
  
  // Test submit button detection
  findSubmitButton()
    .then(submitBtn => {
      if (submitBtn) {
        console.log("✅ Submit button found:", submitBtn);
        console.log("Submit button details:", {
          tagName: submitBtn.tagName,
          type: submitBtn.type,
          className: submitBtn.className,
          textContent: submitBtn.textContent.trim()
        });
      } else {
        console.error("❌ Submit button NOT found");
      }
    })
    .catch(err => console.error("❌ Submit button detection error:", err));
}

// Make test function available globally
window.testInputDetection = testInputDetection;

/**
 * Detect if Captcha or security challenge is present on page
 */
function isCaptchaPresent() {
  try {
    // 0. Check for Captcha script tags (e.g. AWS WAF jsapi.js from static.captcha.awswaf.com)
    const captchaScripts = document.querySelectorAll('script[src*="captcha"], script[src*="recaptcha"], script[src*="hcaptcha"], script[src*="arkose"], script[src*="awswaf"]');
    for (const script of captchaScripts) {
      const src = (script.src || '').toLowerCase();
      if (src.includes('captcha.awswaf.com') || src.includes('recaptcha.net') || src.includes('google.com/recaptcha') || src.includes('hcaptcha.com') || src.includes('arkoselabs.com')) {
        console.log(`[content.js] 🧩 Captcha script detected: ${src}`);
        return true;
      }
    }

    // 1. Check iframes for captcha/challenge services
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      if (!isElementVisible(iframe)) continue;
      const src = (iframe.src || '').toLowerCase();
      const id = (iframe.id || '').toLowerCase();
      const name = (iframe.name || '').toLowerCase();
      const title = (iframe.title || '').toLowerCase();
      
      const captchaKeywords = [
        'captcha', 'recaptcha', 'hcaptcha', 'arkose',
        'turnstile', 'funcaptcha', 'aws-waf-captcha', 'amazon-captcha'
      ];
      if (captchaKeywords.some(kw => src.includes(kw) || id.includes(kw) || name.includes(kw) || title.includes(kw))) {
        console.log(`[content.js] 🧩 Captcha iframe detected: src='${src}', id='${id}', title='${title}'`);
        return true;
      }
    }

    // 2. Check DOM selectors for captcha/challenge containers & React CaptchaModal
    const captchaSelectors = [
      "aws-waf-captcha",
      ".aws-waf-captcha-container",
      "#aws-waf-captcha",
      "[class*='CaptchaModal' i]",
      "[class*='captchaModal' i]",
      "[class*='captcha' i]",
      "[id*='captcha' i]",
      "#arkose",
      "[class*='arkose' i]",
      "#hcaptcha",
      "#g-recaptcha",
      ".g-recaptcha",
      "[data-sitekey]",
      "[src*='captcha.awswaf.com']"
    ];

    for (const selector of captchaSelectors) {
      try {
        const els = document.querySelectorAll(selector);
        for (const el of els) {
          if (isElementVisible(el)) {
            const tagName = el.tagName.toLowerCase();
            if (tagName === 'input' || tagName === 'button') continue;
            
            console.log(`[content.js] 🧩 Captcha container element detected via selector: ${selector}`);
            return true;
          }
        }
      } catch (e) {
        // ignore invalid selector syntax
      }
    }

    // 3. Check modal dialogs containing captcha/challenge text
    const modals = document.querySelectorAll('[role="dialog"], [role="alertdialog"], .modal, .popup, div[class*="modal" i], div[class*="popup" i], div[class*="dialog" i]');
    for (const modal of modals) {
      if (isElementVisible(modal)) {
        const text = (modal.innerText || modal.textContent || '').toLowerCase();
        if (text.includes('captcha') || text.includes('verify you are human') || text.includes('solve this puzzle')) {
          console.log(`[content.js] 🧩 Captcha modal dialog detected with text: ${text.substring(0, 50)}...`);
          return true;
        }
      }
    }
    
    // 4. Check specific container XPath /html/body/div[2] for captcha or iframe or aws-waf
    try {
      const modalContainer = document.evaluate(
        "/html/body/div[2]",
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      ).singleNodeValue;
      if (modalContainer && isElementVisible(modalContainer)) {
        const modalText = (modalContainer.innerText || modalContainer.textContent || '').toLowerCase();
        const modalHTML = (modalContainer.innerHTML || '').toLowerCase();
        const hasCaptchaIframe = modalContainer.querySelector('iframe[src*="captcha"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="awswaf"]') !== null;
        if (hasCaptchaIframe || modalText.includes('captcha') || modalHTML.includes('awswaf') || modalHTML.includes('captcha')) {
          console.log(`[content.js] 🧩 Captcha/Challenge detected in /html/body/div[2] modal container`);
          return true;
        }
      }
    } catch (e) {}

  } catch (err) {
    console.error("[content.js] Error in isCaptchaPresent check:", err);
  }
  
  return false;
}

// Make function available globally for testing
window.isCaptchaPresent = isCaptchaPresent;

/**
 * Deteksi apakah teks merupakan banner pengumuman/informasi AWS SageMaker (bukan error login)
 */
function isAnnouncementNotice(text) {
  if (!text) return false;
  const lowerText = text.toLowerCase();
  
  const announcementPatterns = [
    "no longer be open to new customers",
    "no longer open to new customers",
    "is no longer open",
    "explore amazon sagemaker studio",
    "capabilities similar to amazon sagemaker studio lab",
    "sagemaker studio (free tier)"
  ];
  
  return announcementPatterns.some(pattern => lowerText.includes(pattern));
}

// Make function available globally for testing
window.isAnnouncementNotice = isAnnouncementNotice;

/**
 * Deteksi error messages di halaman login
 */
function detectLoginErrors() {
  // If Captcha or security challenge is present, do NOT treat as error
  if (isCaptchaPresent()) {
    console.log("[content.js] 🧩 Captcha/Challenge active on page - not treating as error.");
    return { hasError: false, isCaptcha: true };
  }

  const bodyText = document.body.innerText || document.body.textContent || "";
  
  // Check specific error container XPath
  let errorContainer = null;
  try {
    errorContainer = document.evaluate(
      "/html/body/div[2]/div/div/div",
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue;
  } catch (err) {
    console.log("[content.js] Error container XPath not found:", err);
  }
  
  // If error container exists, check if it's just an AWS announcement notice
  if (errorContainer) {
    const containerText = (errorContainer.innerText || errorContainer.textContent || "").trim();
    if (isAnnouncementNotice(containerText)) {
      console.log(`[content.js] 🟢 Container contains AWS announcement notice, ignoring as login error: '${containerText.substring(0, 60)}...'`);
      errorContainer = null;
    }
  }
  
  // Get error text from container (for generic check)
  const containerTextForGeneric = errorContainer ? 
    (errorContainer.innerText || errorContainer.textContent || "") : 
    "";
  
  console.log("[content.js] Checking for errors in body text...");
  
  // Error messages yang perlu dideteksi
  const errorPatterns = [
    "To complete registration, please click on the link in the email we've sent to",
    "This email or password didn't match our records. Please try again",
    "Your account will be locked after 5 unsuccessful attempts",
    "Account not found",
    "Invalid credentials",
    "Please verify your email",
    "We couldn't sign you in",
    "Sign in failed",
    "Authentication failed",
    "Login error",
    "Invalid email or password"
  ];
  
  for (const pattern of errorPatterns) {
    if (bodyText.includes(pattern)) {
      console.log(`[content.js] ⚠️ Error detected: ${pattern}`);
      return {
        hasError: true,
        errorType: pattern,
        errorMessage: bodyText.substring(
          bodyText.indexOf(pattern),
          bodyText.indexOf(pattern) + pattern.length + 100
        ).trim(),
        errorContainer: errorContainer
      };
    }
  }
  
  // Check for generic error indicators in error container
  if (containerTextForGeneric.trim().length > 0 && !isAnnouncementNotice(containerTextForGeneric)) {
    const containerText = containerTextForGeneric.trim().toLowerCase();
    
    // Daftar kata kunci yang benar-benar menandakan error login
    const errorKeywords = [
      "error", "invalid", "incorrect", "failed", "wrong", 
      "not match", "not found", "locked", "blocked"
    ];
    
    // Cek apakah teks mengandung salah satu kata kunci error
    const isRealError = errorKeywords.some(keyword => containerText.includes(keyword));

    if (containerText.length > 10 && isRealError) {
      console.log(`[content.js] ⚠️ Generic error in container: ${containerTextForGeneric}`);
      return {
        hasError: true,
        errorType: "Unknown error",
        errorMessage: containerTextForGeneric,
        errorContainer: errorContainer
      };
    }
  }
  
  return { hasError: false };
}

/**
 * Handle error dengan retry mechanism
 */
function handleLoginError(errorInfo) {
  if (isProcessingError) return;
  
  // Safeguard: Do not handle as login error if page has already navigated away from login page
  if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
    console.log(`[content.js] Ignoring handleLoginError because page is not on login page (${window.location.href})`);
    return;
  }
  
  // Extra safeguard: Never handle as error if Captcha is present
  if (isCaptchaPresent()) {
    console.log(`[content.js] 🧩 Captcha detected inside handleLoginError - cancelling reload.`);
    return;
  }
  
  isProcessingError = true;
  retryCount++;
  
  // Save retry state ke storage sebelum reload
  saveRetryState();
  
  console.log(`[content.js] Error detected (${retryCount}/${MAX_RETRIES}): ${errorInfo.errorType}`);
  console.log(`[content.js] 🔍 DEBUGGING - currentAccount at error time: '${currentAccount}'`);
  console.log(`[content.js] 🔍 currentAccount type: ${typeof currentAccount}, includes pipe: ${currentAccount ? currentAccount.includes('|') : 'N/A'}`);
  
  // Validate currentAccount format
  if (currentAccount && currentAccount.includes("|")) {
    const [debugUsername, debugPassword] = currentAccount.split("|");
    console.log(`[content.js] 🔍 currentAccount components - Username: '${debugUsername}', Password: '${debugPassword}' (length: ${debugPassword ? debugPassword.length : 'undefined'})`);
  }
  
  // Update status di popup
  chrome.runtime.sendMessage({
    action: "update_retry_status",
    status: `Reload ${retryCount}/${MAX_RETRIES} - ${errorInfo.errorType.substring(0, 30)}...`,
    show: true
  });
  
  if (retryCount >= MAX_RETRIES) {
    // Sudah maksimal retry, pindahkan akun ke bermasalah
    console.log(`[content.js] Max retries reached. Moving account to problematic list.`);
    console.log(`[content.js] 🔍 Final currentAccount value: '${currentAccount}'`);
    
    // Clear retry state
    clearRetryState();
    
    // Pastikan currentAccount memiliki format yang benar (username|password)
    if (currentAccount && currentAccount.includes("|")) {
      const [checkUsername, checkPassword] = currentAccount.split("|");
      if (checkUsername && checkPassword && checkPassword !== 'undefined' && checkPassword.trim() !== '') {
        console.log(`[content.js] ✅ Sending valid account to problematic: ${checkUsername}|[HIDDEN]`);
        chrome.runtime.sendMessage({
          action: "move_account_to_problematic",
          account: currentAccount, // This should be in format: username|password
          errorType: errorInfo.errorType,
          errorMessage: errorInfo.errorMessage
        });
      } else {
        console.error(`[content.js] ❌ Account has invalid password component: Username='${checkUsername}', Password='${checkPassword}'`);
        // Try to get from storage as fallback
        attemptStorageFallback(errorInfo);
      }
    } else {
      console.error(`[content.js] ❌ Invalid account format for moving to problematic: '${currentAccount}'`);
      attemptStorageFallback(errorInfo);
    }
    
    // Hide retry status
    chrome.runtime.sendMessage({
      action: "update_retry_status",
      show: false
    });
    
    // Reset untuk akun berikutnya
    retryCount = 0;
    isProcessingError = false;
    
  } else {
    // Masih ada retry, reload halaman
    setTimeout(() => {
      if (isCaptchaPresent()) {
        console.log(`[content.js] 🧩 Captcha appeared before reload - cancelling reload.`);
        isProcessingError = false;
        return;
      }
      console.log(`[content.js] Reloading page for retry ${retryCount}/${MAX_RETRIES}`);
      window.location.reload();
    }, 2000); // Delay 2 detik sebelum reload
  }
}

/**
 * Fallback function to get account from storage when currentAccount is corrupted
 */
function attemptStorageFallback(errorInfo) {
  console.log(`[content.js] 🔄 Attempting storage fallback...`);
  chrome.storage.local.get(["activeAccount"], (items) => {
    console.log(`[content.js] 🔍 Storage activeAccount: '${items.activeAccount}'`);
    
    if (items.activeAccount && items.activeAccount.includes("|")) {
      const [storageUsername, storagePassword] = items.activeAccount.split("|");
      if (storageUsername && storagePassword && storagePassword !== 'undefined' && storagePassword.trim() !== '') {
        console.log(`[content.js] ✅ Using valid activeAccount from storage: ${storageUsername}|[HIDDEN]`);
        chrome.runtime.sendMessage({
          action: "move_account_to_problematic",
          account: items.activeAccount,
          errorType: errorInfo.errorType,
          errorMessage: errorInfo.errorMessage
        });
      } else {
        console.error(`[content.js] ❌ Storage account also has invalid password: Username='${storageUsername}', Password='${storagePassword}'`);
      }
    } else {
      console.error(`[content.js] ❌ Could not determine valid account to move to problematic`);
    }
  });
}

/**
 * Monitor halaman untuk error setelah login attempt
 */
function monitorForErrors() {
  if (!currentAccount || isProcessingError) return;
  if (!window.location.href.includes("/login")) {
    console.log(`[content.js] Skipping monitorForErrors because not on login page (${window.location.href})`);
    return;
  }
  
  console.log(`[content.js] Starting error monitoring for account: ${currentAccount}`);
  
  // Clear any existing monitoring timers
  clearMonitoringTimers();
  
  // Early success detection & Captcha check loop
  const successCheck = setInterval(() => {
    if (!window.location.href.includes("/login")) {
      console.log(`[content.js] ✓ Early success detected - navigated away from login page`);
      clearInterval(successCheck);
      clearMonitoringTimers();
      
      // Login berhasil
      retryCount = 0;
      isProcessingError = false;
      clearRetryState();
      
      chrome.runtime.sendMessage({
        action: "update_retry_status",
        show: false
      });
      
      console.log(`[content.js] ✓ Login successful for account: ${currentAccount}`);
      sendStatusUpdate("login_successful");
      return;
    }

    // Check if Captcha is present during monitoring
    if (isCaptchaPresent()) {
      console.log(`[content.js] 🧩 Captcha present during monitoring. Pausing error reloads...`);
      chrome.runtime.sendMessage({
        action: "update_retry_status",
        status: `Captcha terdeteksi - silakan selesaikan Captcha (Menunggu)...`,
        show: true
      });
    }
  }, 1000); // Check every second for successful navigation or captcha
  
  // Stop success check after 5 minutes (300000ms) to give ample time for captcha completion
  setTimeout(() => {
    if (!isCaptchaPresent()) {
      clearInterval(successCheck);
    }
  }, 300000);
  
  // Check for immediate errors (after 3 seconds)
  const timer1 = setTimeout(() => {
    if (!window.location.href.includes("/login")) {
      // Already navigated away, success was handled above
      return;
    }
    
    if (isCaptchaPresent()) {
      console.log(`[content.js] 🧩 Captcha detected at timer1 check - skipping error reload`);
      return;
    }
    
    const errorInfo = detectLoginErrors();
    if (errorInfo.hasError) {
      console.log(`[content.js] ⚠️ Early error detected: ${errorInfo.errorType}`);
      clearInterval(successCheck);
      clearMonitoringTimers();
      handleLoginError(errorInfo);
      return;
    }
  }, 3000);
  monitoringTimers.push(timer1);
  
  // Main error check (after 8 seconds - give time for login to complete)
  const timer2 = setTimeout(() => {
    if (!window.location.href.includes("/login")) {
      // Already navigated away, success was handled above
      return;
    }
    
    if (isCaptchaPresent()) {
      console.log(`[content.js] 🧩 Captcha detected at timer2 check - skipping error reload`);
      return;
    }
    
    const errorInfo = detectLoginErrors();
    if (errorInfo.hasError) {
      console.log(`[content.js] ⚠️ Error detected: ${errorInfo.errorType}`);
      clearInterval(successCheck);
      clearMonitoringTimers();
      handleLoginError(errorInfo);
    } else {
      // Check if we're still on login page
      if (window.location.href.includes("/login")) {
        console.log(`[content.js] Still on login page after 8 seconds, checking for error indicators...`);
        
        if (isCaptchaPresent()) {
          console.log(`[content.js] 🧩 Captcha detected - skipping error element check`);
          return;
        }

        // Look for specific error-related elements (more selective)
        const errorSelectors = [
          ".error", ".alert-danger", ".notification-error", ".message-error", 
          "[role='alert']", "[class*='error-message']", "[class*='login-error']"
        ];
        
        let hasErrorElement = false;
        let errorText = "";
        
        for (const selector of errorSelectors) {
          const errorEl = document.querySelector(selector);
          if (errorEl && errorEl.textContent && errorEl.textContent.trim()) {
            const tempText = errorEl.textContent.trim();
            
            // Check if this is an AWS announcement notice
            if (isAnnouncementNotice(tempText)) {
              console.log(`[content.js] 🟢 Mengabaikan banner pengumuman AWS: '${tempText.substring(0, 50)}...'`);
              continue; // Lanjut cek element lain, jangan anggap sebagai error
            }
            
            // Hanya anggap sebagai error jika benar-benar mengandung kata kunci error
            const errorKeywords = [
              "error", "invalid", "incorrect", "failed", "wrong", 
              "not match", "not found", "locked", "blocked"
            ];
            
            const isRealError = errorKeywords.some(keyword => tempText.toLowerCase().includes(keyword));
            
            if (!isRealError) {
              console.log(`[content.js] 🟢 Mengabaikan teks karena bukan error (Info/Pengumuman): '${tempText.substring(0, 50)}...'`);
              continue; // Lanjut cek element lain, jangan anggap sebagai error
            }
            
            hasErrorElement = true;
            errorText = tempText;
            console.log(`[content.js] Found error element with selector '${selector}': ${errorText}`);
            break;
          }
        }
        
        // Check the specific error container - but be more selective
        if (!hasErrorElement) {
          try {
            const errorContainer = document.evaluate(
              "/html/body/div[2]/div/div/div",
              document,
              null,
              XPathResult.FIRST_ORDERED_NODE_TYPE,
              null
            ).singleNodeValue;
            
            if (errorContainer && errorContainer.textContent) {
              const containerText = errorContainer.textContent.trim();
              
              if (isAnnouncementNotice(containerText)) {
                console.log(`[content.js] 🟢 Mengabaikan container XPath karena berisi banner pengumuman AWS: '${containerText.substring(0, 50)}...'`);
              } else {
                const errorKeywords = [
                  "error", "invalid", "incorrect", "failed", "wrong", 
                  "not match", "not found", "locked", "blocked"
                ];
                
                const hasErrorKeyword = errorKeywords.some(keyword => 
                  containerText.toLowerCase().includes(keyword)
                );
                
                if (hasErrorKeyword && containerText.length > 10) {
                  hasErrorElement = true;
                  errorText = containerText;
                  console.log(`[content.js] Found error in XPath container: ${errorText}`);
                }
              }
            }
          } catch (err) {
            console.log(`[content.js] Could not check error container XPath`);
          }
        }
        
        if (hasErrorElement) {
          clearInterval(successCheck);
          clearMonitoringTimers();
          handleLoginError({
            hasError: true,
            errorType: "Login failed - error detected",
            errorMessage: errorText
          });
          return;
        } else {
          // No explicit error detected - do not trigger false timeout errors
          // Just let successCheck continue waiting for navigation or CAPTCHA completion
          console.log(`[content.js] No explicit login errors detected on page. Waiting for navigation or CAPTCHA completion...`);
        }
      }
    }
  }, 8000); // Increased wait time to 8 seconds
  monitoringTimers.push(timer2);
}

// ================================
// 4. Fungsi menunggu elemen via selector (jika tidak kosong) atau XPath
// ================================
function waitForSelectorOrXPath(selector, xpath, timeout = 60000) {
  return new Promise((resolve, reject) => {
    const intervalTime = 500; // cek setiap 0.5 detik (lebih responsif)
    let elapsed = 0;

    const intervalId = setInterval(() => {
      // Jika selector tidak kosong, coba CSS selector
      if (selector && selector.trim() !== "") {
        try {
          const elCSS = document.querySelector(selector);
          if (elCSS && isElementVisible(elCSS)) { // Ensure element is visible
            clearInterval(intervalId);
            console.log(`[content.js] Found element with CSS selector: ${selector}`);
            resolve(elCSS);
            return;
          }
        } catch (err) {
          // Jika selector invalid, abaikan dan lanjutkan ke XPath
          console.log(`[content.js] CSS selector failed: ${selector}, trying XPath`);
        }
      }

      // Coba XPath jika tersedia
      if (xpath && xpath.trim() !== "") {
        try {
          const xpathResult = document
            .evaluate(
              xpath,
              document,
              null,
              XPathResult.FIRST_ORDERED_NODE_TYPE,
              null
            )
            .singleNodeValue;
          if (xpathResult && isElementVisible(xpathResult)) { // Ensure element is visible
            clearInterval(intervalId);
            console.log(`[content.js] Found element with XPath: ${xpath}`);
            resolve(xpathResult);
            return;
          }
        } catch (err) {
          // Jika XPath invalid, reject
          console.error(`[content.js] XPath invalid: ${xpath}. Error: ${err.message}`);
        }
      }

      elapsed += intervalTime;
      if (elapsed >= timeout) {
        clearInterval(intervalId);
        const errorMsg = selector 
          ? `Timeout: Elemen "${selector}" atau [XPath: ${xpath}] tidak ditemukan dalam ${timeout}ms`
          : `Timeout: [XPath: ${xpath}] tidak ditemukan dalam ${timeout}ms`;
        reject(new Error(errorMsg));
      }
    }, intervalTime);
  });
}

// ================================
// 5. Enhanced input detection and simulation functions
// ================================

/**
 * Find input field using multiple strategies based on project specifications
 */
async function findInputWithMultipleStrategies(inputType) {
  const strategies = {
    username: {
      selectors: [
        "input[name='email']",
        "input[type='email']",
        "input[name='username']",
        "input[name='user']",
        "input[autocomplete='email']",
        "input[autocomplete='username']",
        "input[placeholder*='email' i]",
        "input[placeholder*='username' i]",
        "input[placeholder*='user' i]",
        "input[id*='email' i]",
        "input[id*='username' i]",
        "input[id*='user' i]"
      ],
      xpath: "/html/body/div[2]/div/div/form/section/div[1]/div/div/div/input",
      attributes: ['email', 'username', 'user']
    },
    password: {
      selectors: [
        "input[type='password']",
        "input[name='password']",
        "input[name='pass']",
        "input[autocomplete='current-password']",
        "input[autocomplete='password']",
        "input[placeholder*='password' i]",
        "input[placeholder*='pass' i]",
        "input[id*='password' i]",
        "input[id*='pass' i]"
      ],
      xpath: "/html/body/div[2]/div/div/form/section/div[2]/div/div/div/input",
      attributes: ['password', 'pass']
    }
  };

  const config = strategies[inputType];
  if (!config) {
    throw new Error(`Unknown input type: ${inputType}`);
  }

  console.log(`[content.js] 🔍 Trying multiple strategies for ${inputType} input...`);

  // Strategy 1: Try known XPath first (fastest)
  try {
    console.log(`[content.js] 🏆 Strategy 1: Testing known XPath for ${inputType}...`);
    const element = await waitForSelectorOrXPath("", config.xpath, 10000);
    if (element && isElementVisible(element)) {
      console.log(`[content.js] ✅ Found ${inputType} input via XPath`);
      return element;
    }
  } catch (err) {
    console.log(`[content.js] XPath failed for ${inputType}: ${err.message}`);
  }

  // Strategy 2: Try CSS selectors
  console.log(`[content.js] 🏆 Strategy 2: Testing CSS selectors for ${inputType}...`);
  for (const selector of config.selectors) {
    try {
      const element = document.querySelector(selector);
      if (element && isElementVisible(element)) {
        console.log(`[content.js] ✅ Found ${inputType} input via selector: ${selector}`);
        return element;
      }
    } catch (err) {
      console.log(`[content.js] Selector failed: ${selector}`);
    }
  }

  // Strategy 3: Search by attributes and context
  console.log(`[content.js] 🏆 Strategy 3: Searching by attributes for ${inputType}...`);
  const allInputs = document.querySelectorAll('input');
  for (const input of allInputs) {
    if (!isElementVisible(input)) continue;
    
    const inputText = (
      input.name + ' ' +
      input.type + ' ' +
      input.placeholder + ' ' +
      input.id + ' ' +
      input.getAttribute('autocomplete') + ' ' +
      input.className
    ).toLowerCase();

    for (const attr of config.attributes) {
      if (inputText.includes(attr)) {
        console.log(`[content.js] ✅ Found ${inputType} input via attribute search: ${attr}`);
        return input;
      }
    }
  }

  // Strategy 4: Fallback - first visible input of expected type
  console.log(`[content.js] 🏆 Strategy 4: Fallback search for ${inputType}...`);
  if (inputType === 'password') {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    for (const input of passwordInputs) {
      if (isElementVisible(input)) {
        console.log(`[content.js] ✅ Found ${inputType} input via type fallback`);
        return input;
      }
    }
  } else {
    // For username, look for first visible text/email input
    const textInputs = document.querySelectorAll('input[type="text"], input[type="email"], input:not([type])');
    for (const input of textInputs) {
      if (isElementVisible(input)) {
        console.log(`[content.js] ✅ Found ${inputType} input via fallback`);
        return input;
      }
    }
  }

  console.error(`[content.js] ❌ Failed to find ${inputType} input with any strategy`);
  return null;
}

/**
 * Find submit button using multiple strategies
 */
async function findSubmitButton() {
  const strategies = [
    // Strategy 1: Known XPath
    () => {
      console.log(`[content.js] 🏆 Trying known XPath for submit button...`);
      return waitForSelectorOrXPath("", "/html/body/div[2]/div/div/form/section/div[4]/button/span[1]", 3000)
        .then(el => el && isElementVisible(el) ? el : null)
        .catch(() => null);
    },
    // Strategy 2: Submit type
    () => {
      console.log(`[content.js] 🏆 Looking for submit type button...`);
      const button = document.querySelector('button[type="submit"]');
      return isElementVisible(button) ? button : null;
    },
    // Strategy 3: Submit class
    () => {
      console.log(`[content.js] 🏆 Looking for submit class button...`);
      const button = document.querySelector('button[class*="submit"]');
      return isElementVisible(button) ? button : null;
    },
    // Strategy 4: Text content
    () => {
      console.log(`[content.js] 🏆 Looking for button by text content...`);
      const buttons = document.querySelectorAll('button');
      for (const button of buttons) {
        if (!isElementVisible(button)) continue;
        const text = button.textContent.toLowerCase();
        if (text.includes('sign in') || text.includes('login') || text.includes('submit')) {
          return button;
        }
      }
      return null;
    },
    // Strategy 5: Form context
    () => {
      console.log(`[content.js] 🏆 Looking for button in form context...`);
      const forms = document.querySelectorAll('form');
      for (const form of forms) {
        const button = form.querySelector('button');
        if (button && isElementVisible(button)) {
          return button;
        }
      }
      return null;
    }
  ];

  for (const strategy of strategies) {
    try {
      const button = await strategy();
      if (button) {
        console.log(`[content.js] ✅ Found submit button`);
        return button;
      }
    } catch (err) {
      console.log(`[content.js] Submit button strategy failed:`, err.message);
    }
  }

  console.error(`[content.js] ❌ Failed to find submit button with any strategy`);
  return null;
}

/**
 * Check if element is visible and interactable
 */
function isElementVisible(element) {
  if (!element) return false;
  try {
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
  } catch(e) {}
  return (element.offsetWidth > 0 || element.offsetHeight > 0 || (element.getClientRects && element.getClientRects().length > 0) || element.offsetParent !== null);
}

/**
 * Enhanced typing simulation with better event handling
 */
async function enhancedSimulateTyping(element, text) {
  if (!element) {
    throw new Error("Element is null or undefined");
  }

  console.log(`[content.js] 🔄 Enhanced typing: "${text}" into element`);
  
  // Focus the element
  element.focus();
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Clear existing value
  element.value = "";
  
  // Dispatch focus event
  element.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
  
  // Set value directly (most reliable method)
  element.value = text;
  
  // Dispatch comprehensive events for modern frameworks
  const events = [
    new Event('input', { bubbles: true, cancelable: true }),
    new Event('change', { bubbles: true, cancelable: true }),
    new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }),
    new KeyboardEvent('keyup', { key: 'Tab', bubbles: true }),
    new FocusEvent('blur', { bubbles: true })
  ];
  
  for (const event of events) {
    element.dispatchEvent(event);
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  
  console.log(`[content.js] ✅ Enhanced typing completed`);
}

/**
 * Debug function to see all input fields (available in console)
 */
function debugInputFields() {
  console.log("[content.js] === DEBUG: All input fields on page ===");
  const inputs = document.querySelectorAll('input');
  inputs.forEach((input, index) => {
    console.log(`Input ${index + 1}:`, {
      type: input.type,
      name: input.name,
      id: input.id,
      placeholder: input.placeholder,
      className: input.className,
      visible: isElementVisible(input),
      value: input.value
    });
  });
  
  console.log("=== DEBUG: All buttons on page ===");
  const buttons = document.querySelectorAll('button');
  buttons.forEach((button, index) => {
    console.log(`Button ${index + 1}:`, {
      type: button.type,
      className: button.className,
      textContent: button.textContent.trim(),
      visible: isElementVisible(button)
    });
  });
}

// Make debug function available globally
window.debugInputFields = debugInputFields;

/**
 * Original simulateTyping function (kept for backward compatibility)
 */
function simulateTyping(element, text) {
  // Clear field first
  element.value = "";
  element.focus();
  
  // Set value directly (more reliable for modern forms)
  element.value = text;
  
  // Dispatch events to trigger form validation
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new Event("blur", { bubbles: true }));
  
  console.log(`[content.js] Typed: "${text}" into element`);
}

// ================================
// 6. Fungsi simulasi klik
// ================================
function simulateClick(element) {
  element.dispatchEvent(
    new MouseEvent("click", {
      view: window,
      bubbles: true,
      cancelable: true,
    })
  );
}

// ================================
// 7. Fungsi untuk melakukan login dengan username & password
// ================================
async function performLogin(username, password) {
  if (window.__isLoginRunning) {
    console.log(`[content.js] ⏳ Login already in progress for: ${username}, skipping duplicate call`);
    return;
  }
  window.__isLoginRunning = true;

  try {
    if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] Aborting performLogin because page is not on login page (${window.location.href})`);
      window.__isLoginRunning = false;
      return;
    }

    // DON'T overwrite currentAccount here - it should already be set in performLoginFromStorage
    // Only validate that it's set properly
    if (!currentAccount || !currentAccount.includes("|")) {
      console.error(`[content.js] ❌ currentAccount not properly set before performLogin: ${currentAccount}`);
      currentAccount = `${username}|${password}`; // Fallback
      console.log(`[content.js] 🔄 Set currentAccount fallback to: ${currentAccount.split('|')[0]}|[HIDDEN]`);
    } else {
      console.log(`[content.js] ✅ currentAccount already set: ${currentAccount.split('|')[0]}|[HIDDEN]`);
    }
    
    // Load retry state dari storage
    await loadRetryState();
    
    console.log(`[content.js] Attempting login for: ${username} (Retry: ${retryCount}/${MAX_RETRIES})`);
    
    // Wait for page to be ready
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] Aborting performLogin - page navigated away from login page during delay (${window.location.href})`);
      window.__isLoginRunning = false;
      return;
    }

    // Enhanced input detection with multiple strategies
    console.log(`[content.js] 🔍 Starting enhanced input detection...`);
    
    // === FIND USERNAME INPUT WITH MULTIPLE STRATEGIES ===
    console.log(`[content.js] Looking for username input...`);
    const usernameInput = await findInputWithMultipleStrategies('username');
    if (!usernameInput) {
      if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
        console.log(`[content.js] Aborting performLogin - username input missing because page navigated away (${window.location.href})`);
        window.__isLoginRunning = false;
        return;
      }
      throw new Error("Username input not found with any strategy");
    }
    console.log(`[content.js] ✅ Found username input, typing: ${username}`);
    await enhancedSimulateTyping(usernameInput, username);
    await new Promise(resolve => setTimeout(resolve, 800));

    if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] Aborting performLogin - page navigated away during username typing (${window.location.href})`);
      window.__isLoginRunning = false;
      return;
    }

    // === FIND PASSWORD INPUT WITH MULTIPLE STRATEGIES ===
    console.log(`[content.js] Looking for password input...`);
    const passwordInput = await findInputWithMultipleStrategies('password');
    if (!passwordInput) {
      if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
        console.log(`[content.js] Aborting performLogin - password input missing because page navigated away (${window.location.href})`);
        window.__isLoginRunning = false;
        return;
      }
      throw new Error("Password input not found with any strategy");
    }
    console.log(`[content.js] ✅ Found password input, typing password`);
    await enhancedSimulateTyping(passwordInput, password);
    await new Promise(resolve => setTimeout(resolve, 800));

    if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] Aborting performLogin - page navigated away during password typing (${window.location.href})`);
      window.__isLoginRunning = false;
      return;
    }

    // === FIND SUBMIT BUTTON WITH MULTIPLE STRATEGIES ===
    console.log(`[content.js] Looking for submit button...`);
    const signInButton = await findSubmitButton();
    if (!signInButton) {
      if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
        console.log(`[content.js] Aborting performLogin - submit button missing because page navigated away (${window.location.href})`);
        window.__isLoginRunning = false;
        return;
      }
      throw new Error("Submit button not found");
    }
    
    console.log(`[content.js] ✅ Found submit button, clicking`);
    simulateClick(signInButton);

    sendStatusUpdate("login_submitted");
    
    // Monitor for errors after login attempt
    monitorForErrors();
    
    // Release login lock after some delay
    setTimeout(() => {
      window.__isLoginRunning = false;
    }, 5000);
    
  } catch (err) {
    window.__isLoginRunning = false;
    if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] Aborting performLogin error handler - page is no longer on login page (${window.location.href}): ${err.message}`);
      return;
    }
    console.error("[content.js] performLogin error:", err);
    sendStatusUpdate("login_error");
    
    // If login failed, treat as error and handle retry
    const errorInfo = {
      hasError: true,
      errorType: "Login process failed",
      errorMessage: err.message
    };
    handleLoginError(errorInfo);
  }
}

/**
 * Enhanced account validation with proper error handling
 */
function validateAccountFormat(account) {
  if (!account) {
    return { valid: false, error: "Account is null or undefined" };
  }
  
  if (typeof account !== 'string') {
    return { valid: false, error: `Account is not a string: ${typeof account}` };
  }
  
  if (!account.includes("|")) {
    return { valid: false, error: `Account missing pipe separator: '${account}'` };
  }
  
  const parts = account.split("|");
  if (parts.length !== 2) {
    return { valid: false, error: `Account has ${parts.length} parts, expected 2: '${account}'` };
  }
  
  const [username, password] = parts;
  
  if (!username || username.trim() === '') {
    return { valid: false, error: `Username is empty or whitespace: '${username}'` };
  }
  
  if (!password || password === 'undefined' || password.trim() === '') {
    return { valid: false, error: `Password is invalid: '${password}'` };
  }
  
  // Additional validation for common issues
  if (password.length < 3) {
    return { valid: false, error: `Password too short (${password.length} chars): '${password}'` };
  }
  
  return { 
    valid: true, 
    username: username.trim(), 
    password: password.trim() 
  };
}

// ================================
// 8. Fungsi memulai login berdasarkan akun yang tersimpan di storage
// ================================
/**
 * Enhanced performLoginFromStorage with better error handling
 */
function performLoginFromStorage(account) {
  // Prevent concurrent account validation
  if (accountValidationLock) {
    console.warn(`[content.js] Account validation already in progress, ignoring request`);
    return;
  }

  if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
    console.log(`[content.js] Not on login page (${window.location.href}), ignoring performLoginFromStorage`);
    return;
  }
  
  accountValidationLock = true;
  
  try {
    console.log(`[content.js] 🔍 performLoginFromStorage called with account type: ${typeof account}, length: ${account ? account.length : 'undefined'}`);
    
    // Enhanced account validation
    const validation = validateAccountFormat(account);
    if (!validation.valid) {
      console.error(`[content.js] ❌ Account validation failed: ${validation.error}`);
      accountValidationLock = false;
      return;
    }
    
    const { username, password } = validation;
    
    // Set currentAccount AFTER successful validation
    currentAccount = `${username}|${password}`;
    console.log(`[content.js] ✅ Account validated and set: ${username}|[HIDDEN_PASSWORD]`);
    
    // Only proceed if on login page
    if (window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
      console.log(`[content.js] On login page, proceeding with login...`);
      performLogin(username, password);
    } else {
      console.log(`[content.js] Not on login page (${window.location.href}), skipping login`);
    }
    
  } catch (err) {
    console.error(`[content.js] Error in performLoginFromStorage:`, err);
  } finally {
    accountValidationLock = false;
  }
}

// ================================
// 9. Fungsi untuk switch account atas perintah server
// ================================
function switchAccountFromServer() {
  console.log(`[content.js] 🔄 Server-triggered account switch - delegating to background`);
  
  // ENHANCED: Delegate to background's centralized sequence management
  // instead of calculating sequence locally
  chrome.runtime.sendMessage(
    { action: "switch_account_from_server" },
    (response) => {
      if (chrome.runtime.lastError) {
        console.error(`[content.js] Failed to switch account:`, chrome.runtime.lastError.message);
      } else {
        console.log(`[content.js] ✅ Server account switch request sent to background`);
      }
    }
  );
}

// ================================
// 10. Enhanced message listener with ping support
// ================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(`[content.js] Received message:`, message);
  
  try {
    if (message.action === "ping") {
      // Respond to ping for connection testing
      console.log(`[content.js] Responding to ping`);
      sendResponse({ status: "ready", url: window.location.href });
      return true; // Keep message channel open
      
    } else if (message.action === "performLogin") {
      if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
        console.log(`[content.js] Ignoring performLogin message because not on login page (${window.location.href})`);
        sendResponse({ status: "skipped_not_on_login_page" });
        return false;
      }
      
      if (message.account) {
        console.log(`[content.js] Performing login with provided account`);
        performLoginFromStorage(message.account);
      } else {
        console.log(`[content.js] No account in message, using storage activeAccount`);
        // Jika tidak ada account di pesan, pakai activeAccount yang sudah tersimpan
        chrome.storage.local.get(["activeAccount"], (items) => {
          if (items.activeAccount) {
            performLoginFromStorage(items.activeAccount);
          } else {
            console.error(`[content.js] No activeAccount found in storage`);
          }
        });
      }
      sendResponse({ status: "login_initiated" });
      
    } else if (message.action === "switch_account_from_server") {
      console.log(`[content.js] Switching account from server`);
      switchAccountFromServer();
      sendResponse({ status: "account_switch_initiated" });
      
    } else {
      console.warn(`[content.js] Unknown message action: ${message.action}`);
      sendResponse({ status: "unknown_action" });
    }
  } catch (err) {
    console.error(`[content.js] Error handling message:`, err);
    sendResponse({ status: "error", message: err.message });
  }
  
  return false; // Don't keep message channel open by default
});

// ================================
// 11. Enhanced initialization with better error handling
// ================================
(async function init() {
  console.log(`[content.js] Content script initialized on: ${window.location.href}`);
  
  // Only proceed if on login page
  if (!window.location.href.startsWith("https://studiolab.sagemaker.aws/login")) {
    console.log(`[content.js] Not on login page, skipping login process`);
    return;
  }
  
  console.log(`[content.js] On login page, initializing login process...`);
  
  try {
    // Get activeAccount from storage with enhanced error handling
    const items = await new Promise((resolve) => {
      chrome.storage.local.get(["activeAccount"], (result) => {
        resolve(result);
      });
    });
    
    console.log(`[content.js] 🔍 Storage retrieval result:`, {
      hasActiveAccount: !!items.activeAccount,
      accountType: typeof items.activeAccount,
      accountLength: items.activeAccount ? items.activeAccount.length : 'undefined'
    });
    
    if (!items.activeAccount) {
      console.error(`[content.js] ❌ No activeAccount found in storage`);
      return;
    }
    
    // Validate account before proceeding
    const validation = validateAccountFormat(items.activeAccount);
    if (!validation.valid) {
      console.error(`[content.js] ❌ Storage account validation failed: ${validation.error}`);
      return;
    }
    
    const { username, password } = validation;
    console.log(`[content.js] ✅ Valid account found in storage: ${username}|[HIDDEN_PASSWORD]`);
    
    // Set currentAccount
    currentAccount = `${username}|${password}`;
    
    // Load retry state untuk akun ini
    await loadRetryState();
    
    // Show retry status if this is a retry attempt
    if (retryCount > 0) {
      console.log(`[content.js] This is retry attempt ${retryCount}/${MAX_RETRIES}`);
      chrome.runtime.sendMessage({
        action: "update_retry_status",
        status: `Reload ${retryCount}/${MAX_RETRIES} - Retrying login...`,
        show: true
      });
    }
    
    console.log(`[content.js] ✅ Starting login process with account: ${username}|[HIDDEN_PASSWORD]`);
    
    // Add small delay to ensure page is fully ready
    setTimeout(() => {
      performLogin(username, password);
    }, 1000);
    
  } catch (err) {
    console.error(`[content.js] ❌ Error in initialization:`, err);
  }
})();
