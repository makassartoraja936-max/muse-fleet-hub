// Content script untuk menjembatani komunikasi antara injected script dan background script
window.addEventListener('message', (event) => {
    // Hanya terima pesan dari injected script kita
    if (event.data.source === 'captcha-detector') {
        if (event.data.type === 'CAPTCHA_DETECTED') {
            chrome.runtime.sendMessage({ type: 'captcha_detected' });
        } else if (event.data.type === 'CAPTCHA_CLEARED') {
            chrome.runtime.sendMessage({ type: 'captcha_cleared' });
        }
    }
});