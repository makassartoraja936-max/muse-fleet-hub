// =========================
// Global variables
// =========================
let globalCountdownInterval = null;
let globalCaptchaDetectedTime = null;
let globalReloadTimer = null;
let currentTabId = null;

// Untuk login page
let globalLoginDetectedTime = null;
let globalLoginCountdownInterval = null;
let globalLoginReloadTimer = null;

// Untuk Jupyter Lab page
let globalJupyterLabDetectedTime = null;
let globalJupyterLabCountdownInterval = null;
let globalJupyterLabReloadTimer = null;

// Untuk fallback timer (global tapi reset per tab)
let globalFallbackDetectedTime = null;
let globalFallbackCountdownInterval = null;
let globalFallbackReloadTimer = null;
let currentActiveTabId = null;

// =========================
// Fungsi reset timer
// =========================
function resetCaptchaTimer() {
    if (globalCountdownInterval) {
        clearInterval(globalCountdownInterval);
        globalCountdownInterval = null;
    }
    if (globalReloadTimer) {
        clearTimeout(globalReloadTimer);
        globalReloadTimer = null;
    }
    globalCaptchaDetectedTime = null;
    currentTabId = null;
    updateCountdownBadge();
}

function resetLoginTimer() {
    if (globalLoginCountdownInterval) {
        clearInterval(globalLoginCountdownInterval);
        globalLoginCountdownInterval = null;
    }
    if (globalLoginReloadTimer) {
        clearTimeout(globalLoginReloadTimer);
        globalLoginReloadTimer = null;
    }
    globalLoginDetectedTime = null;
    updateCountdownBadge();
}

function resetJupyterLabTimer() {
    if (globalJupyterLabCountdownInterval) {
        clearInterval(globalJupyterLabCountdownInterval);
        globalJupyterLabCountdownInterval = null;
    }
    if (globalJupyterLabReloadTimer) {
        clearTimeout(globalJupyterLabReloadTimer);
        globalJupyterLabReloadTimer = null;
    }
    globalJupyterLabDetectedTime = null;
    updateCountdownBadge();
}

function startJupyterLabTimer(tabId) {
    if (globalJupyterLabDetectedTime === null) {
        globalJupyterLabDetectedTime = Date.now();
        console.log('Halaman Jupyter Lab terdeteksi, mulai countdown 90 detik...');

        globalJupyterLabCountdownInterval = setInterval(updateCountdownBadge, 1000);
        updateCountdownBadge();

        globalJupyterLabReloadTimer = setTimeout(() => {
            // Reload sekali
            chrome.tabs.reload(tabId);
            console.log('Reload halaman Jupyter Lab setelah 90 detik');
            // Reset timer - chrome.tabs.onUpdated akan restart jika masih di halaman yang sama
            resetJupyterLabTimer();
        }, 90000);
    }
}

function startFallbackTimer() {
    if (globalFallbackDetectedTime === null) {
        globalFallbackDetectedTime = Date.now();
        console.log('Fallback timer aktif, mulai countdown 95 detik...');

        globalFallbackCountdownInterval = setInterval(updateCountdownBadge, 1000);
        updateCountdownBadge();

        globalFallbackReloadTimer = setTimeout(() => {
            // Reload halaman aktif saat ini (abaikan jika sedang di login)
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].url && !tabs[0].url.includes("/login")) {
                    chrome.tabs.reload(tabs[0].id);
                    console.log(`Fallback reload di tab aktif ${tabs[0].id} setelah 95 detik`);
                } else {
                    console.log(`Fallback reload dilewati karena sedang di halaman login`);
                }
            });

            // Reset dan restart timer untuk loop terus menerus
            resetFallbackTimer();
            setTimeout(() => startFallbackTimer(), 1000);
        }, 95000);
    }
}

function resetFallbackTimer() {
    if (globalFallbackCountdownInterval) {
        clearInterval(globalFallbackCountdownInterval);
        globalFallbackCountdownInterval = null;
    }
    if (globalFallbackReloadTimer) {
        clearTimeout(globalFallbackReloadTimer);
        globalFallbackReloadTimer = null;
    }
    globalFallbackDetectedTime = null;
    updateCountdownBadge();
}

function manageFallbackTimer() {
    const hasActiveSpecificTimer = globalCaptchaDetectedTime !== null ||
                                   globalLoginDetectedTime !== null ||
                                   globalJupyterLabDetectedTime !== null;

    if (hasActiveSpecificTimer) {
        // Jika ada timer spesifik aktif, stop fallback timer
        if (globalFallbackDetectedTime !== null) {
            console.log('Timer spesifik aktif, menghentikan fallback timer...');
            resetFallbackTimer();
        }
    } else {
        // Jika tidak ada timer spesifik aktif, start fallback timer
        if (globalFallbackDetectedTime === null) {
            console.log('Tidak ada timer spesifik aktif, memulai fallback timer...');
            startFallbackTimer();
        }
    }
}

// =========================
// Fungsi update badge
// =========================
function updateCountdownBadge() {
    let texts = [];

    // CAPTCHA countdown
    if (globalCaptchaDetectedTime) {
        const elapsed = Date.now() - globalCaptchaDetectedTime;
        const remaining = Math.max(0, Math.ceil((180000 - elapsed) / 1000));
        if (remaining > 0) {
            texts.push(remaining.toString());
        }
    }

    // Login countdown
    if (globalLoginDetectedTime) {
        const elapsed = Date.now() - globalLoginDetectedTime;
        const remaining = Math.max(0, Math.ceil((180000 - elapsed) / 1000));
        if (remaining > 0) {
            texts.push(remaining.toString());
        }
    }

    // Jupyter Lab countdown
    if (globalJupyterLabDetectedTime) {
        const elapsed = Date.now() - globalJupyterLabDetectedTime;
        const remaining = Math.max(0, Math.ceil((90000 - elapsed) / 1000));
        if (remaining > 0) {
            texts.push(remaining.toString());
        }
    }

    // Fallback countdown (global)
    if (globalFallbackDetectedTime) {
        const elapsed = Date.now() - globalFallbackDetectedTime;
        const remaining = Math.max(0, Math.ceil((95000 - elapsed) / 1000));
        if (remaining > 0) {
            texts.push(remaining.toString());
        }
    }

    // Gabungkan angka jadi badge text
    chrome.action.setBadgeText({ text: texts.join('|') });

    // Tentukan warna - fallback (hijau) memiliki prioritas tertinggi
    if (globalFallbackDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#00FF00' }); // hijau
    } else if (globalCaptchaDetectedTime && globalLoginDetectedTime && globalJupyterLabDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#800080' }); // ungu (untuk kombinasi)
    } else if (globalCaptchaDetectedTime && globalLoginDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#800080' }); // ungu
    } else if (globalCaptchaDetectedTime && globalJupyterLabDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' }); // merah (CAPTCHA priority)
    } else if (globalLoginDetectedTime && globalJupyterLabDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#FFD700' }); // kuning (login priority)
    } else if (globalCaptchaDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#FF0000' }); // merah
    } else if (globalLoginDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#FFD700' }); // kuning
    } else if (globalJupyterLabDetectedTime) {
        chrome.action.setBadgeBackgroundColor({ color: '#FFFFFF' }); // putih
    } else {
        chrome.action.setBadgeText({ text: '' });
    }
}

// =========================
// Listener dari content.js
// =========================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'captcha_detected') {
        if (globalCaptchaDetectedTime === null) {
            globalCaptchaDetectedTime = Date.now();
            currentTabId = sender.tab.id;
            console.log('CAPTCHA terdeteksi, memulai countdown...');

            globalCountdownInterval = setInterval(updateCountdownBadge, 1000);
            updateCountdownBadge();

            globalReloadTimer = setTimeout(() => {
                if (currentTabId) {
                    chrome.tabs.reload(currentTabId);
                }
            }, 180000);

            // Kelola fallback timer - stop karena CAPTCHA aktif
            manageFallbackTimer();
        }
    } else if (message.type === 'captcha_cleared') {
        if (globalCaptchaDetectedTime !== null) {
            console.log('CAPTCHA hilang, membatalkan countdown...');
            resetCaptchaTimer();

            // Kelola fallback timer - mungkin start jika tidak ada timer lain
            manageFallbackTimer();
        }
    }
});

// =========================
// Listener untuk tab activated (user pindah tab)
chrome.tabs.onActivated.addListener((activeInfo) => {
    // Reset fallback timer setiap kali user pindah tab
    resetFallbackTimer();

    // Kelola fallback timer berdasarkan kondisi timer spesifik
    manageFallbackTimer();
});

// =========================

// =========================
// Listener untuk tab update
// =========================
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
        // Setiap kali halaman reload, reset timer CAPTCHA agar tidak tersisa
        resetCaptchaTimer();

        // Kelola fallback timer berdasarkan kondisi timer spesifik
        manageFallbackTimer();

        // --- CAPTCHA injection ---
        if (tab.url.startsWith("https://studiolab.sagemaker.aws/")) {
            chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: initializeCaptchaDetector,
                args: [tabId]
            });
        }

        // --- Login page detection ---
        if (tab.url.startsWith("https://studiolab.sagemaker.aws/login")) {
            // Reset login timer setiap kali reload
            resetLoginTimer();

            globalLoginDetectedTime = Date.now();
            console.log('Halaman login terdeteksi, mulai countdown 180 detik...');

            globalLoginCountdownInterval = setInterval(updateCountdownBadge, 1000);
            updateCountdownBadge();

            globalLoginReloadTimer = setTimeout(() => {
                chrome.tabs.reload(tabId);
            }, 180000);

            // Kelola fallback timer - stop karena login timer aktif
            manageFallbackTimer();
        } else {
            // Reset login timer ketika keluar dari halaman login
            if (globalLoginDetectedTime !== null) {
                console.log('User keluar dari login page, reset login timer...');
                resetLoginTimer();

                // Kelola fallback timer - mungkin start jika tidak ada timer lain
                manageFallbackTimer();
            }
        }

        // --- Jupyter Lab page detection ---
        const jupyterLabPattern = /https:\/\/.*\.studio\.us-east-2\.sagemaker\.aws\/studiolab\/default\/jupyter\/lab/;
        if (tab.url.match(jupyterLabPattern)) {
            // Reset Jupyter Lab timer setiap kali reload
            resetJupyterLabTimer();

            // Mulai timer baru
            startJupyterLabTimer(tabId);

            // Kelola fallback timer - stop karena Jupyter Lab timer aktif
            manageFallbackTimer();
        } else {
            // Reset Jupyter Lab timer ketika keluar dari halaman Jupyter Lab
            if (globalJupyterLabDetectedTime !== null) {
                console.log('User keluar dari halaman Jupyter Lab, reset timer...');
                resetJupyterLabTimer();

                // Kelola fallback timer - mungkin start jika tidak ada timer lain
                manageFallbackTimer();
            }
        }

    }
});

// =========================
// CAPTCHA Detector Function
// =========================
function initializeCaptchaDetector(tabId) {
    function detectCaptcha() {
        const captchaSelectors = [
            'awswaf-captcha',
            '[data-awswaf-captcha]',
            '.awswaf-captcha',
            '#awswaf-captcha',
            'div[class*="awswaf"]',
            'div[id*="awswaf"]',
            '.captcha-modal',
            '.captcha-container',
            '.captcha-wrapper',
            '.captcha-box',
            '[id*="captcha"]',
            '[class*="captcha"]',
            '[data-captcha]',
            '.g-recaptcha',
            '#recaptcha',
            'iframe[src*="recaptcha"]',
            '.recaptcha-container',
            '.h-captcha',
            'iframe[src*="hcaptcha"]',
            '.cf-challenge',
            '.challenge-form',
            '.cf-captcha',
            '.aws-captcha',
            '[class*="aws-captcha"]',
            '[id*="aws-captcha"]',
            '[role="dialog"]',
            '.modal',
            '.MuiDialog-root',
            '.popup',
            '.overlay',
            '.challenge',
            '.verification',
            '.security-check',
            '[class*="challenge"]',
            '[class*="verification"]'
        ];

        let captchaFound = false;
        let foundElement = null;

        for (const selector of captchaSelectors) {
            try {
                const elements = document.querySelectorAll(selector);
                if (elements.length > 0) {
                    for (const element of elements) {
                        const style = window.getComputedStyle(element);
                        const rect = element.getBoundingClientRect();
                        if (style.display !== 'none' && style.visibility !== 'hidden' &&
                            style.opacity !== '0' && rect.width > 0 && rect.height > 0) {
                            captchaFound = true;
                            foundElement = element;
                            break;
                        }
                    }
                    if (captchaFound) break;
                }
            } catch (error) {}
        }

        if (!captchaFound) {
            const iframes = document.querySelectorAll('iframe');
            for (const iframe of iframes) {
                try {
                    const src = iframe.src ? iframe.src.toLowerCase() : '';
                    const title = iframe.title ? iframe.title.toLowerCase() : '';
                    const className = iframe.className ? iframe.className.toLowerCase() : '';
                    if (src.includes('captcha') || src.includes('recaptcha') || src.includes('hcaptcha') ||
                        title.includes('captcha') || className.includes('captcha') ||
                        src.includes('challenge') || title.includes('challenge')) {
                        const rect = iframe.getBoundingClientRect();
                        const style = window.getComputedStyle(iframe);
                        if (style.display !== 'none' && style.visibility !== 'hidden' &&
                            rect.width > 0 && rect.height > 0) {
                            captchaFound = true;
                            foundElement = iframe;
                            break;
                        }
                    }
                } catch (error) {}
            }
        }

        if (!captchaFound) {
            const bodyText = document.body.textContent.toLowerCase();
            const captchaKeywords = [
                'complete the captcha',
                'solve the captcha',
                'verify you are human',
                'prove you are human',
                'security check',
                'prove you are not a robot',
                'human verification',
                'challenge verification',
                'verify your identity',
                'security challenge',
                'complete verification',
                'anti-robot verification'
            ];
            for (const keyword of captchaKeywords) {
                if (bodyText.includes(keyword)) {
                    captchaFound = true;
                    break;
                }
            }
        }

        if (!captchaFound) {
            const suspiciousElements = document.querySelectorAll('[data-sitekey], [data-site-key], [data-callback*="captcha"]');
            if (suspiciousElements.length > 0) {
                for (const element of suspiciousElements) {
                    const rect = element.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                        captchaFound = true;
                        foundElement = element;
                        break;
                    }
                }
            }
        }

        return { found: captchaFound, element: foundElement };
    }

    function startCaptchaMonitoring() {
        const checkInterval = 3000;
        let lastCaptchaState = false;

        setInterval(() => {
            const captchaResult = detectCaptcha();
            if (captchaResult.found) {
                if (!lastCaptchaState) {
                    window.postMessage({ type: 'CAPTCHA_DETECTED', source: 'captcha-detector' }, '*');
                    lastCaptchaState = true;
                }
                if (document.title.indexOf('[CAPTCHA]') === -1) {
                    document.title = '[CAPTCHA] ' + document.title;
                }
            } else {
                if (lastCaptchaState) {
                    window.postMessage({ type: 'CAPTCHA_CLEARED', source: 'captcha-detector' }, '*');
                    lastCaptchaState = false;
                }
                if (document.title.indexOf('[CAPTCHA]') !== -1) {
                    document.title = document.title.replace('[CAPTCHA] ', '');
                }
            }
        }, checkInterval);
    }

    startCaptchaMonitoring();
    const initialResult = detectCaptcha();
    if (initialResult.found) {
        document.title = '[CAPTCHA] ' + document.title;
        window.postMessage({ type: 'CAPTCHA_DETECTED', source: 'captcha-detector' }, '*');
    }
}
