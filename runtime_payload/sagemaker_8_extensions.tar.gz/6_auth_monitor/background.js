// background.js
// Service worker untuk menangani pesan dari content script

console.log("[AuthTokenMonitor Background] Service worker started");

/**
 * Listener untuk pesan dari content script
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[AuthTokenMonitor Background] Received message:", message);
  
  if (message.action === "auth_token_expired") {
    console.log("[AuthTokenMonitor Background] ⚠️ Auth token expired detected!");
    console.log("[AuthTokenMonitor Background] Source URL:", message.url);
    console.log("[AuthTokenMonitor Background] Sender tab:", sender.tab?.id);
    
    handleAuthTokenExpired();
    sendResponse({ success: true });
  }
  
  return true; // Keep message channel open for async response
});

/**
 * Fungsi utama untuk menangani auth token expired:
 * 1. Tutup semua tab (TANPA menghapus cache)
 * 2. Buka tab baru dengan URL login SageMaker
 */
async function handleAuthTokenExpired() {
  try {
    console.log("[AuthTokenMonitor Background] 🔄 Starting auth token expired handling...");
    
    // Step 1: Buat tab login BARU terlebih dahulu (agar browser tidak menutup semua)
    console.log("[AuthTokenMonitor Background] 📄 Creating new login tab...");
    const newTab = await chrome.tabs.create({
      url: "https://studiolab.sagemaker.aws/login",
      active: true
    });
    
    console.log("[AuthTokenMonitor Background] ✅ New login tab created with ID:", newTab.id);
    
    // Step 2: Dapatkan semua tab yang ada
    const allTabs = await chrome.tabs.query({});
    console.log("[AuthTokenMonitor Background] 📋 Found", allTabs.length, "tabs total");
    
    // Step 3: Tutup semua tab KECUALI tab login yang baru dibuat
    let closedCount = 0;
    for (const tab of allTabs) {
      if (tab.id !== newTab.id) {
        try {
          await chrome.tabs.remove(tab.id);
          closedCount++;
          console.log("[AuthTokenMonitor Background] ❌ Closed tab:", tab.id, "-", tab.url);
        } catch (err) {
          console.warn("[AuthTokenMonitor Background] Failed to close tab", tab.id, ":", err.message);
        }
      }
    }
    
    console.log("[AuthTokenMonitor Background] ✅ Successfully closed", closedCount, "tabs");
    console.log("[AuthTokenMonitor Background] ✅ Login tab remains open");
    console.log("[AuthTokenMonitor Background] 🎉 Auth token expired handling completed!");
    
    // CATATAN: Kita TIDAK menghapus cache/cookies, hanya menutup tab
    
  } catch (err) {
    console.error("[AuthTokenMonitor Background] ❌ Error handling auth token expired:", err);
    
    // Fallback: Minimal buat tab login baru jika terjadi error
    try {
      await chrome.tabs.create({
        url: "https://studiolab.sagemaker.aws/login"
      });
      console.log("[AuthTokenMonitor Background] Fallback: Created login tab");
    } catch (fallbackErr) {
      console.error("[AuthTokenMonitor Background] Fallback failed:", fallbackErr);
    }
  }
}

console.log("[AuthTokenMonitor Background] ✅ Background script initialized and ready");
