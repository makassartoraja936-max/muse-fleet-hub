# SageMaker Auth Token Monitor

Extension Chrome sederhana untuk mendeteksi error "Invalid or Expired Auth Token" pada halaman SageMaker dan otomatis menutup semua tab lalu membuka halaman login.

## Fitur

✅ Mendeteksi pesan error: "Invalid or Expired Auth Token. Request a new presigned URL to continue using SageMaker."
✅ Menutup semua tab otomatis saat error terdeteksi
✅ Membuka tab baru dengan halaman login SageMaker
✅ **TIDAK menghapus cache atau cookies** (berbeda dengan extension utama)

## Cara Kerja

1. **Content Script** (`content.js`):
   - Berjalan di semua halaman SageMaker (studiolab.sagemaker.aws dan *.studio.us-east-2.sagemaker.aws)
   - Memantau halaman untuk mencari text error "Invalid or Expired Auth Token"
   - Menggunakan MutationObserver untuk mendeteksi perubahan DOM secara real-time
   - Mengirim pesan ke background script saat error terdeteksi

2. **Background Script** (`background.js`):
   - Menerima pesan dari content script
   - Menutup semua tab (kecuali tab login yang baru dibuat)
   - Membuat tab baru dengan URL: https://studiolab.sagemaker.aws/login
   - Tidak menghapus cache/cookies (hanya menutup tab)

## Instalasi

1. Buka Chrome dan ketik: `chrome://extensions/`
2. Aktifkan "Developer mode" (toggle di kanan atas)
3. Klik "Load unpacked"
4. Pilih folder `1` yang berisi extension ini
5. Extension akan aktif otomatis

## File Structure

```
1/
├── manifest.json      # Konfigurasi extension
├── content.js         # Script untuk deteksi error di halaman
├── background.js      # Script untuk menangani penutupan tab
└── README.md          # File ini
```

## Perbedaan dengan Extension Utama

| Fitur | Extension Ini | Extension Utama |
|-------|--------------|-----------------|
| Deteksi auth error | ✅ | ✅ |
| Tutup semua tab | ✅ | ✅ |
| Hapus cache | ❌ | ✅ |
| Ganti akun | ❌ | ✅ |
| Auto login | ❌ | ✅ |
| Mining automation | ❌ | ✅ |

Extension ini **lebih sederhana** dan **hanya fokus** pada satu fungsi: mendeteksi auth token expired dan redirect ke login.

## Debug

Untuk melihat log extension:
1. Klik kanan pada icon extension > "Inspect popup" (untuk popup)
2. Atau buka Console di halaman SageMaker (F12) untuk melihat log content script
3. Atau buka `chrome://extensions/` > klik "background page" pada extension ini untuk melihat log background script

## Catatan

- Extension ini akan bekerja di semua halaman SageMaker domain
- Deteksi error case-insensitive (tidak peduli huruf besar/kecil)
- Jika MutationObserver gagal, akan fallback ke interval check setiap 3 detik
- Tab login baru dibuat SEBELUM tab lain ditutup untuk mencegah browser menutup semua window
