// content.js
// Script untuk mendeteksi pesan "Invalid or Expired Auth Token" di halaman SageMaker

console.log("[AuthTokenMonitor] Content script loaded on:", window.location.href);

let authErrorDetected = false;

/**
 * Fungsi untuk mengecek apakah text mengandung pesan error auth token
 */
function containsAuthTokenError(text) {
  if (!text) return false;
  
  const lowerText = text.toLowerCase();
  
  // Cek keberadaan semua kata kunci penting
  const keywords = [
    "invalid or expired auth token",
    "request a new presigned url",
    "continue using sagemaker"
  ];
  
  // Return true jika semua keyword ditemukan
  return keywords.every(keyword => lowerText.includes(keyword));
}

/**
 * Fungsi untuk trigger penutupan tab dan redirect ke login
 */
function triggerAuthErrorHandling() {
  if (authErrorDetected) {
    console.log("[AuthTokenMonitor] Error sudah diproses sebelumnya, skip.");
    return;
  }
  
  authErrorDetected = true;
  console.log("[AuthTokenMonitor] ⚠️ Auth token error terdeteksi!");
  console.log("[AuthTokenMonitor] Mengirim pesan ke background script...");
  
  try {
    chrome.runtime.sendMessage({ 
      action: "auth_token_expired",
      url: window.location.href 
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("[AuthTokenMonitor] Error mengirim pesan:", chrome.runtime.lastError.message);
      } else {
        console.log("[AuthTokenMonitor] ✅ Pesan berhasil dikirim ke background");
      }
    });
  } catch (err) {
    console.error("[AuthTokenMonitor] Gagal mengirim pesan:", err);
  }
}

/**
 * Fungsi untuk check sekali di halaman
 */
function checkForAuthError() {
  try {
    // Ambil semua text dari halaman
    const bodyText = document.body ? (document.body.innerText || document.body.textContent || "") : "";
    
    if (containsAuthTokenError(bodyText)) {
      console.log("[AuthTokenMonitor] 🔍 Error message ditemukan di halaman!");
      console.log("[AuthTokenMonitor] Sample text:", bodyText.substring(0, 200));
      triggerAuthErrorHandling();
      return true;
    }
  } catch (err) {
    console.warn("[AuthTokenMonitor] Error saat membaca body text:", err);
  }
  
  return false;
}

/**
 * Fungsi untuk memulai monitoring halaman
 */
function startMonitoring() {
  console.log("[AuthTokenMonitor] 🚀 Memulai monitoring untuk auth token error...");
  
  // Check pertama kali
  if (checkForAuthError()) {
    return; // Sudah ditemukan, tidak perlu monitoring lagi
  }
  
  // Setup MutationObserver untuk mendeteksi perubahan di DOM
  try {
    const observer = new MutationObserver(() => {
      if (authErrorDetected) {
        observer.disconnect();
        return;
      }
      
      checkForAuthError();
    });
    
    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
    
    console.log("[AuthTokenMonitor] ✅ MutationObserver berhasil dijalankan");
  } catch (err) {
    console.warn("[AuthTokenMonitor] Gagal menjalankan MutationObserver:", err);
    
    // Fallback: cek secara periodik setiap 3 detik
    const intervalId = setInterval(() => {
      if (authErrorDetected) {
        clearInterval(intervalId);
        return;
      }
      
      checkForAuthError();
    }, 3000);
    
    console.log("[AuthTokenMonitor] ⏰ Fallback ke interval check setiap 3 detik");
  }
}

// Jalankan monitoring saat halaman sudah siap
if (document.readyState === "complete" || document.readyState === "interactive") {
  startMonitoring();
} else {
  window.addEventListener("DOMContentLoaded", startMonitoring);
}

console.log("[AuthTokenMonitor] ✅ Content script initialized");
