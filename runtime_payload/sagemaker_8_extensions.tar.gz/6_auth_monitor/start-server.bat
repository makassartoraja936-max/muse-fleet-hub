@echo off
echo ========================================
echo Starting Local Web Server for Testing
echo ========================================
echo.
echo Extension will run on: http://localhost:8000
echo.
echo Test pages available:
echo - http://localhost:8000/test-simple.html
echo - http://localhost:8000/test.html
echo.
echo Press Ctrl+C to stop the server
echo ========================================
echo.

python -m http.server 8000

pause
